com_changeadmin

The goal of this component is to enhanced the security of sites in Joomla.

After an Joomla upgrade its can overwrite administrator/index.php. If this happens, this version of changeadmin no longer works.

After running the adminchange, direct access to the administrator is redirected to the site.

Befone install this component ensure what your server hosting have support to mod_rewrite.
Do not use if your server do not support mod_rewrite.

If you have a administrator/.htaccess the changeadmin make a backup to administrator/.htaccess_backup and copy to new directory also with .htpasswd.
After creation new directory change path to htpasswd in .htaccess

If you have others files make a manually copy to new directory and edition.

Install compopnent
Access in administrator
Change the administrator directory parameter

Obs.: After login in administrator the access to "administrator" directory is granted. 
Is denied to others users not logged.

After uninstall this component or if ocurre problema, only remove this lines in administrator/index.php:
if ($_COOKIE['JoomlaAdminSession'] != "1234567890")
{
	?><script>location='../index.php';</script><?;
}

WARNING

If install in server without mod_rewrite to manually uninstall:

1) remove this lines in administrator/index.php:
if ($_COOKIE['JoomlaAdminSession'] != "1234567890")
{
	?><script>location='../index.php';</script><?;
}

2) If you install and your server dont support module rewrite then your site dont more works.
Remove the file administrator/.htaccess

And your site wirks again.

__________________________________________
Ribamar FS - http://ribafs.org - 21/11/2011

