<?php
/**
 * Component com_changeadmin
 * @copyright	Copyright (C) 2010 Ribamar FS.
 * @license		GNU/GPL, see http://www.gnu.org/licenses/old-licenses/gpl-2.0.txt
 * JoomInstaller is free and open source software. This version may have been modified 
 * pursuant to the GNU General Public License, and as distributed it includes or is 
 * derivative of works licensed under the GNU General Public License or other free or 
 * open source software licenses. 
 * http://ribafs.org
*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
error_reporting(E_ALL & ~E_NOTICE);
require_once( JPATH_COMPONENT.DS.'changeadmin.html.php' );

jimport( 'joomla.application.helper' );
jimport('joomla.filesystem.file');
jimport('joomla.filesystem.folder');

upd();

function upd()
{
	$subupd = JRequest::getVar('submit') ;

	if(isset($subupd)){
		$new_directory = JRequest::getVar( 'new_directory');

		$new_directory = JPATH_ROOT.DS.$new_directory;
		$new_directory = JFolder::makeSafe($new_directory);
		if(file_exists($new_directory)){
			//
		}else{
			JFolder::create($new_directory);
		}

		// In new directory create a index.php
		$index_newadmin ="<?php
\$admin_cookie_code=\"1234567890\";
setcookie(\"JoomlaAdminSession\",\$admin_cookie_code,0,\"/\");
header(\"Location: ../administrator/index.php\");
?>
";
	
		$new_index = $new_directory.DS.'index.php';
		if(file_exists($new_index)){
			//
		}else{
			$fp = fopen($new_index, "w");
			$wrt = fwrite($fp, $index_newadmin);
			// close file
			fclose($fp);
		}
		
		if(file_exists($htaccess_admin)){
			JFile::move($htaccess_admin, $new_directory.DS.'.htaccess');
		}

		// In administrator append to start of index.php
$index_admin_add ="<?php
/**
 * @version		\$Id: index.php 21399 2011-05-30 23:10:20Z dextercowley $
 * @package		Joomla.Administrator
 * @copyright	Copyright (C) 2005 - 2011 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

// Set flag that this is a parent file
define('_JEXEC', 1);
define('DS', DIRECTORY_SEPARATOR);

if (@\$_COOKIE['JoomlaAdminSession'] != '1234567890')
{
    header('Location: http://www.google.com/');
}

if (file_exists(dirname(__FILE__) . '/defines.php')) {
	include_once dirname(__FILE__) . '/defines.php';
}

if (!defined('_JDEFINES')) {
	define('JPATH_BASE', dirname(__FILE__));
	require_once JPATH_BASE.'/includes/defines.php';
}

require_once JPATH_BASE.'/includes/framework.php';
require_once JPATH_BASE.'/includes/helper.php';
require_once JPATH_BASE.'/includes/toolbar.php';

// Mark afterLoad in the profiler.
JDEBUG ? \$_PROFILER->mark('afterLoad') : null;

// Instantiate the application.
\$app = JFactory::getApplication('administrator');

// Initialise the application.
\$app->initialise(array(
	'language' => \$app->getUserState('application.lang')
));

// Mark afterIntialise in the profiler.
JDEBUG ? \$_PROFILER->mark('afterInitialise') : null;

// Route the application.
\$app->route();

// Mark afterRoute in the profiler.
JDEBUG ? \$_PROFILER->mark('afterRoute') : null;

// Dispatch the application.
\$app->dispatch();

// Mark afterDispatch in the profiler.
JDEBUG ? \$_PROFILER->mark('afterDispatch') : null;

// Render the application.
\$app->render();

// Mark afterRender in the profiler.
JDEBUG ? \$_PROFILER->mark('afterRender') : null;

// Return the response.
echo \$app;
";

		$index_admin = JPATH_ROOT.DS.'administrator'.DS.'index.php';

		$fp = fopen($index_admin, "w");
		$wrt = fwrite($fp, $index_admin_add);
		// close file
		fclose($fp);

		//Credits: Créditos: http://www.joomlahackers.net/joomla-tutorials/change-joomla-admin-name-or-path.html

	}
 	OutputChangeadmin::updChangeadmin();
	
}// end function upd()

?>
