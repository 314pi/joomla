<?php
/**
 * @package		Version Verification Tool
 * @copyright (C) 2010-2012 by SourceCoast - All rights reserved
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controller');

class VersionVerificationToolControllerHome extends JController
{
	function display()
	{
        $document = & JFactory::getDocument();
        $viewType = $document->getType();
        $viewName = 'home';
        $viewLayout = JRequest::getCmd('layout', 'default');
        $view = $this->getView($viewName, $viewType);
        $view->setLayout($viewLayout);
        $view->display();
	}
}
