<?php
/**
 * @package		Version Verification Tool
 * @copyright (C) 2010-2012 by SourceCoast - All rights reserved
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */
defined('_JEXEC') or die('Restricted access');

class VersionVerificationToolHelper
{
	function _versionCmp($a, $b)
	{
		$aVersion = str_replace(".xml", "", $a->text);
		$bVersion = str_replace(".xml", "", $b->text);

		if($aVersion == $bVersion)
		{
			return 0;
		}

		$aArray = explode(".", $aVersion);
		$bArray = explode(".", $bVersion);

		while(($aElement = array_shift($aArray)) != null && ($bElement = array_shift($bArray)) != null)
		{
			if($aElement < $bElement)
			{
				return 1;
			}
			else if($aElement != $bElement)
			{
				return -1;
			}
		}

		$aCount = count($aArray);
		$bCount = count($bArray);

		if($aCount == $bCount)
		{
			return 0;
		}
		else if($aCount < $bCount)
		{
			return 1;
		}
		else
		{
			return -1;
		}
	}

	function getArrayValue($fileArray, $text)
	{
		foreach($fileArray as $fileElement)
		{
			if($fileElement->text == $text)
			{
				return $fileElement->value;
			}
		}

		return "";
	}

	function getXmlFiles()
	{
		$xmlFiles = array();
		$xmlDirPath = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_versionverificationtool'.DS."xml".DS;

        
        
        $xmlDirPath .= "1_7".DS;
        

		$dirhandle = @opendir($xmlDirPath);
		if($dirhandle)
		{
			while($file = readdir($dirhandle))
			{
				if($file != "." && $file != ".." && is_file($xmlDirPath.$file))
				{
					$fileObject = new stdClass();
					$fileObject->value = $xmlDirPath.$file;
					$fileObject->text = $file;
					array_push($xmlFiles, $fileObject);
				}
			}
		}

		// Sort the version numbers for the drop down
		usort($xmlFiles, array("VersionVerificationToolHelper", "_versionCmp"));

		return $xmlFiles;
	}
}
