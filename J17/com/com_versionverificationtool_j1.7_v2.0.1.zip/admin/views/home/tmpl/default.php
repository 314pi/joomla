<?php
/**
 * @package		Version Verification Tool
 * @copyright (C) 2010-2012 by SourceCoast - All rights reserved
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */
defined('_JEXEC') or die('Restricted access');
?>

<style type="text/css">
.icon-48-vvt {
    background-image: url('components/com_versionverificationtool/assets/images/vvt_icon48.png');
}

div.pagetitle.icon-48-vvt h2 {
    margin-left: 20px;
}

div.header.icon-48-vvt {
    padding-left: 85px;
}
</style>

<form action="index.php?option=com_versionverificationtool" method="post" name="adminForm">
<?php
	$xmlFiles = VersionVerificationToolHelper::getXmlFiles();

	// Get the currently installed version of Joomla to default the drop down
	$version = new JVersion();
	$versionString = $version->getShortVersion().".xml";
	$selectedValue = VersionVerificationToolHelper::getArrayValue($xmlFiles, $versionString);

		// Create the drop down
	print JHTML::_('select.genericlist', $xmlFiles, 'xmlFile', 'class="inputbox"', 'value', 'text', $selectedValue);
?>
	<input type="submit" value="Run Check" />
	<input type="hidden" name="comCheck" value="joomla" />
	<input type="hidden" name="task" value="runcheck" />
</form>

<?php
if (!$this->checkStarted)
{ # No check started, print the intro
?>
	<p>Welcome to the Version Verification Tool. This component will check each file of your Joomla installation to verify that it hasn't been modified from it's original state. If a file has been modified, if "Find Version" is set to "Yes" in your parameters, an attempt will be made to see if a different official version of that file resides on your server. This parameter is defaulted to 'No' as it's more memory and compute intensive, and therefore, may not work properly under all conditions.</p>
	<p>To run the check, set the drop-down to the correct version of your Joomla installation and click "Run Check".</p>
<?php
}
else
{
	print "<hr/>";
	print "Running check...<br />";
	if ($this->memLimitIncreased)
	{
		print "<b>Memory Limit:</b> Temporarily increasing to ".$this->memoryLimit."<br />";
		print "<b>Max Execution Time:</b> Temporarily increasing to ".$this->maxExecutionTime." seconds<br />";
	}

	print "<b>XML File:</b> ".$this->xmlFile."<br />";
	print "<b>Root Joomla Path:</b> ".JPATH_ROOT."<br />";

	print "<h2>Modified Files</h2>\n";
	if (empty($this->modifiedFiles))
		print "No modified files detected.";
	else
	{
		print "<ul>\n";
		foreach($this->modifiedFiles as $file)
			print "<li>".$file."</li>\n";
		print "</ul>\n";
	}

	print "<h2>Missing Files</h2>\n";
	if (empty($this->missingFiles))
		print "No missing files detected.";
	else
	{
		print "<ul>\n";
		foreach($this->missingFiles as $file)
				print "<li>".$file."</li>\n";
		print "</ul>\n";
	}

	print "<h2>Ignored Files</h2>\n";
	if (empty($this->ignoredFiles))
		print "No ignored files detected.";
	else
	{
		print "<ul>\n";
		foreach($this->ignoredFiles as $file => $count)
			print "<li><b>".$file.":</b> ".$count."</li>\n";
		print "</ul>\n";
	}

}
?>
	<hr/>
	<p><strong>Legend:</strong><br/>
	<strong>Modified Files</strong> - Files that are not the 'official' version of the file as distributed by Joomla.org</p>
	<p><strong>Missing Files</strong> - Files that could not be found on your system, though the should be there</p>
	<p><strong>Ignored Files</strong> - Files that are intentionally not tested. This can be configured through the parameters. Example: The installation directory, which is intentionally removed after site configuration.</p>
	
