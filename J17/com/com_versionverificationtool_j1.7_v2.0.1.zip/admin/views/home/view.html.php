<?php
/**
 * @package		Version Verification Tool
 * @copyright (C) 2010-2012 by SourceCoast - All rights reserved
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');
jimport('joomla.utilities.simplexml');

class VersionVerificationToolViewHome extends JView
{
	function display()
	{
		require_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_versionverificationtool'.DS.'helpers'.DS.'helper.php');
		$componentCheck = JRequest::getString('comCheck');
		$checkStarted = false;
		if ($componentCheck == "joomla")
		{
			$checkStarted = true;

			$xmlFile = JRequest::getVar("xmlFile");
			# display the xml file;
			$this->assignRef('xmlFile', $xmlFile);
            
            
            $componentParams = JComponentHelper::getParams('com_versionverificationtool');
            $params = $componentParams->get('params');

            if(isset($params))
            {
                $findVersion = $params->findversion; //"0"
                $memoryLimit = $params->memory_limit; //"256M"
                $maxExecutionTime = $params->max_execution_time;//"300"
                $ignoreRegEx = $params->ignoreregex;// "/^installation\\/.*/"
            }
            else
            {
                $findVersion = "0";
                $memoryLimit = "256M";
                $maxExecutionTime = "300";
                $ignoreRegEx = "/^installation\\/.*/";
            }
            
			$this->assignRef('memLimitIncreased', $findVersion);
			$this->assignRef('memoryLimit', $memoryLimit);
			$this->assignRef('maxExecutionTime', $maxExecutionTime);
			$fileList = array();
			$xmlFiles;
			if($findVersion)
			{
				$xmlFiles = VersionVerificationToolHelper::getXmlFiles();
				ini_set('memory_limit', $memoryLimit);
				ini_set('max_execution_time', $maxExecutionTime);

				$xmlFileCount = 0;
				foreach($xmlFiles as $xmlFile2)
				{
					$xml2 = new JSimpleXML();
					$xml2->loadFile($xmlFile2->value);

					$files2 = $xml2->document->getElementByPath("/files")->children();
					foreach($files2 as $file2)
					{
						$xmlname2 = $file2->attributes("name");
						$xml2md5 = $file2->attributes("md5");

						if(!array_key_exists($xmlname2, $fileList))
						{
							$fileList[$xmlname2] = array();
							for($i = 0; $i < $xmlFileCount; $i++)
							{
								array_push($fileList[$xmlname2], null);
							}
						}

						array_push($fileList[$xmlname2], $xml2md5);

					}
					unset($files2);

					$xmlFileCount++;
					unset($xml2);
				}
			}
		
			$missingFiles = array();
			$modifiedFiles = array();
			$ignoredFiles = array();

			$xml = new JSimpleXML();
			$xml->loadFile($xmlFile);

			$files = $xml->document->getElementByPath("/files")->children();
	
			foreach($files as $file)
			{
				$xmlname = $file->attributes("name");
				$xmlmd5 = $file->attributes("md5");
	
				if(preg_match($ignoreRegEx, $xmlname))
				{
					if(array_key_exists($ignoreRegEx, $ignoredFiles))
					{
						$ignoredFiles[$ignoreRegEx]++;
					}
					else
					{
						$ignoredFiles[$ignoreRegEx] = 1;
					}
				}
				else
				{
					$name = JPATH_ROOT.DS.$xmlname;
					if(!file_exists($name))
					{
						array_push($missingFiles, $name);
					}
					else
					{
						$md5 = md5_file($name);
						if($xmlmd5 != $md5)
						{
							if($findVersion)
							{
								// Loop over all our XML files
								$versionFound = false;
								if(array_key_exists($xmlname, $fileList))
								{
									for($i = 0; $i < count($xmlFiles); $i++)
									{
										if($fileList[$xmlname][$i] == $md5)
										{
											$versionFound = true;
											$name .= " (".$xmlFiles[$i]->text.")";
											break;
										}
									}

								}
	
								if(!$versionFound)
								{
									$name .= " (unknown version)";
								}
							}
							array_push($modifiedFiles, $name);
						}
					}
				}
			}

			$this->assignRef('missingFiles', $missingFiles);
			$this->assignRef('modifiedFiles', $modifiedFiles);
			$this->assignRef('ignoredFiles', $ignoredFiles);
	
		}

		$this->assignRef('checkStarted', $checkStarted);
		parent::display();
	}
}
