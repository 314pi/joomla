<?php 
echo( $rows[$num]);

?>
