<?php

defined( '_JEXEC' ) or die( 'Restricted access' );

$mainframe->registerEvent( 'onSearch', 'botSearchRquotes' );
$mainframe->registerEvent( 'onSearchAreas', 'botSearchRquotesAreas' );

function &botSearchRquotesAreas() {
	static $areas = array(
		'rquotes' => ' Rquotes'
	);
	return $areas;
}

function botSearchRquotes ( $text, $phrase='', $ordering='', $areas=null )
{
	if (!$text) {
		return array();
	}
	
	if (is_array( $areas )) {
		if (!array_intersect( $areas, array_keys( botSearchRquotesAreas() ) )) {
			return array();
		}
	}
	
	$plugin =& JPluginHelper::getPlugin('search', 'rquotes');
 	$pluginParams = new JParameter( $plugin->params );

	$limit = $pluginParams->get( 'search_limit', 50 );


	$db =& JFactory::getDBO();

	if ($phrase == 'exact')
	{
		$where = "(LOWER(quote) LIKE '%$text%')
		 OR (LOWER(author) LIKE '%$text%')" .
		" OR (LOWER(notes) LIKE '%$text%') ";
	}
	else
	{
		$words = explode( ' ', $text );
		$wheres = array();

		foreach ($words as $word) {
			$wheres[] = "(LOWER(quote) LIKE '%$word%')
			 OR (LOWER(author) LIKE '%$word%')" .
						" OR (LOWER(notes) LIKE '%$word%') ";
		}

		if($phrase == 'all')
		{
			$separator = "AND";
		}
		else
		{
			$separator = "OR";
		}

		$where = '(' . implode( ") $separator (" , $wheres ) . ')';
	}

	$where .= ' AND published = 1';
	
	switch ($ordering) {
		case 'oldest':
			$order = 'id ASC';
			break;

		case 'alpha':
			$order = 'quote ASC';
			break;

		case 'newest':
		default:
			$order = 'record_date DESC';
			break;
	}
	
	$query = "SELECT  quote AS title, author AS text, record_date AS created, " .
		"\n 'Rquotes' AS section," .
		"\n CONCAT('index.php?option=com_rquotes&view=one&id=', id)  AS href," .
		"\n '2' AS browsernav" .
	"\n FROM #__rquotes" .
		"\n WHERE $where" .
		"\n ORDER BY $order"	
		;
   $db->setQuery( $query,0, $limit );
//	$db->setQuery( $query );
	$rows = $db->loadObjectList();

	return $rows;
}

?>