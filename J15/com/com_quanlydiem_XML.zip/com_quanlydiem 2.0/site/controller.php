<?php

jimport('joomla.application.component.controller');


class QuanlydiemController extends JController
{
	
	function display()
	{
		parent::display();
	}
}
?>
