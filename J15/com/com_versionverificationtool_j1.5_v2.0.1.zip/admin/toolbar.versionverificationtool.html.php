<?php
/**
 * @package		Version Verification Tool
 * @copyright (C) 2010-2012 by SourceCoast - All rights reserved
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

class TOOLBAR_versionverificationtool
{
	function _DEFAULT()
	{
		JToolBarHelper::preferences('com_versionverificationtool', '400');
        JToolBarHelper::title('Version Verification Tool', 'vvt.png');
	}
}
