<?php
/**
 * @package		Version Verification Tool
 * @copyright (C) 2010-2012 by SourceCoast - All rights reserved
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

	defined('_JEXEC') or die('Restricted access');

	require_once(JPATH_COMPONENT.DS.'controller.php'); 
	$option = JRequest::getString('option');

	$controller = new VersionVerificationToolControllerHome();
	$controller->execute(JRequest::getVar('task'));
	include_once(JPATH_ADMINISTRATOR.DS.'components'.DS.$option.DS.'assets'.DS.'footer'.DS.'footer.php');
	$controller->redirect();
?> 
