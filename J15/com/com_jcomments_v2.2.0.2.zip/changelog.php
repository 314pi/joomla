<?php
/**
 * @package JComments
 * @version 2.2.0.0
 * @author Sergey M. Litvinov (smart@joomlatune.ru)
 * @copyright (C) 2006-2010 by Sergey M. Litvinov (http://www.joomlatune.ru)
 * @license GNU/GPL: http://www.gnu.org/copyleft/gpl.html
*/

(defined('_VALID_MOS') OR defined('_JEXEC')) or die('Restricted access');
?>

Changelog
------------

2.2.0.2
# Fixed bug in [img] tag processing

2.2.0.1
# Fixed XSS vulnerability through URL and IMG tags (thanks to Jeff)
# Fixed bug in Custom BBCode's save function (close tag wasn't saved)

2.2.0.0
^ Pre-release code revision
^ Updated JComments installer
^ Updated information about translators
# Fixed small error in template's CSS file
# Fixed error in router (the link to full rss was broken)
# Fixed bug in settings section (the permission tab was blank for catalan language)
+ Added plugin for LyftenBloggie support
^ Updated comments import from LyftenBloggie component
# Fixed bug in router (unsubscribe didn't work)
+ Added support of 3rd party CAPTCHA implementations (via plugins)
+ Added plugin for FLEXIcontent support (thanks to Emmanuel Danan)
$ Updated Greek translation (thanks to Chrysovalantis Mochlas and Lazaros Giannakidis)
+ Added new parameter: Minimum comment length
^ All plugins were updated for better compatibility with JoomFish 
$ Updated Portuguese translation (thanks to Pedro Jesus)
$ Updated Portuguese (Brazilian) translation (thanks to Caio Guimaraes)
$ Added Galician translation
+ Added support for RTL language (extra CSS styles)
+ Added support for creating subscriptions from backend
+ New custom BBCode: Facebook Video
+ Improved page navigation for comments (flat list layout)
^ Imporved URL handling in BBCodes
+ Added plugin for JaVoice support
+ Added plugin for RSEvents! support (thanks to Oregon)
+ Added comments import from JA Comment component
+ Added plugin for TPDugg support
+ Added comments import from TPDugg component
+ Added comments import from ZOO 2.0 component
^ Updated plugin for com_resource (thanks to Sergey Romanov)
^ Replaced eregi with preg_match for more PHP 5.3 compatibility
+ Added rule for support JomSocial's User Points System
# Fixed some errors in yvComment import function
+ Added support meta keywords and description for JComments menu item
^ Improved import comments from JoomGallery (added support JoomGallery 1.5.5 beta)
$ Updated Dutch translation (thanks to Zjuul and Mirjam)
$ Fixed typo in language files 'persmissions' -> 'permissions'
+ Added plugin for JUserlist support
^ Improved import comments algorithm
+ Added copy function for Custom BBCodes 
# Fixed pagination bug (thanks to blanxd, http://www.joomlatune.com/forum/index.php/topic,1551.0.html)
+ Added plugin for BeeHeard support
+ Added comments import from BeeHeard component
+ Added plugin for DigiFolio support
+ Added plugin for JMyLife support
+ Added comments import from JMyLife component
+ Added plugin for Music Collection support
+ Added comments import from Music Collection component
# Fixed possible XSS in JComments backend (http://www.htbridge.ch/advisory/xss_vulnerability_in_jcomments_joomla.html)
+ Added comments import from RSComments component

2.1.0.8
+ Added router for RSS feed urls translation to be humanly readable
+ Added function to restore the default settings
+ Added parameter to setup notifications type to administrator
+ Added support for Joostina 1.3.0
+ Added comments import from yvComments component
+ Added comments import from ZiMB Comment component
+ Added comments import from RDBS Comment component
+ Added comments import from Webee Comment component
+ Added comments import from LyftenBloggie component
+ Added comments import from MightyExtensions Resource (JoomSuite Resource) component
+ Added check current Joomla's template for afterDisplayContent event (only for Joomla 1.5)
+ Added filter and sorting in JComments backend
+ Added parameters to switch Readmore CSS class
+ Added plugin for MooFAQ component (thanks to Douglas Machado)
+ Added plugin for CoreJoomla Community Polls component (thanks to maverick)
+ Added plugin for full PhocaGallery support (thanks to Jan Pavelka)
+ Added plugin for full PhocaDownload support (thanks to Jan Pavelka)
^ Settings form in JComments backend now uses AJAX
^ Import comments in JComments backend now uses AJAX
^ Added missed title attribute for links in Subscrition Manager
^ Added fix for very long titles (same function as for long words in comment text)
^ Updated plugin for JCalPro (added support JCalPro 2.x)
^ Changed CSS class name for link to comments (from 'comment-link' to 'comments-link')
$ Updated Spanish translation (thanks to Selim Alamo)
$ Updated Italian translation (thanks to Giuseppe Covino)
$ Updated Romanian translation (thanks to Dan Partac)
$ Updated Swedish translation (thanks to MulletMidget)
$ Updated Croatian translation (thanks to Tomislav Kikic)
$ Updated Polish translation (thanks to Jamniq)
$ Updated Slovak translation (thanks to Vladimir Prochazka)
$ Updated Dutch translation (thanks to Pieter Agten and Mirjam)
$ Updated Danish translation (thanks to Martin Podolak and Ole Bang Ottosen)
$ Updated Norwegian translation (thanks to Helge Johnsen)
$ Updated Bulgarian translation (thanks to Georgi Gerov)
$ Added Serbian translation (thanks to Ivan Krkotic)
$ Added Portuguese (Brazilian) translation (thanks to Daniel Gomes)
$ Added Greek translation (thanks to Lazaros Giannakidis)
# Solved saving settings bug with huge number of categories
# Reversed order in Subscrition Manager (changed to alphabet)
# Fixed small bugs in Subscrition Manager
# Fixed bug with RSS feed in IE
# Fixed bug with displaying comments for users without permissions to post comments
# Fixed bug in router (quick moderation didn't work)
# Fixed bug in AJAX calls to an url with port specified
# Fixed bug in PuArcade plugin
# Fixed smiles replacement bug
# Fixed absolute path detection bug (only for Joomla 1.0)
# Fixed AlphaContent integration bug
# Fixed bug in JoomlaComment import (added import email, website and rating fields)
- Removed plugins for Kinoarchiv, True, MDDGallery, PAXXGallery
  (if you need them - take from previous JComments version)
# Fixed bug in comments rating import from ChronoComments (thanks clone)
# Fixed bug with nested quotes processing
# Fixed bug in PhocaGallery comments import
# Fixed bug in SOBI2 Reviews import
 

2.1.0.7
+ Added experimental feature - quick moderation from administrator's notification (publish, unpublish and remove comments directly from administrator's notification e-mail)
+ Added comments import from UrComment component
+ Added Croatian translation (thanks to Damuz)
$ Updated Spanish translation (thanks to Selim Alamo)
$ Updated French translation (thanks to Eric Lamy)
$ Updated Turkish translation (thanks to Tolga Sanci)
$ Updated Romanian translation (thanks to Dan Partac)
$ Updated German translation (thanks to Denis Panschinski)
$ Updated Bulgarian translation (thanks to Alexander Sidorov)
# Fixed small bug in CSS
# Fixed bug in AkoBook entries import (wrong time format)
# Omitted checks result of store function
# Fixed bug in QuickFaq plugin 


2.1.0.6
+ Added a small hack to allow CAPTCHA image displays even if some notice or warning occured
^ Code optimization
# Fixed bug with CODE tag processing

2.1.0.5
+ Added plugin for JCollection component (thanks to Thorsten Riess)
^ Changed error handling and reporting in Report to administrator function
^ Small optimization of JavaScript functions
# JavaScript loads on pages where JComments isn't published
# Fixed comments pagination bug (plain list mode)

2.1.0.4
+ Added getTitles function in plugins (for future optimization)
# Fixed error then magic_quotes_sybase is on.
# Fixed bug with Joom!Fish detection in backend
# FIxed bug in /helpers/plugin.php (Joomla 1.0 only)
# Fixed typos in some plugins (EasyCalendar, EasyFAQ)
$ Updated Turkish translation (thanks to cumla.blogspot.com)

2.1.0.3
+ New option for comments form: hide if any comment exist

2.1.0.2
+ Added 'Report comment' function
$ Fixed typo in language files (AP_FORM_SHOW_FROM to AP_FORM_SHOW_FORM)

2.1.0.1
+ CAPTCHA option switched off automatically if GD library isn't installed 
+ New param in JComment content plugin - Show Hits (Note: will increase SQL queries count per page)
^ Updated K2 comments import function to support K2 v2.0
^ Updated Turkish translation (thanks to cumla.blogspot.com)
# Fixed small bug in javascript function
# The [code] tag isn't properly processed in RSS feeds
# Fixed error in datetime format in Thai language file

* -> Security Fix
# -> Bug Fix
$ -> Language fix or change
+ -> Addition
^ -> Change
- -> Removed
! -> Note