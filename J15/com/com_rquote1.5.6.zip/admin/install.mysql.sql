

CREATE TABLE IF NOT EXISTS `bac_rquotes`
(
  `id` int(11) NOT NULL auto_increment,
  `daily_number` int(11) NOT NULL,
  `quote` text NOT NULL,
  `author` text NOT NULL,
  `categorey`text NOT NULL,
  `notes` text NOT NULL,
  `published` tinyint(1) unsigned NOT NULL default '0',
  `catid` int(11) NOT NULL,
  `checked_out` int(11) NOT NULL,
  `ordering` int(11) NOT NULL,
  
   PRIMARY KEY  (`id`)
);




 CREATE TABLE IF NOT EXISTS `#__rquotes` LIKE bac_rquotes;
 INSERT INTO `#__rquotes` SELECT*  FROM `bac_rquotes`;ALTER TABLE `#__rquotes` ADD COLUMN `record_date`  datetime NOT NULL  ;
ALTER TABLE `#__rquotes` ADD COLUMN `display_date`  varchar(10)  NOT NULL;


  
 DROP TABLE IF EXISTS `#__rquotes_meta`;

CREATE TABLE `#__rquotes_meta` (
  `id` int(11) NOT NULL DEFAULT '0',
  `number_reached` mediumint(9) NOT NULL DEFAULT '0',
  `date_modified` mediumint(9) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



--
-- Dumping data for table `#__rquotes_meta`
--

INSERT INTO `#__rquotes_meta` (`id`, `number_reached`, `date_modified`) VALUES
(1, 1, 1);
