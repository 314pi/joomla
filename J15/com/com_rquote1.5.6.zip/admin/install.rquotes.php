<?php
/**
 * @version		1.5.6
 * @package		Joomla
 * @subpackage	Rquotes
 * @copyright	Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.
 * @license		GPLv2.0, see LICENSE.php
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 */
defined( '_JEXEC' ) or die( 'Restricted access' );

function com_install()
{
	?>
	
<div class="header">
  <div align="center">
    <h3>Congratulations, Your RQUOTES Component has been installed or upgraded 
      .</h3>
    <h3>Version 1.5.6 now installed</h3>
    <p align="left"><strong>Please see help file for details on the uses of Rquotes 
      component , module and plugins.</strong></p>
  </div>
</div>
	
<p><strong><font color="#000000">New to this version:<br>
  1)added date field to be used in search plugin avaiable at </font></strong><strong><font color="#000000"><a href="http://www.mytidbits.us/joomla173/downloads" target="_blank"> 
  http://www.mytidbits.us/downloads</a><br>
  2) </font></strong><strong><font color="#000000">Added display date field used 
  to display events by date in module.</font></strong></p>
<p><font color="#000000"><strong> To get started, navigate to Components, Rquotes, 
  and click on "Manage Categories","New" and enter a name and optional description. 
  Save it and go to "List Quotes","New&quot; and enter your information. All fields 
  are optional.(***See Help***)Also, be sure to install the latest version of 
  the module ( mod_rquotes 1.5.6 available at <a href="http://www.mytidbits.us/joomla173/downloads" target="_blank">http://www.mytidbits.us/downloads</a> 
  to promote your Random, Quotes,Riddles,etc throughout your website! </strong></font></p>
<?php
}

?>