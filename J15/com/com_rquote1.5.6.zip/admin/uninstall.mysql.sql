DROP TABLE IF EXISTS `bac_rquotes`;
CREATE TABLE IF NOT EXISTS`bac_rquotes` LIKE `#__rquotes`;
 INSERT INTO `bac_rquotes` SELECT * FROM `#__rquotes`;


DROP TABLE IF EXISTS  `#__rquotes`;
DROP TABLE IF EXISTS `#__rquotes_meta`;
DROP TABLE IF EXISTS `#__rquotes_categories`;