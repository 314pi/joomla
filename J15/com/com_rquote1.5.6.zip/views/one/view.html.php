<?php

defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.application.component.view');

class ViewOne extends JView
{
	function display($tpl = null)
	{
		global $option, $mainframe;
		
		$model =& $this->getModel();
	//	$user =& JFactory::getUser();

		$rquote = $model->getRquote();

		$pathway =& $mainframe->getPathWay();
		
//		$backlink = JRoute::_('index.php?option=' . $option . '&view=all' );
		
		$params = &$mainframe->getParams();

		
		
		$pathway->addItem($rquote->quote, '');
		
		$this->assignRef('rquote', $rquote);
//		$this->assignRef('comments', $comments);
//		$this->assignRef('backlink', $backlink);
		$this->assignRef('option', $option);
//		$this->assignRef('name', $user->name);

		
		parent::display($tpl);
	}
}

?>