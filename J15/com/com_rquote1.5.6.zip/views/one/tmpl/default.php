<?php defined( '_JEXEC' ) or die( 'Restricted access' ); ?> 
<p class="contentheading"> 
  <?php echo $this->rquote->quote; ?> 
</p> 

<p> 
  <?php echo $this->rquote->author; ?> 
</p> 
<p class="notes"> 
  <?php echo $this->rquote->notes; ?> 
</p>  
