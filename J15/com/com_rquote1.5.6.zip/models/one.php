<?php 
defined( '_JEXEC' ) or die( 'Restricted access' ); 

jimport( 'joomla.application.component.model' ); 

class ModelRquotesOne extends JModel 
{
	var $_rquote = null; 

	var $_id = null; 

	function __construct() 
	{ 
		parent::__construct(); 
		$id = JRequest::getVar('id', 0); 
		$this->_id = $id; 
	} 

	function getRquote() 
	{ 
		if(!$this->_rquote) 
		{ 
	
	$query = "SELECT * FROM #__rquotes WHERE id = '" . $this->_id . "'"; 
			$this->_db->setQuery($query); 
			$this->_rquote = $this->_db->loadObject();
			 
			if(!$this->_rquote->published) 
			{ 
				JError::raiseError( 404, "Invalid ID provided" ); 
			} 
		}
		
		return $this->_rquote; 
	} 

	
} 

?>

