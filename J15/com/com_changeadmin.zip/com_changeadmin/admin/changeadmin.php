<?php
/**
 * Component com_changeadmin
 * @copyright	Copyright (C) 2010 Ribamar FS.
 * @license		GNU/GPL, see http://www.gnu.org/licenses/old-licenses/gpl-2.0.txt
 * JoomInstaller is free and open source software. This version may have been modified 
 * pursuant to the GNU General Public License, and as distributed it includes or is 
 * derivative of works licensed under the GNU General Public License or other free or 
 * open source software licenses. 
 * http://ribafs.org
*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

require_once( JPATH_COMPONENT.DS.'changeadmin.html.php' );

jimport( 'joomla.application.helper' );
jimport('joomla.filesystem.file');
jimport('joomla.filesystem.folder');

upd();

function upd()
{
	$subupd = JRequest::getVar('submit') ;

	if(isset($subupd)){
		$new_directory = JRequest::getVar( 'new_directory');

		$new_directory = JPATH_ROOT.DS.$new_directory;
		$new_directory = JFolder::makeSafe($new_directory);
		if(file_exists($new_directory)){
			//
		}else{
			JFolder::create($new_directory);
		}

		// In new directory create a index.php
		$index_newadmin ="<?php
\$admin_cookie_code=\"1234567890\";
setcookie(\"JoomlaAdminSession\",\$admin_cookie_code,0,\"/\");
header(\"Location: ../administrator/index.php\");
?>
";
	
		$new_index = $new_directory.DS.'index.php';
		if(file_exists($new_index)){
			//
		}else{
			$fp = fopen($new_index, "w");
			$wrt = fwrite($fp, $index_newadmin);
			// close file
			fclose($fp);
		}
		
		// In administrator create .htaccess if not exists. Append if exists to start of file
		$htaccess_admin_add ="RewriteEngine On
RewriteCond %{REQUEST_URI} ^/administrator
RewriteCond %{HTTP_COOKIE} !JoomlaAdminSession=1234567890
RewriteRule .* - [L,F]
";

		$htaccess_admin = JPATH_ROOT.DS.'administrator'.DS.'.htaccess';

		if(file_exists($htaccess_admin)){
			JFile::copy($htaccess_admin, $htaccess_admin.'.backup');
			JFile::move($htaccess_admin, $new_directory.DS.'.htaccess');
		}

		$fp = fopen($htaccess_admin, "w");
		$wrt = fwrite($fp, $htaccess_admin_add);
		// close file
		fclose($fp);

		// In administrator append to start of index.php
$index_admin_add ="<?php
/**
* @version		\$Id: index.php 14401 2010-01-26 14:10:00Z louis $
* @package		Joomla
* @copyright	Copyright (C) 2005 - 2010 Open Source Matters. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* Joomla! is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/

// Set flag that this is a parent file
define( '_JEXEC', 1 );

if (@\$_COOKIE['JoomlaAdminSession'] != \"1234567890\")
{
	?><script>location='../index.php';</script><?;
}

define('JPATH_BASE', dirname(__FILE__) );

define('DS', DIRECTORY_SEPARATOR);

require_once( JPATH_BASE .DIRECTORY_SEPARATOR.'includes'.DIRECTORY_SEPARATOR.'defines.php' );
require_once( JPATH_BASE .DIRECTORY_SEPARATOR.'includes'.DIRECTORY_SEPARATOR.'framework.php' );
require_once( JPATH_BASE .DIRECTORY_SEPARATOR.'includes'.DIRECTORY_SEPARATOR.'helper.php' );
require_once( JPATH_BASE .DIRECTORY_SEPARATOR.'includes'.DIRECTORY_SEPARATOR.'toolbar.php' );

JDEBUG ? \$_PROFILER->mark( 'afterLoad' ) : null;

/**
 * CREATE THE APPLICATION
 *
 * NOTE :
 */
\$mainframe =& JFactory::getApplication('administrator');

/**
 * INITIALISE THE APPLICATION
 *
 * NOTE :
 */
\$mainframe->initialise(array(
	'language' => \$mainframe->getUserState( \"application.lang\", 'lang' )
));

JPluginHelper::importPlugin('system');

// trigger the onAfterInitialise events
JDEBUG ? \$_PROFILER->mark('afterInitialise') : null;
\$mainframe->triggerEvent('onAfterInitialise');

/**
 * ROUTE THE APPLICATION
 *
 * NOTE :
 */
\$mainframe->route();

// trigger the onAfterRoute events
JDEBUG ? \$_PROFILER->mark('afterRoute') : null;
\$mainframe->triggerEvent('onAfterRoute');

/**
 * DISPATCH THE APPLICATION
 *
 * NOTE :
 */
\$option = JAdministratorHelper::findOption();
\$mainframe->dispatch(\$option);

// trigger the onAfterDispatch events
JDEBUG ? \$_PROFILER->mark('afterDispatch') : null;
\$mainframe->triggerEvent('onAfterDispatch');

/**
 * RENDER THE APPLICATION
 *
 * NOTE :
 */
\$mainframe->render();

// trigger the onAfterRender events
JDEBUG ? \$_PROFILER->mark( 'afterRender' ) : null;
\$mainframe->triggerEvent( 'onAfterRender' );

/**
 * RETURN THE RESPONSE
 */
echo JResponse::toString(\$mainframe->getCfg('gzip'));
?>

";

		$index_admin = JPATH_ROOT.DS.'administrator'.DS.'index.php';

		$fp = fopen($index_admin, "w");
		$wrt = fwrite($fp, $index_admin_add);
		// close file
		fclose($fp);

		//Credits: Créditos: http://www.joomlahackers.net/joomla-tutorials/change-joomla-admin-name-or-path.html

	}
 	OutputChangeadmin::updChangeadmin();
	
}// end function upd()

?>
