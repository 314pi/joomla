<?php
/**
 * Component com_changeadmin
 * @copyright	Copyright (C) 2010 Ribamar FS.
 * @license		GNU/GPL, see http://www.gnu.org/licenses/old-licenses/gpl-2.0.txt
 * JoomInstaller is free and open source software. This version may have been modified 
 * pursuant to the GNU General Public License, and as distributed it includes or is 
 * derivative of works licensed under the GNU General Public License or other free or 
 * open source software licenses. 
 * http://ribafs.org
*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.helper' );
jimport('joomla.filesystem.file');
jimport('joomla.filesystem.folder');

jimport( 'joomla.application.application' );

class OutputChangeadmin
{
function updChangeadmin(){  
	?>
	<h2 class="moduletable">Change Administrator Directory</h2>
	<div align="left">
	 
	<form id="form1" name="form1" method="post" action="index.php?option=com_changeadmin">
		<br>
		<table border="0">
		<tr><td>New Directory</td><td><input type="text" name="new_directory" size="20" maxlength="50" value="adminxwh"></td></tr>
		<tr><td>&nbsp;</td><td><input type="submit" name="submit" value="Change" /></td></tr>
		</table>
	</form>
	<br>
</div>
<?php
	
	$submit = JRequest::getVar('submit');
	$nd = JRequest::getVar('new_directory');
	if(isset($submit)){
		JFactory::getApplication()->enqueueMessage( 'Directory administrator changed to '.$nd.' Logout to enter a new admin: '.$nd,'message');
		JFactory::getApplication()->enqueueMessage( 'LOGOUT now and LOGIN in new '.$nd,'error');
	}

}// End function

}// End class 

?>
