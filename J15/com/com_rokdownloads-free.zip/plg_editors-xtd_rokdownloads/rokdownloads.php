<?php
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin' );

/**
 * Editor Image buton
 *
 * @package Editors-xtd
 * @since 1.5
 */
class plgButtonRokDownloads extends JPlugin
{
	/**
	 * Constructor
	 *
	 * For php4 compatability we must not use the __constructor as a constructor for plugins
	 * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
	 * This causes problems with cross-referencing necessary for the observer design pattern.
	 *
	 * @param 	object $subject The object to observe
	 * @param 	array  $config  An array that holds the plugin configuration
	 * @since 1.5
	 */
	function plgButtonRokDownloads(& $subject, $config)
	{
		parent::__construct($subject, $config);
	}

	/**
	 * Display the button
	 *
	 * @return array A two element array of ( imageName, textToInsert )
	 */
	function onDisplay($name)
	{
		global $mainframe;

		$doc 		=& JFactory::getDocument();
		$template 	= $mainframe->getTemplate();

		/* @var $doc JDocumentHTML */
		
		
//		$declaration	= 
//		"function jSelectArticle(id, title, object) {
//			var content 		= tinyMCE.getContent();
//			
//			var articlehref = 'index.php?option=com_content&view=article&id='+id;
//			var articlelink = ' <a href=\"'+articlehref+'\">'+title+'</a> ';
//
//			jInsertEditorText( articlelink, 'text' );
//			document.getElementById('sbox-window').close();
//		}
//	";
//		
//		
//		$doc->addScriptDeclaration($declaration);
		
		$declaration	="
		.button2-left .rokdownload 	{ background: url(components/com_rokdownloads/assets/images/editor_button.png) 100% 0 no-repeat; } ";
		
		$doc->addStyleDeclaration($declaration);

		$link = 'index.php?option=com_rokdownloads&amp;task=select&amp;tmpl=component&amp;e_name='.$name;

		JHTML::_('behavior.modal');

		$button = new JObject();
		$button->set('modal', true);
		$button->set('link', $link);
		$button->set('text', JText::_('RokDownload Link'));
		$button->set('name', 'rokdownload');
		$button->set('options', "{handler: 'iframe', size: {x: 650, y: 400}}");

		return $button;
	}
}