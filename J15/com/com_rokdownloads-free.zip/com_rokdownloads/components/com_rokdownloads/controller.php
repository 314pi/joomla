<?php
/**
 * @version $Id: controller.php 18489 2010-02-03 00:44:48Z btowles $
 * @package RocketTheme
 * @subpackage	RokDownloads
 * @copyright Copyright (C) 2008 RocketWerx. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport('joomla.application.component.controller');

/**
 * @package		RocketTheme
 * @subpackage	RokDownloads
 *
 * @since 1.5
 */
class RokdownloadsController extends JController
{
	function display()
	{
		global $mainframe;

		$vName = JRequest::getCmd('task', 'display');
		switch ($vName)
		{
            case 'view':
            case 'display':
                parent::display();
                break;
			case 'select':
			default:
                JHTML::_('behavior.mootools');
				$mName = 'select';
				$vName = 'select';
                $document = &JFactory::getDocument();
                $vType		= $document->getType();

                // Get/Create the view
                $view = &$this->getView($vName, $vType);
                
                $view->addTemplatePath(JPATH_COMPONENT_ADMINISTRATOR.DS.'views'.DS.strtolower($vName).DS.'tmpl');

                // Get/Create the model
                if ($model = &$this->getModel($mName)) {
                    // Push the model into the view (as default)
                    $view->setModel($model, true);
                }
                // Display the view
                $view->display();
				break;
		}
	}
}
