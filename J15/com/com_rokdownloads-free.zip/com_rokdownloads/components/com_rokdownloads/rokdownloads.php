<?php
/**
 * @version $Id: rokdownloads.php 20138 2010-03-16 14:49:23Z btowles $
 * @package RocketTheme
 * @subpackage	RokDownloads
 * @copyright Copyright (C) 2008 RocketWerx. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

/*
 * Make sure the user is authorized to view this page
 */

// Require the base controller
require_once (JPATH_COMPONENT.DS.'controller.php');
require_once (JPATH_COMPONENT.DS.'views'.DS.'view.html.php' );

// Require specific controller if requested
if(!$controller_name = JRequest::getVar('controller')) {
	$controller_name = "rokdownloads"; //if no controller specified, set to default controller
}

// Create the controller
switch($controller_name){
    case "rokdownloads":
        $classname = "RokdownloadsControllerRokdownloads";
        $classfile = "rokdownloads";
        break;
    default:
        exit;
}

require_once (JPATH_COMPONENT.DS.'controllers'.DS.$classfile.'.php');
$controller = new $classname( );

$controller->addViewPath(JPATH_COMPONENT_ADMINISTRATOR.DS.'views');
$controller->addModelPath(JPATH_COMPONENT_ADMINISTRATOR.DS.'models');

// Perform the Request task
$controller->execute( JRequest::getVar('task'));

// Redirect if set by the controller
$controller->redirect();