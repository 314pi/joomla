<?php

/**
 * @version $Id: folder.php 18489 2010-02-03 00:44:48Z btowles $
 * @package RocketTheme
 * @subpackage	RokDownloads
 * @copyright Copyright (C) 2008 RocketWerx. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport('joomla.application.component.model');
jimport('joomla.utilities.date');
include ('downloadItem.php');

/**
 *
 * @package		RocketTheme
 * @subpackage	RokDownloads
 *
 * @since 1.5
 */
class RokdownloadsModelFolder extends RokdownloadsModelDownloadItem {
	var $NODE_TYPE_FILE = 0;
	var $NODE_TYPE_FOLDER = 1;

	var $_folder = null;
	var $_params = null;

	/**
	 * Constructor
	 *
	 * @since 1.5
	 */
	function __construct() {
		global $mainframe;
		parent::__construct();

		$id = JRequest::getVar('id', 0, '', 'int');
		$this->setId((int)$id);
		$this->_params = &$mainframe->getParams();

	}

	/**
	 * Overridden set method to pass properties on to the article
	 *
	 * @access	public
	 * @param	string	$property	The name of the property
	 * @param	mixed	$value		The value of the property to set
	 * @return	boolean	True on success
	 * @since	1.5
	 */
	function set($property, $value = null) {
		if ($this->_loadFolder()) {
			$this->_folder-> $property = $value;
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Overridden get method to get properties from the article
	 *
	 * @access	public
	 * @param	string	$property	The name of the property
	 * @param	mixed	$value		The value of the property to set
	 * @return 	mixed 				The value of the property
	 * @since	1.5
	 */
	function get($property, $default = null) {
		if ($this->_loadFolder()) {
			if (isset ($this->_folder-> $property)) {
				return $this->_folder-> $property;
			}
		}
		return $default;
	}

	/**
	 * Method to get content article data for the frontpage
	 *
	 * @since 1.5
	 */
	function & getFolder() {

		if ($this->_loadFolder()) {
			$user = & JFactory :: getUser();
			$this->_loadNodeParams($this->_folder, true);
		} else {
			$user = & JFactory :: getUser();
			$folder = & JTable :: getInstance('rokdownloads');
			$folder->state = 1;
			$folder->author = null;
			$folder->created_by = $user->get('id');
			$folder->parameters = new JParameter('');
			$folder->text = '';
			$folder->subfolders = array ();
			$folder->files = array ();
			$folder->count_subfolders = 0;
			$folder->count_files = 0;
			$folder->parent = null;
			$folder->alias = '';
			$this->_folder = $folder;

		}

		return $this->_folder;
	}

	/**
	 * Method to load content article data
	 *
	 * @access	private
	 * @return	boolean	True on success
	 * @since	1.5
	 */
	function _loadFolder() {
		global $mainframe;

		if ($this->_id == '0') {
			return false;
		}

		// Load the content if it doesn't already exist
		if (empty ($this->_folder)) {
			// Get the page/component configuration

			// Get the WHERE clause
			$where = $this->_buildFolderWhere();

			$query = 'SELECT a.*, u.name AS author, u.usertype, ' .
			' g.name AS groups ' .
			' FROM #__rokdownloads AS a' .
			' LEFT JOIN #__users AS u ON u.id = a.created_by' .
			' LEFT JOIN #__groups AS g ON a.access = g.id' .
			$where;

			$this->_db->setQuery($query);
			$this->_folder = $this->_db->loadObject();

			// make sure query worked			
			if ($this->_db->getErrorMsg() != '') {
				$this->setError($this->_db->getErrorMsg());
				return false;
			}

			// make sure we got a folder
			if (!$this->_folder) {
				$this->setError("Did not return a folder object");
				return false;
			}

			// load the sub folders
			$this->_folder->subfolders = array ();
			if ($this->_params->get('subfolders_show')) {
				$this->_folder->subfolders = & $this->_loadSubNodes($this->NODE_TYPE_FOLDER);
				if ($this->_folder->subfolders === false) {
					return false;
				}
			}

			// load the files in the folder
			$this->_folder->files = & $this->_loadSubNodes($this->NODE_TYPE_FILE);
			if ($this->_folder->files === false) {
				return false;
			}

			// load the parent info
			$this->_folder->parent = & $this->_loadParentNode();
			if ($this->_folder->parent === false) {
				return false;
			}
		}
		return true;
	}

	function _loadParentNode() {
		$user = & JFactory :: getUser();
		$aid = (int) $user->get('aid', 0);
		$menus = & JSite :: getMenu();
		$menu = $menus->getActive();
		$view = 'folder';
		$parent = null;

		//get the parent id of the folder
		$query = 'select a.*, u.name AS author, u.usertype,  g.name AS groups FROM #__rokdownloads AS a' . ' LEFT JOIN #__users AS u ON u.id = a.created_by' . ' LEFT JOIN #__groups AS g ON a.access = g.id' . ' where a.id = ' . '(select MAX(parent.id) as parent from #__rokdownloads as node, #__rokdownloads as parent where node.lft >= parent.lft and node.lft <= parent.rgt and node.id = ' . (int) $this->_id . ' and parent.id != ' . (int) $this->_id . ' order by parent.lft)' . ' AND a.access <= ' . (int) $aid . ' AND a.published = 1';

		$this->_db->setQuery($query);
		$this->_db->query();

		// make sure query worked	
		if ($this->_db->getErrorMsg() != '') {
			$this->setError($this->_db->getErrorMsg());
			return false;
		}

		if ($this->_db->getNumRows() >= 1) {
			$parent = $this->_db->loadObject();
			$parent->detail_link = "index.php?option=com_rokdownloads&view=" . $view . "&Itemid=" . $menu->id . "&id=" . RokdownloadsModelDownloadItem :: getSlug($parent);
		}

		return $parent;

	}

	function _loadSubNodes($type = 0) {
		$user = & JFactory :: getUser();
		$aid = (int) $user->get('aid', 0);
		$menus = & JSite :: getMenu();
		$menu = $menus->getActive();

		$sub_file_counts = array ();
		$sub_folder_counts = array ();

		// Get the pagination request variables
		$limit = JRequest :: getVar('limit', 0, '', 'int');
		$limitstart = JRequest :: getVar('limitstart', 0, '', 'int');

		$accesswhere = " (a.folder = 1 AND a.access <= " . $aid . ") OR a.folder = 0 ";

		$empty_where = "";
		if ((!$this->_params->get('subfolders_show_empty')) && $type == $this->NODE_TYPE_FOLDER) {
			$empty_where = " and (a.rgt - a.lft) > 1 ";
		}

		$query = "select a.*, u.name AS author, u.usertype,  g.name AS groups   from " .
		" (SELECT node.*, (COUNT(parent.name) - (sub_tree.depth + 1)) AS depth " .
		" FROM #__rokdownloads AS node,#__rokdownloads AS parent,#__rokdownloads AS sub_parent," .
		" (SELECT node.id, (COUNT(parent.name) - 1) AS depth FROM #__rokdownloads AS node,#__rokdownloads AS parent" .
		" WHERE node.lft >= parent.lft AND node.lft <= parent.rgt" .
		" AND node.id = " . $this->_id .
		" GROUP BY node.id ORDER BY node.lft ) AS sub_tree" .
		" WHERE node.lft >= parent.lft AND node.lft <= parent.rgt AND node.lft >= sub_parent.lft" .
		" AND node.lft <= sub_parent.rgt AND sub_parent.id = sub_tree.id and node.published = 1 and node.folder = " . $type .
		" GROUP BY node.id HAVING depth = 1 ORDER BY node.lft) as a" .
		" LEFT JOIN #__users AS u ON u.id = a.created_by" .
		" LEFT JOIN #__groups AS g ON a.access = g.id" .
		" WHERE " . $accesswhere . $empty_where;

		$nodes = array ();

		if ($type == $this->NODE_TYPE_FILE) {
			$this->_folder->count_files = $this->_getListCount($query);

			$all_nodes = $this->_getList($query);
			if ($this->_db->getErrorMsg() != '') {
				$this->setError($this->_db->getErrorMsg());
				$nodes = array ();
				return false;
			}

			$this->_sort_nodes($all_nodes, $this->_params->get('files_sort_order', 'original'));
			if ($limit > 0) {
				$i = 0;
				foreach ($all_nodes as $node) {
					if ($i >= $limitstart && $i < ($limitstart + $limit)) {
						$nodes[$i] = $node;
					}
					$i++;
				}
			} else {
				$nodes = $all_nodes;
			}
		} else {
			$this->_folder->count_subfolders = $this->_getListCount($query);
			$nodes = $this->_getList($query);

			if ($this->_db->getErrorMsg() != '') {
				$this->setError($this->_db->getErrorMsg());
				$nodes = array ();
				return false;
			}
			
			$this->_sort_nodes($nodes, $this->_params->get('subfolder_sort_order', 'original'));

			// get the list of all folders and thier sub folder counts
			$query = "SELECT parent.id as id, COUNT(downloads.id)-1 as count " .
			"FROM #__rokdownloads AS node, " .
			"#__rokdownloads AS parent, " .
			"#__rokdownloads as downloads " .
			"WHERE node.lft >= parent.lft AND node.lft <= parent.rgt " .
			"and node.folder=1 " .
			"AND node.id = downloads.id " .
			"AND node.published = 1 " .
			"AND node.access <= " . $aid . " " .
			"GROUP BY parent.id " .
			"ORDER BY node.lft";
			$this->_db->setQuery($query);
			$sub_folder_counts = $this->_db->loadAssocList("id");
			if ($this->_db->getErrorMsg() != '') {
				$this->setError($this->_db->getErrorMsg());
				$sub_folder_counts = array ();
				return false;
			}

			// Get the list of folders and thier file counts
			$query = "SELECT parent.id as id, COUNT(downloads.id) as count " .
			"FROM #__rokdownloads AS node, " .
			"#__rokdownloads AS parent, " .
			"#__rokdownloads as downloads " .
			"WHERE node.lft >= parent.lft AND node.lft <= parent.rgt " .
			"and node.folder=0 " .
			"and node.published=1 " .
			"and parent.folder=1 " .
			"and parent.published=1 " .
			"and parent.access <= " . $aid . " " .
			"AND node.id = downloads.id " .
			"GROUP BY parent.id " .
			"ORDER BY node.lft ";

			$this->_db->setQuery($query);
			$sub_file_counts = $this->_db->loadAssocList("id");
			if ($this->_db->getErrorMsg() != '') {
				$this->setError($this->_db->getErrorMsg());
				$sub_file_counts = array ();
				return false;
			}

			// Find the count of no access files based on the folder not having access
			$no_access_sub_file_counts = array ();
			$query = "SELECT parent.id as id, COUNT(downloads.id) as count " .
			"FROM #__rokdownloads AS node, " .
			"#__rokdownloads AS parent, " .
			"#__rokdownloads as downloads " .
			"WHERE node.lft >= parent.lft AND node.lft <= parent.rgt " .
			"and node.folder=0 " .
			"and node.published=1 " .
			"and parent.folder=1 " .
			"and parent.published=1 " .
			"and parent.access > " . $aid . " " .
			"AND node.id = downloads.id " .
			"GROUP BY parent.id " .
			"ORDER BY node.lft ";
			$this->_db->setQuery($query);
			$no_access_sub_file_counts = $this->_db->loadAssocList("id");
			if ($this->_db->getErrorMsg() != '') {
				$this->setError($this->_db->getErrorMsg());
				$no_access_sub_file_counts = array ();
				return false;
			}

			//Get the child folder and thier parents relationships
			$child_parent_relationships = array ();
			$query = "select node.id as child, parent.id as parent " .
			"from #__rokdownloads as node, " .
			"#__rokdownloads AS parent " .
			"WHERE node.lft > parent.lft AND node.lft < parent.rgt " .
			"AND node.folder=1 " .
			"and node.published=1 " .
			"and parent.folder=1 " .
			"and parent.published=1 " .
			"order by node.lft ";
			$this->_db->setQuery($query);
			$child_parent_relationships = $this->_db->loadObjectList();
			if ($this->_db->getErrorMsg() != '') {
				$this->setError($this->_db->getErrorMsg());
				$child_parent_relationships = array ();
				return false;
			}

			if (count($no_access_sub_file_counts) > 0) {
				foreach ($no_access_sub_file_counts as $nakey => $naval) {
					foreach ($child_parent_relationships as $cpobject) {
						if ($cpobject->child == $nakey) {
							if (array_key_exists($cpobject->parent, $sub_file_counts)) {
								$parentid = $cpobject->parent;
								if ($sub_file_counts[$parentid]['count'] >= $naval['count']) {
									$sub_file_counts[$parentid]['count'] = $sub_file_counts[$parentid]['count'] - $naval['count'];
								} else {
									$sub_file_counts[$parentid]['count'] = 0;
								}
							}
						}
					}
				}
			}
		}

		foreach ($nodes as $nk => $nv) {
			$node = & $nodes[$nk];
			$this->_loadNodeParams($node, false);
			// put in link for drill down
			if ($node->folder) {
				$view = "folder";

				if (array_key_exists($node->id, $sub_folder_counts)) {
					$node->count_subfolders = $sub_folder_counts[$node->id]['count'];
				} else {
					$node->count_subfolders = 0;
				}

				if (array_key_exists($node->id, $sub_file_counts)) {
					$node->count_files = $sub_file_counts[$node->id]['count'];
				} else {
					$node->count_files = 0;
				}
			} else {
				$view = "file";
				$node->filesize = $this->_filesize_format($node->filesize);

				// Set the download URL
				$node->download_link = "index.php?option=com_rokdownloads&view=" . $view . "&task=download&id=" . RokdownloadsModelDownloadItem :: getSlug($node);

			}
			$node->detail_link = "index.php?option=com_rokdownloads&view=" . $view . "&Itemid=" . $menu->id . "&id=" . RokdownloadsModelDownloadItem :: getSlug($node);
		}
		return $nodes;
	}

	/**
	 * Method to load content folder parameters
	 *
	 * @access	private
	 * @return	void
	 * @since	1.5
	 */
	function _loadNodeParams(& $node, $top_level) {
		global $mainframe;

		// Get the page/component configuration
		$params = clone ($mainframe->getParams('com_rokdownloads'));

		//Adjust Parameters
		$this->_file->parameters = array ();
		if (0 < strlen($node->params)) {
			// Get the item parameters
			$item_params = new JParameter($node->params);
			$item_params->loadSetupFile(JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_rokdownloads' . DS . 'custom_params.xml');
			$tempparams = $item_params->renderToArray();
			foreach ($tempparams as $pval) {
				$node->parameters[$pval[3]] = $pval[4];
			}
		}

		// Get the item parameters
		$item_params = new JParameter($node->params);
		//Adjust Parameters
		$node->parameters = array ();
		if (0 < strlen($node->params)) {
			$node->parameters = $item_params->toArray();
		}

		$params->merge($item_params);

		// Set the popup configuration option based on the request
		$pop = JRequest :: getVar('pop', 0, '', 'int');
		$params->set('popup', $pop);

		// Are we showing introtext with the article
		if (!$top_level) {
			$node->text = $node->introtext;
		} else {
			if ($params->get('subfolders_show_intro')) {
				$node->text = $node->introtext . chr(13) . chr(13) . $node->fulltext;
			} else {
				$node->text = $node->fulltext;
			}
		}

		//set the alias
		$node->alias = $this->_getAlias($node);

		$thumbfolder = JURI :: base() . $params->get("thumbnail_folder");

		// Adjust Thumbnail path
		if (0 < strlen($node->thumbnail)) { //default values
			$node->thumbpath = $thumbfolder ."/".$node->thumbnail;
			$node->thumb_tag = "<img src='" . $node->thumbpath . "' alt='" . $node->thumbnail . "' />";
		}
		elseif ($params->get('display_default_thumbnails', 1) == 1) {
			$node->thumbnail = $node->folder ? $params->get('default_folder_thumb') : $params->get('default_file_thumb');
			$node->thumbpath = $thumbfolder ."/".$node->thumbnail;
			$node->thumb_tag = "<img src='" . $node->thumbpath . "' alt='" . $node->thumbnail . "' />";
		} else {
			$node->thumb_tag = "";
		}

		if (!$node->folder) {
			$node->new = false;
			if ($params->get('files_show_new_flag')) {
				$daysdiff = (time() - strtotime($node->created_time)) / 60 / 60 / 24;
				if ((int) $params->get('files_new_flag_days') > $daysdiff) {
					$node->new = true;
				}
			}

			$node->updated = false;
			if ($params->get('files_show_updated_flag')) {
				$daysdiff = (time() - strtotime($node->modified_time)) / 60 / 60 / 24;
				if ($params->get('files_updated_flag_days') > $daysdiff) {
					$node->updated = true;
				}
			}

			$node->hot = false;
			if ($params->get('files_show_hot_flag')) {
				if ($node->downloads >= $params->get('files_hot_flag_minimum')) {
					$node->hot = true;
				}
			}

		}
	}

	/**
	 * Method to build the WHERE clause of the query to select a content article
	 *
	 * @access	private
	 * @return	string	WHERE clause
	 * @since	1.5
	 */
	function _buildFolderWhere() {
		global $mainframe;

		$user = & JFactory :: getUser();
		$aid = (int) $user->get('aid', 0);

		jimport('joomla.utilities.date');
		$jnow = new JDate();
		$now = $jnow->toMySQL();
		$nullDate = $this->_db->getNullDate();

		/*
		 * First thing we need to do is assert that the content article is the one
		 * we are looking for and we have access to it.
		 */
		$where = ' WHERE a.id = ' . (int) $this->_id;
		$where .= ' AND a.access <= ' . (int) $aid;
		$where .= ' AND a.published = 1';

		return $where;
	}

	/**
	 * Format a number of bytes into a human readable format.
	 * Optionally choose the output format and/or force a particular unit
	 *
	 * @param   int     $bytes      The number of bytes to format. Must be positive
	 * @param   string  $format     Optional. The output format for the string
	 * @param   string  $force      Optional. Force a certain unit. B|KB|MB|GB|TB
	 * @return  string              The formatted file size
	 */
	function _filesize_format($bytes, $format = '', $force = '') {
		$force = strtoupper($force);
		$defaultFormat = '%01d %s';
		if (strlen($format) == 0)
			$format = $defaultFormat;

		$bytes = max(0, (int) $bytes);

		$units = array (
			'B',
			'KB',
			'MB',
			'GB',
			'TB',
			'PB'
		);

		$power = array_search($force, $units);

		if ($power === false)
			$power = $bytes > 0 ? floor(log($bytes, 1024)) : 0;

		if (0 == $power)
			$format = $defaultFormat;
		return sprintf($format, $bytes / pow(1024, $power), $units[$power]);
	}

	function _sort_nodes(& $nodes, $sort_type) {
		switch ($sort_type) {
			case "alpha" :
				usort($nodes, "displayname_cmp");
				break;
			case "ralpha" :
				usort($nodes, "rev_displayname_cmp");
				break;
			case "falpha" :
				usort($nodes, "filename_cmp");
				break;
			case "rfalpha" :
				usort($nodes, "rev_filename_cmp");
				break;
			case "modified" : 
				usort($nodes, "modified_date_cmp");
				break;
			case "rmodified" : 
				usort($nodes, "rev_modified_date_cmp");
				break;
			case "created" : 
				usort($nodes, "created_date_cmp");
				break;
			case "rcreated" : 
				usort($nodes, "rev_created_date_cmp");
				break;
		}
	}
}

function displayname_cmp($a, $b) {
	return rokdl_string_cmp($a->displayname, $b->displayname, false);
}

function rev_displayname_cmp($a, $b) {
	return rokdl_string_cmp($a->displayname, $b->displayname, true);
}

function filename_cmp($a, $b) {
	return rokdl_string_cmp($a->name, $b->name, false);
}

function rev_filename_cmp($a, $b) {
	return rokdl_string_cmp($a->name, $b->name, true);
}

function modified_date_cmp($a, $b) {
	return rokdl_date_cmp($a->modified_time, $b->modified_time, false);
}

function rev_modified_date_cmp($a, $b) {
	return rokdl_date_cmp($a->modified_time, $b->modified_time, true);
}

function created_date_cmp($a, $b) {
	return rokdl_date_cmp($a->created_time, $b->created_time, false);
}

function rev_created_date_cmp($a, $b) {
	return rokdl_date_cmp($a->created_time, $b->created_time, true);
}

function rokdl_string_cmp($a, $b, $reverse = false) {
	if (strtoupper($a) == strtoupper($b)) {
		return 0;
	}
	if (!$reverse) 
		return (strtoupper($a) < strtoupper($b)) ? -1 : 1;
	else
		return (strtoupper($a) > strtoupper($b)) ? -1 : 1;
}

function rokdl_date_cmp($a, $b, $reverse = false) {
	$a_date = new JDate($a);
	$b_date = new JDate($b);
	
	$a_ts = $a_date->toUnix();
	$b_ts = $b_date->toUnix();
	
	if ($a_ts == $b_ts) {
		return 0;
	} 
	if (!$reverse) 
		return ($a_ts < $b_ts)? -1 : 1;
	else
		return ($a_ts > $b_ts)? -1 : 1;
}
