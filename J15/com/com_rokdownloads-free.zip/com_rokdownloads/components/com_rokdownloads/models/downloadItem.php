
<?php
/**
 * @version $Id: file.php 4437 2008-05-05 22:57:58Z wonderslug $
 * @package RocketTheme
 * @subpackage	RokDownloads
 * @copyright Copyright (C) 2008 RocketWerx. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport('joomla.application.component.model');

/**
 * @package		RocketTheme
 * @subpackage	RokDownloads
 *
 * @since 1.5
 */
class RokdownloadsModelDownloadItem extends JModel
{
	var $_id = 0;
	
	/**
	 * Method to set the id
	 *
	 * @access	public
	 * @param	int	Article ID number
	 */
	function setId($id)
	{
		// Set new article ID and wipe data
		$id_a = explode( ':', $id );
		$this->_id		= $id_a[0];
		$this->_file	= null;
	}
	
	function getId() {
		return $this->_id;
	}
	
    function getParents($top_level_parent = 1) {
    	$menus = &JSite::getMenu();
		$menu  = $menus->getActive();
		
    	$query = 'select p.*, u.name AS author, u.usertype,  g.name AS groups,' 
    			. ' " "  as detail_link from'
    		  	. ' (SELECT parent.* FROM #__rokdownloads AS node, #__rokdownloads AS parent' 
    			. ' WHERE node.lft > parent.lft AND node.lft < parent.rgt AND node.id = '. $this->_id
    			. ' and parent.id in (select b.id from #__rokdownloads as b  where b.lft >= (select a.lft from #__rokdownloads as a where a.id = ' . $top_level_parent .')) ORDER BY parent.lft) p'
    			. ' LEFT JOIN #__users AS u ON u.id = p.created_by'
				. ' LEFT JOIN #__groups AS g ON p.access = g.id';	
    	$nodes = $this->_getList($query);
    	
    	foreach ($nodes  as $node ){
    		$node->detail_link = $menu->link."&Itemid=" . $menu->id .  "&id=" . RokdownloadsModelDownloadItem::getSlug($node);
    	}
    	
    	return $nodes;
    }
    
    function getSlug(&$node) {
    	// Add id
    	$slug = $node->id;
		$slug .= ":";
		$slug .= RokdownloadsModelDownloadItem::_getAlias($node);
		return $slug;
    }
    
    function _getAlias(&$node) {
    	
    	if ((isset($node->displayname) && strlen($node->displayname) > 0) || (isset($node->title) && strlen($node->title)>0)){ 
    		if (!isset($node->displayname) && isset($node->title)){
    			$node->displayname = $node->title;
    		}
			// Strip extension is there is one
			$name = $node->displayname;
			$ext = strrchr($name, '.');
			if($ext !== false)
			{
				$name = substr($name, 0, -strlen($ext));
			} 
			// lower case the name
			$name = JString::strtolower($name);
			// Change spaces and periods to  dashes
			$name = JString::str_ireplace(" ", "-", $name);
			$name = JString::str_ireplace(".", "-", $name);
    	}
		return JFilterOutput::stringURLSafe($name);
    }
}