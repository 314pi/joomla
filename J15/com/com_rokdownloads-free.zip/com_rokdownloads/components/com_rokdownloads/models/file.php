<?php
/**
 * @version $Id: file.php 18489 2010-02-03 00:44:48Z btowles $
 * @package RocketTheme
 * @subpackage	RokDownloads
 * @copyright Copyright (C) 2008 RocketWerx. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport('joomla.application.component.model');
include('downloadItem.php');

/**
 * @package		RocketTheme
 * @subpackage	RokDownloads
 *
 * @since 1.5
 */
class RokdownloadsModelFile extends RokdownloadsModelDownloadItem
{
	
	var $_file = null;
	
	/**
	 * Constructor
	 *
	 * @since 1.5
	 */
	function __construct()
	{
		parent::__construct();

		$id = JRequest::getVar('id', 0, '', 'int');
		$this->setId((int)$id);
	}
		
	/**
	 * Overridden set method to pass properties on to the article
	 *
	 * @access	public
	 * @param	string	$property	The name of the property
	 * @param	mixed	$value		The value of the property to set
	 * @return	boolean	True on success
	 * @since	1.5
	 */
	function set( $property, $value=null )
	{
		if ($this->_loadFile()) {
			$this->_file->$property = $value;
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Overridden get method to get properties from the article
	 *
	 * @access	public
	 * @param	string	$property	The name of the property
	 * @param	mixed	$value		The value of the property to set
	 * @return 	mixed 				The value of the property
	 * @since	1.5
	 */
	function get($property, $default=null)
	{
		if ($this->_loadFile()) {
			if(isset($this->_file->$property)) {
				return $this->_file->$property;
			}
		}
		return $default;
	}

	/**
	 * Method to get the file information
	 *
	 * @since 1.5
	 */
	function &getFile()
	{

		if ($this->_loadFile())
		{
			$user	= & JFactory::getUser();
			$this->_loadFileParams();

			/*
			 * Record the hit on the article if necessary
			 */
/*			$limitstart	= JRequest::getVar('limitstart',	0, '', 'int');
			if (!$this->_file->parameters->get('intro_only') && ($limitstart == 0))
			{
				$this->hit();
			}*/

		}
		else
		{
			$user =& JFactory::getUser();
			$file =& JTable::getInstance('rokdownloads');
			$file->state			= 1;
			$file->author		= null;
			$file->created_by	= $user->get('id');
			$file->parameters	= new JParameter( '' );
			$file->text			= '';
			$file->new = false;
			$file->hot = false; 
			$file->updated = false;
			$file->alias = '';
			$this->_file			= $file;
		}

		return $this->_file;
	}

	/**
	 * Method to increment the hit counter for the article
	 *
	 * @access	public
	 * @return	boolean	True on success
	 * @since	1.5
	 */
/*	function hit()
	{
		global $mainframe;

		if ($this->_id)
		{
			$article = & JTable::getInstance('rokdownloads');
			$article->hit($this->_id);
			return true;
		}
		return false;
	}*/

	/**
	 * Method to load content article data
	 *
	 * @access	private
	 * @return	boolean	True on success
	 * @since	1.5
	 */
	function _loadFile()
	{
		$menus = &JSite::getMenu();
		$menu  = $menus->getActive();
		
		global $mainframe;

		if($this->_id == '0')
		{
			return false;
		}

		// Load the content if it doesn't already exist
		if (empty($this->_file))
		{
			// Get the page/component configuration
			$params = &$mainframe->getParams();

			// Get the WHERE clause
			$where	= $this->_buildContentWhere();

			$query = 'SELECT a.*, u.name AS author, u.usertype, ' .
					' g.name AS groups '.
					' FROM #__rokdownloads AS a' .
					' LEFT JOIN #__users AS u ON u.id = a.created_by' .
					' LEFT JOIN #__groups AS g ON a.access = g.id'.
					$where;
			
			$this->_db->setQuery($query);
			$this->_file = $this->_db->loadObject();
			
			if ( ! $this->_file ) {
				return false;
			}
			
			// Load the parent info if from a folder menu
			if($menu && $menu->query['view'] == 'folder') { 
				// load the parent info
				$this->_file->parent = &$this->_loadParentNode();
				if ($this->_file->parent === false) {
					return false;
				}			
			}
			else {
				$this->_file->parent=null; 
			}
		}
		return true;
	}

	/**
	 * Method to load content article parameters
	 *
	 * @access	private
	 * @return	void
	 * @since	1.5
	 */
	function _loadFileParams()
	{
		global $mainframe;

		// Get the page/component configuration
		$params = clone($mainframe->getParams('com_rokdownloads'));

		
		//Adjust Parameters
		$this->_file->parameters = array();
		if (0 < strlen($this->_file->params)) {
			// Get the item parameters
			$item_params = new JParameter($this->_file->params);
			$item_params->loadSetupFile(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_rokdownloads'.DS.'custom_params.xml');
			$tempparams = $item_params->renderToArray();
			foreach($tempparams as $pval) {
				if ($pval[0] != "&nbsp;") { 
					$this->_file->parameters[$pval[3]] = $pval[4];
				}
			}  
		}
		
		$params->merge($item_params);

		// Set the popup configuration option based on the request
		$pop = JRequest::getVar('pop', 0, '', 'int');
		$params->set('popup', $pop);

		// Are we showing introtext with the article
		if ($params->get('files_show_intro')) {
			$this->_file->text = $this->_file->introtext . chr(13).chr(13) . $this->_file->fulltext;
		} else {
			$this->_file->text = $this->_file->fulltext;
		}
		
		$this->_file->filesize = $this->_filesize_format($this->_file->filesize);
		
		$thumbfolder = JURI::base() . $params->get("thumbnail_folder");

		// Adjust Thumbnail path
		if (0 < strlen($this->_file->thumbnail)) { //default values
			$this->_file->thumbpath = $thumbfolder."/".$this->_file->thumbnail;
			$this->_file->thumb_tag = "<img src='" . $this->_file->thumbpath . "' alt='" . $this->_file->thumbnail . "' />";
		} elseif ($params->get('display_default_thumbnails',1)==1) {
			$this->_file->thumbnail = $params->get('default_file_thumb');
			$this->_file->thumbpath = $thumbfolder ."/". $this->_file->thumbnail;
			$this->_file->thumb_tag = "<img src='" . $this->_file->thumbpath . "' alt='" . $this->_file->thumbnail . "' />";
		} else {
			$this->_file->thumb_tag = "";
		}
		$this->_file->files_show_thumbnails = $params->get('files_show_thumbnails',1);
		
		// Set the download URL
		$this->_file->download_link = "index.php?option=com_rokdownloads&view=file&task=download&id=" . RokdownloadsModelDownloadItem::getSlug($this->_file);
		
		$this->_file->alias = $this->_getAlias($this->_file);
		
		$this->_file->new = false;
		if ($params->get('files_show_new_flag')) {
			$daysdiff = (time() - strtotime($this->_file->created_time))/60/60/24; 
			if ($params->get('files_new_flag_days') > $daysdiff) {
				$this->_file->new = true;
			}
		}
		
		$this->_file->updated = false;
		if ($params->get('files_show_updated_flag')) {
			$daysdiff = (time() - strtotime($this->_file->modified_time))/60/60/24; 
			if ($params->get('files_updated_flag_days') > $daysdiff) {
				$this->_file->updated = true;
			}
		}
		
		$this->_file->hot = false;
		if ($params->get('files_show_hot_flag')) {
			if ($this->_file->downloads >= $params->get('files_hot_flag_minimum')) {
				$this->_file->hot = true;
			}
		}
		// set all associated parameters
		//$this->_file->all_parameters = & $params->toArray();
	}

	/**
	 * Method to build the WHERE clause of the query to select a content article
	 *
	 * @access	private
	 * @return	string	WHERE clause
	 * @since	1.5
	 */
	function _buildContentWhere()
	{
		global $mainframe;

		$user		=& JFactory::getUser();
		$aid		= (int) $user->get('aid', 0);
		// TODO: Should we be using requestTime here? or is JDate ok?
		// $now		= $mainframe->get('requestTime');

		jimport('joomla.utilities.date');
		$jnow		= new JDate();
		$now		= $jnow->toMySQL();
		$nullDate	= $this->_db->getNullDate();

		/*
		 * First thing we need to do is assert that the content article is the one
		 * we are looking for and we have access to it.
		 */
		$where = ' WHERE a.id = '. (int) $this->_id;
		$where .= ' AND a.published = 1';
		$where .= ' AND a.folder = 0';

		return $where;
	}
	
	/**
     * Format a number of bytes into a human readable format.
     * Optionally choose the output format and/or force a particular unit
     *
     * @param   int     $bytes      The number of bytes to format. Must be positive
     * @param   string  $format     Optional. The output format for the string
     * @param   string  $force      Optional. Force a certain unit. B|KB|MB|GB|TB
     * @return  string              The formatted file size
     */
    function _filesize_format($bytes, $format = '', $force = '')
    {
        $force = strtoupper($force);
        $defaultFormat = '%01d %s';
        if (strlen($format) == 0)
            $format = $defaultFormat;
 
        $bytes = max(0, (int) $bytes);
 
        $units = array('B', 'KB', 'MB', 'GB', 'TB', 'PB');
 
        $power = array_search($force, $units);
 
        if ($power === false)
            $power = $bytes > 0 ? floor(log($bytes, 1024)) : 0;
 
 		if (0 == $power) $format = $defaultFormat;
        return sprintf($format, $bytes / pow(1024, $power), $units[$power]);
    }
    
    
    function logDownload() {
    	$query = 'UPDATE #__rokdownloads'
		. ' SET downloads = ( downloads + 1 )'
		. ' WHERE  id='. $this->_id;
		$this->_db->setQuery( $query );
		$this->_db->query();
    }
    
    
    function _loadParentNode() {
		$user		=& JFactory::getUser();
		$aid		= (int) $user->get('aid', 0);
		$menus = &JSite::getMenu();
		$menu  = $menus->getActive();
		$view = 'folder';
		$parent = null;
		
		//get the parent id of the folder
		$query = 'select a.*, u.name AS author, u.usertype,  g.name AS groups FROM #__rokdownloads AS a' 
				. ' LEFT JOIN #__users AS u ON u.id = a.created_by' 
				. ' LEFT JOIN #__groups AS g ON a.access = g.id'
				. ' where a.id = '
				. '(select MAX(parent.id) as parent from #__rokdownloads as node, #__rokdownloads as parent where node.lft between parent.lft and parent.rgt and node.id = '
		 		. (int)$this->_id .' and parent.id != ' . (int)$this->_id . ' order by parent.lft)'
				. ' AND a.access <= '. (int) $aid
				. ' AND a.published = 1';
		 		  
		$this->_db->setQuery($query);
		$this->_db->query();
		
		// make sure query worked	
		if ($this->_db->getErrorMsg()!='') {
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
		
		if ($this->_db->getNumRows() >= 1) {
			$parent = $this->_db->loadObject();
			$parent->detail_link = "index.php?option=com_rokdownloads&view=" . $view . "&Itemid=". $menu->id . "&id=" . RokdownloadsModelDownloadItem::getSlug($parent);	
		}
		
		return $parent;
	}
}