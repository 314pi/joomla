<?php

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

jimport( 'joomla.application.component.view');


class RokdownloadsViewFolder extends JView
{
	function display()
	{
		global $mainframe;
		$doc =& JFactory::getDocument();
		$params =& $mainframe->getParams();
		
		// $item = $menu->getActive();
		$state		=& $this->get('state');
		$mparams    =& $state->get('parameters.menu');
		$model = & $this->getModel();
		$menus = &JSite::getMenu();
		$menu  = $menus->getActive();
		$params->merge($mparams);
		
		if (0 == (int)$this->get('Id')) {
			$model->setId((int)$params->get('top_level_folder'));
		} 

		// Get some data from the model
		JRequest::setVar('limit', $mainframe->getCfg('feed_limit'));

		// Lets get our data from the model
		$allSub = &$this->get( 'Folder' );
		$files = &$allSub->files;
		
		$dates = array();
		foreach ( $files as $key => $val )
		{
			$dates[$key] = $val->created_time;
		}
		arsort($dates);
		$sfiles = array();
		foreach ($dates as $key => $val) {
			$sfiles[$key] = $files[$key];
		}
		
		$doc->link = JRoute::_('index.php?option=com_rokdownloads&view=folder&ItemId='.$menu->id);
		
		foreach ( $sfiles as $row )
		{
			// strip html from feed item title
			$title = $this->escape( $row->displayname );
			$title = html_entity_decode( $title );

			// url link to article
			// & used instead of &amp; as this is converted by feed creator
			$tmplink = $this->getFolderRoute($menu->id, $row);
			$link = JRoute::_($tmplink);

			// strip html from feed item description text
			$description	= ($params->get('feed_summary', 0) ? $row->introtext.$row->fulltext : $row->introtext);
			//$author			= $row->created_by_alias ? $row->created_by_alias : $row->author;

			// load individual item creator class
			$item = new JFeedItem();
			$item->title 		= $title;
			$item->link 		= $link;
			$item->description 	= $description;
			$item->date			= $row->created_time;
			$item->category   	= $row->category;

			// loads item info into rss array
			$doc->addItem( $item );
		}
	}
	
	function getFolderRoute($menuId, $node)
	{
		$link = 'index.php?option=com_rokdownloads&view=file&id='.RokdownloadsModelDownloadItem::getSlug($node);
		return $link;
	}
}