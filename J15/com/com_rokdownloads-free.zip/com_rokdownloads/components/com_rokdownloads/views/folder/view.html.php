<?php
/**
 * @version $Id: view.html.php 26259 2010-08-03 11:48:15Z juozas $
 * @package RocketTheme
 * @subpackage	RokDownloads
 * @copyright Copyright (C) 2008 RocketWerx. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport( 'joomla.application.component.view');
jimport( 'joomla.html.pagination');

/**
 * @package		RocketTheme
 * @subpackage	RokDownloads
 *
 * @since 1.5
 */
class RokdownloadsViewFolder extends RokDownloadView
{
	function display( $tpl = null)
	{
		global $mainframe;
		
		$user		   =& JFactory::getUser();
		$document	   =& JFactory::getDocument();
		$dispatcher	   =& JDispatcher::getInstance();
		$pathway	   =& $mainframe->getPathway();
		$params 	   =& $mainframe->getParams('com_rokdownloads');
		$breadcrumbs = array();
		
		$model = & $this->getModel();
		$uri 		=& JFactory::getURI();
		$user		=& JFactory::getUser();
		$aid		= (int) $user->get('aid', 0);
		
		// Load the menu object and parameters
		// $menu = &JMenu::getInstance("site");
		// Get the menu item object
		$menus = &JSite::getMenu();
		$menu  = $menus->getActive();
		
		// $item = $menu->getActive();
		$state		= $this->get('state');
		$mparams    = $state->get('parameters.menu');
		
		$params->merge($mparams);
		
		if (0 == (int)$this->get('Id')) {
			$model->setId((int)$params->get('top_level_folder'));
		} 

		$fileperpage =($params->def('show_pagination', 2))?$params->def('file_per_page', 0):0;
		$limit		= $mainframe->getUserStateFromRequest('com_rokdownloads.'.$this->getLayout().'.limit', 'limit', $fileperpage, 'int');
		$limitstart	= JRequest::getVar('limitstart', 0, '', 'int');
		JRequest::setVar('limit', (int) $limit);
		
		$folder =& $model->getFolder();
		
		if (($folder->id == 0))
		{
			$id = JRequest::getVar( 'id', '', 'default', 'int' );
			return JError::raiseError( 404, JText::_( 'Not found or Unauthorized', (int)$id ) );
		}

		$pagination = new JPagination($folder->count_files, $limitstart, $limit);
		
		/*  Show the sub folders 
				if there are any to show 
				and
				  if pagination is enabled, we are not showing subfolders on each page and it is page one
				  or
				  if pagination is enabled, and we are showing subfodlers on each page
				  of 
				  if pagination is not enabled
		*/
		$params->def('subfolders_show',1);
		if (count($folder->subfolders) > 0 && 
		      (
		      	($params->def('show_pagination',2) && !$params->def('show_subfolders_on_all_pages',1) && $limitstart == 0) ||
		      	($params->def('show_pagination',2) && $params->def('show_subfolders_on_all_pages',1)) ||
		      	(!$params->def('show_pagination',2))
		      )
		     )
		{
			$params->set('subfolders_show', 1);
		}
		else { 
			$params->set('subfolders_show', 0);
		}
		
		
		

		
		/*
		 * Process the prepare content plugins
		 */

		JPluginHelper::importPlugin('content');
		$results = $dispatcher->trigger('onPrepareContent', array (&$folder, & $params, $limitstart));	
		
		foreach($folder->subfolders as $subfolder) {
			$results = $dispatcher->trigger('onPrepareContent', array (&$subfolder, & $params, $limitstart));
		}
		
		foreach($folder->files as $file) {
			
			if ($file->access <= $aid) {
				$file->show_download_button = (int)$params->def('files_show_download_button',1);
			}
			else {
				$file->show_download_button = ((int)$params->def('files_show_download_button',1) && (int)$params->get('files_show_download_for_no_access',1))?1:0;
			}
			
			$file->show_details_button = (int)$params->def('files_show_details_button', 1);
			
			$results = $dispatcher->trigger('onPrepareContent', array (&$file, & $params, $limitstart));
		}
			
		$page_title = $params->get('page_title');
		/*
		 * Handle the breadcrumbs
		 */
		if($menu)
		{
			$parents = $model->getParents((int)$params->get('top_level_folder'));

			for ($i = 1; $i < count($parents); $i++){ 
				$pathway->addItem($parents[$i]->displayname, $parents[$i]->detail_link);
			}
			
			// zero parents has top-level folder
			if (count($parents) > 0) { 
				$pathway->addItem($folder->displayname, '');
				$page_title .=  ' - ' . $folder->displayname;
			}
		}
		
		$document->setTitle( $page_title);
		$folder->title = $page_title;
		
		// Populate metadata
		if ($folder->metadesc) {
			$document->setDescription( $folder->metadesc );
		}
		if ($folder->metakey) {
			$document->setMetadata('keywords', $folder->metakey);
		}

		if ($mainframe->getCfg('MetaTitle') == '1') {
			$mainframe->addMetaTag('title', $folder->title);
		}
		if ($mainframe->getCfg('MetaAuthor') == '1') {
			$mainframe->addMetaTag('author', $folder->author);
		}
		
		
		//add alternate feed link
		if($params->get('show_feed_link', 1) == 1)
		{
			$link	= '&format=feed&limitstart=';
			$attribs = array('type' => 'application/rss+xml', 'title' => 'RSS 2.0');
			$document->addHeadLink(JRoute::_($link.'&type=rss'), 'alternate', 'rel', $attribs);
			$attribs = array('type' => 'application/atom+xml', 'title' => 'Atom 1.0');
			$document->addHeadLink(JRoute::_($link.'&type=atom'), 'alternate', 'rel', $attribs);
		}
		
		/*
		 * Handle display events
		 */
		$folder->event = new stdClass();
		$results = $dispatcher->trigger('onAfterDisplayTitle', array ($folder, &$params, $limitstart));
		$folder->event->afterDisplayTitle = trim(implode("\n", $results));
		
		foreach($folder->subfolders as $subfolder) {
			$results = $dispatcher->trigger('onAfterDisplayTitle', array (&$subfolder, & $params, $limitstart));
		}
		
		foreach($folder->files as $file) {
			$results = $dispatcher->trigger('onAfterDisplayTitle', array (&$file, & $params, $limitstart));
		}
		
		
		$results = $dispatcher->trigger('onBeforeDisplayContent', array (& $folder, & $params, $limitstart));
		$folder->event->beforeDisplayContent = trim(implode("\n", $results));
		
		foreach($folder->subfolders as $subfolder) {
			$results = $dispatcher->trigger('onBeforeDisplayContent', array (&$subfolder, & $params, $limitstart));
		}
		
		foreach($folder->files as $file) {
			$results = $dispatcher->trigger('onBeforeDisplayContent', array (&$file, & $params, $limitstart));
		}

		$results = $dispatcher->trigger('onAfterDisplayContent', array (& $folder, & $params, $limitstart));
		$folder->event->afterDisplayContent = trim(implode("\n", $results));
		foreach($folder->subfolders as $subfolder) {
			$results = $dispatcher->trigger('onAfterDisplayContent', array (&$subfolder, & $params, $limitstart));
		}
		
		foreach($folder->files as $file) {
			$results = $dispatcher->trigger('onAfterDisplayContent', array (&$file, & $params, $limitstart));
		}
				
				
		$print = JRequest::getBool('print');
		if ($print) {
	      $document->setMetaData('robots', 'noindex, nofollow');
	    }
		
				
		$this->assignRef('breadcrumbs',$parents);
		$this->assignRef('folder', $folder);
		$this->assignRef('params', $params);
		$request_url = $uri->toString();
		$this->assignRef('request_url',	$request_url);
		$this->assignRef('pagination',	$pagination);

		parent::display($tpl);
	}
}