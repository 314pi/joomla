<?php
/**
 * @version $Id: default.php 18489 2010-02-03 00:44:48Z btowles $
 * @package RocketTheme
 * @subpackage	RokDownloads
 * @copyright Copyright (C) 2008 RocketWerx. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 */
defined('_JEXEC') or die('Restricted access'); 
$counter = 0;

?>  
<?php if ($this->params->get( 'show_page_title', 1)) : ?>
<div class="component-header">
    <h1 class="componentheading<?php echo $this->params->get( 'pageclass_sfx' ) ?>">
	    <?php echo $this->escape($this->params->get('page_title')); ?>
    </h1>
</div>
<?php endif; ?>
<div id="rokdownloads">
	<?php if ($this->params->def('display_rokdownloads_breadcrumbs', 1)) : ?>
	<div id="rd_breadcrumbs">
	<?php echo Jtext::_("BREADINTRO"); ?> <span>\</span>
	<?php foreach ($this->breadcrumbs as $parent) : ?>
		<?php if ($parent->displayname == $this->folder->displayname) : ?>
			<strong><?php echo $parent->displayname; ?></strong>
		<?php else : ?>
		<a href="<?php echo JRoute::_($parent->detail_link); ?>" class="rd_breadcrumbs_folder"><?php echo $parent->displayname; ?></a>
		<span>\</span>	
		<?php endif; ?>
	<?php endforeach; ?>
	</div>
	<?php	endif; ?>

	<div id="rd_folder" <?php if(!$this->params->def('folder_display_thumnnail',1)): ?> class="nothumb"<?php endif; ?>>
		<?php if($this->params->def('folder_display_title',1)) : ?>
		<h3><?php echo Jtext::_("FOLDER"); ?> <span><?php echo $this->folder->displayname; ?></span></h3>
		<?php endif; ?>
		<?php if($this->params->def('folder_display_thumnnail',1)) : ?><div class="rd_thumb"><?php echo $this->folder->thumb_tag; ?></div><?php endif; ?>
		<?php if($this->params->def('folder_display_desc',1)) : ?>
		<div class="rd_details">
			<p><span class="rd_desc">
				<?php echo $this->folder->text; ?>
			</span></p>
		</div>
		<?php endif; ?>
	</div>

	<?php if ($this->params->def('subfolders_show',1)) : ?>
	<h3><?php echo Jtext::_("SUBFOLDERS"); ?></h3>
	<div id="rd_subfolders" <?php if(!$this->params->def('subfolder_display_thumnnail', 1)) : ?> class="nothumb"<?php endif; ?>>
		<ul>
		<?php	foreach ($this->folder->subfolders as $subfolder) :?>
			<li>
				<?php if($this->params->def('subfolder_display_thumnnail', 1)) : ?><div class="rd_thumb"><a class="rd_url" href="<?php echo JRoute::_($subfolder->detail_link); ?>"><?php echo $subfolder->thumb_tag; ?></a></div><?php endif; ?>
				<div class="rd_details">
					<h4><a class="rd_url" href="<?php echo JRoute::_($subfolder->detail_link); ?>"><?php echo $subfolder->displayname; ?></a></h4>
					<!-- if (contains files): -->   
					<?php if ($this->params->def('subfolders_show_file_count', 1) or $this->params->def('subfolders_show_subfolder_count', 1)) : ?>
					<dl>
						<?php if($this->params->def('subfolders_show_file_count', 1)) : ?>
						<dt class="rd_filecount"><?php echo Jtext::_("FILECOUNT"); ?></dt>
						<dd class="rd_filecount"><?php echo $subfolder->count_files; ?></dd>
						<?php endif; ?>
						<?php if($this->params->def('subfolders_show_subfolder_count', 1)) : ?>
						<dt class="rd_foldercount"><?php echo Jtext::_("FOLDERCOUNT"); ?></dt>
						<dd class="rd_foldercount"><?php echo $subfolder->count_subfolders; ?></dd>
						<?php endif; ?>
					</dl>
					<?php endif; ?> 
					
					<!-- endif; -->
					<?php if($this->params->def('subfolders_show_intro', 1)) { ?>
					<div class="rd_desc">
						<p><?php echo $subfolder->text; ?></p>
					</div>
					<?php }?>
				</div>
			</li>
			<?php	endforeach; ?>
		</ul>
	</div>
	<?php endif; ?> 
	
	<?php if (count($this->folder->files) > 0 && $this->params->def('show_pagination', 2)) : ?>
	<div class="rd_pagination">
	<?php echo $this->pagination->getPagesLinks(); ?>
	</div>
	<?php endif; ?>
	
	<?php if (count($this->folder->files) > 0) : ?>
		<h3><?php echo Jtext::_("FILES"); ?></h3>
		<div id="rd_files" <?php if(!$this->params->def('files_show_thumbnails', 1)) : ?> class="nothumb"<?php endif; ?>>
			<ul>
			<?php foreach ($this->folder->files as $file) : ?>
				<li class="rd_file">
					<?php if($this->params->def('files_show_thumbnails', 1)) : ?><div class="rd_thumb"><?php echo $file->thumb_tag; ?></div><?php endif; ?>
					<div class="rd_details">
						<h4>
							<?php if($this->params->def('files_title_link','details') == 'details') : ?>
							<a class="folder_url" href="<?php echo JRoute::_($file->detail_link); ?>"><?php echo $file->displayname; ?></a>
							<?php elseif($this->params->def('files_title_link') == 'download') : ?>
							<a class="folder_url" href="<?php echo JRoute::_($file->download_link); ?>"><?php echo $file->displayname; ?></a>
							<?php else: ?>
							<?php echo $file->displayname; ?>
							<?php endif; ?>
						</h4>
						<dl class="rd_props">
							<?php if($this->params->def('files_show_create_date_list', 1)) : ?>
							<div class="rd_prop <?php echo (($counter++)%2 == 0 ? "even":"odd"); ?>">
								<dt class="rd_uploaded_date"><?php echo Jtext::_("UPLOADED_DATE"); ?></dt>
								<dd class="rd_uploaded_date"><?php echo JHTML::_('date', $file->created_time, JText::_('DATE_FORMAT_LC4')); ?></dd>
							</div>
							<?php endif; ?>
							<?php if($this->params->def('files_show_modify_date_list', 1)) : ?>
							<div class="rd_prop <?php echo (($counter++)%2 == 0 ? "even":"odd"); ?>">
								<dt class="rd_modified_date"><?php echo Jtext::_("MODIFIED_DATE"); ?></dt>
								<dd class="rd_modified_date"><?php echo JHTML::_('date', $file->modified_time, JText::_('DATE_FORMAT_LC4')); ?></dd>
							</div>
							<?php endif; ?>
							<?php if($this->params->def('files_show_filesize_list', 1)) : ?>
							<div class="rd_prop <?php echo (($counter++)%2 == 0 ? "even":"odd"); ?>">
								<dt class="rd_filesize"><?php echo Jtext::_("FILESIZE"); ?></dt>
								<dd class="rd_filesize"><?php echo $file->filesize; ?></dd>
							</div>
							<?php endif; ?>
							<?php if($this->params->def('files_show_download_stats_list', 1)) : ?>
							<div class="rd_prop <?php echo (($counter++)%2 == 0 ? "even":"odd"); ?>">
								<dt class="rd_dl_count"><?php echo Jtext::_("DOWNLOAD_COUNT"); ?></dt>
								<dd class="rd_dl_count"><?php echo $file->downloads; ?></dd>
							</div>
							<?php endif; ?>
							<?php if($this->params->def('files_show_custom_parameters_list', 1)) :
									foreach ($file->parameters as $paramname => $paramval) :
										if (isset($paramval) and $paramval != "") :
										?>
							<div class="rd_prop <?php echo (($counter++)%2 == 0 ? "even":"odd"); ?>">
								<dt class="rd_param_key"><?php echo Jtext::_($paramname); ?></dt>
								<dd class="rd_param_key"><?php echo $paramval; ?></dd>
							</div>
							<?php 		endif;
									endforeach;
								  endif; 
							?>
						</dl>
						<?php if($this->params->def('files_show_intro_list',1)) :?>
						<div class="rd_desc">
							<p><?php echo $file->text; ?></p>
						</div>
						<?php endif; ?>
						<div class="rd_status">
							<?php if ($file->hot):?><span class="rd_hot"><span><?php echo ""?></span></span><?php endif; ?>
							<?php if ($file->new):?><span class="rd_new"><span><?php echo ""?></span></span><?php endif; ?>
							<?php if (!$file->new && $file->updated):?><span class="rd_updated"><span><?php echo ""?></span></span><?php endif; ?>
						</div>
						<div class="rd_buttons">
							<?php if ($file->show_download_button): ?><a href="<?php echo JRoute::_($file->download_link); ?>" class="rd_button"><span><?php echo Jtext::_("DOWNLOAD"); ?></span></a><?php endif; ?>
							<?php if ($file->show_details_button) : ?><a href="<?php echo JRoute::_($file->detail_link); ?>" class="rd_button"><span><?php echo Jtext::_("DETAILS"); ?></span></a><?php endif; ?>
						</div>
					</div>
				</li>
				<?php endforeach; ?>
			</ul>
		</div>
		<?php if (count($this->folder->files) > 0 && $this->params->def('show_pagination', 2)) : ?>
			<div class="rd_pagination">
				<?php echo $this->pagination->getPagesLinks(); ?>
				<?php if ($this->params->def('show_pagination_results', 1)) : ?>
					<div class="rd_pages"><?php echo $this->pagination->getPagesCounter(); ?></div>
					<div class="rd_counter"><?php echo $this->pagination->getResultsCounter();?></div>
				<?php endif; ?>	
			</div>
		<?php endif; ?>
	<?php endif; ?>
</div>





