<?php
/**
 * @version $Id: view.html.php 18489 2010-02-03 00:44:48Z btowles $
 * @package RocketTheme
 * @subpackage	RokDownloads
 * @copyright Copyright (C) 2008 RocketWerx. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 */
defined('JPATH_BASE') or die();

jimport( 'joomla.application.component.view');

class RokDownloadView extends JView
{
	function __construct( $config = array() )
	{
		global $mainframe;
		
		parent::__construct( $config );
		
		$doc = & JFactory::getDocument();
		$doc->addStylesheet(RokDownloadView::getCSSPath('rokdownloads.css', 'com_rokdownloads'));
	}
	
	function getCSSPath($cssfile, $component)
	{
		global $mainframe;
		$tPath = 'templates/'.$mainframe->getTemplate().'/html/' . $component .'/'. $cssfile;
		$bPath = 'components/'.$component.'/css/'.$cssfile;       

		// If the template has a css override use it
		if (file_exists(JPATH_BASE.DS.$tPath)) {
			return $this->baseurl.'/'.$tPath;
		} else {
			return $this->baseurl.'/'.$bPath;
		}
	}
}