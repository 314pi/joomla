<?php
/**
 * @version $Id: default.php 18489 2010-02-03 00:44:48Z btowles $
 * @package RocketTheme
 * @subpackage	RokDownloads
 * @copyright Copyright (C) 2008 RocketWerx. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 */
defined('_JEXEC') or die('Restricted access'); 
$counter = 0;
?>
<div class="component-header"><h1 class="componentheading<?php echo $this->params->get( 'pageclass_sfx' ) ?>">
	<?php echo $this->escape($this->params->get('page_title')); ?>
</h1></div>
<div id="rokdownloads">

	<?php if ($this->viewtype == 'folder' && $this->params->def('display_rokdownloads_breadcrumbs', 1)) : ?>
	<div id="rd_breadcrumbs">
	<?php echo Jtext::_("BREADINTRO"); ?> <span>\</span>
	<?php foreach ($this->breadcrumbs as $parent) : ?>
		<?php if ($parent->displayname == $this->file->displayname) : ?>
			<strong><?php echo $parent->displayname; ?></strong>
		<?php else : ?>
		<a href="<?php echo JRoute::_($parent->detail_link); ?>" class="rd_breadcrumbs_folder"><?php echo $parent->displayname; ?></a>
		<span>\</span>	
		<?php endif; ?>
	<?php endforeach; ?>
	</div>
	<?php endif; ?>

	<h3><?php echo Jtext::_("FILE"); ?> <?php echo $this->file->displayname; ?></h3>
	<div id="rd_file"  <?php if (!$this->params->def('files_show_thumbnails',1)) : ?> class="nothumb"<?php endif; ?>>
		<?php if ($this->params->def('files_show_thumbnails',1)) : ?><div class="rd_thumb"><?php echo $this->file->thumb_tag; ?></div><?php endif; ?>
		
		<div class="rd_details">
			<dl class="rd_props">
				<?php if($this->params->def('files_show_create_date', 1)) : ?>
				<div class="rd_prop <?php echo (($counter++)%2 == 0 ? "even":"odd"); ?>">
					<dt class="rd_uploaded_date"><?php echo Jtext::_("UPLOADED_DATE"); ?></dt>
					<dd class="rd_uploaded_date"><?php echo JHTML::_('date', $this->file->created_time, JText::_('DATE_FORMAT_LC4')); ?></dd>
				</div>
				<?php endif; ?>
				<?php if($this->params->def('files_show_modify_date', 1)) : ?>
				<div class="rd_prop <?php echo (($counter++)%2 == 0 ? "even":"odd"); ?>">
					<dt class="rd_modified_date"><?php echo Jtext::_("MODIFIED_DATE"); ?></dt>
					<dd class="rd_modified_date"><?php echo JHTML::_('date', $this->file->modified_time, JText::_('DATE_FORMAT_LC4')); ?></dd>
				</div>
				<?php endif; ?>
				<?php if($this->params->def('files_show_filesize', 1)) : ?>
				<div class="rd_prop <?php echo (($counter++)%2 == 0 ? "even":"odd"); ?>">
					<dt class="rd_filesize"><?php echo Jtext::_("FILESIZE"); ?></dt>
					<dd class="rd_filesize"><?php echo $this->file->filesize; ?></dd>
				</div>
				<?php endif; ?>
				<?php if($this->params->def('files_show_download_stats', 1)) : ?>
				<div class="rd_prop <?php echo (($counter++)%2 == 0 ? "even":"odd"); ?>">
					<dt class="rd_dl_count"><?php echo Jtext::_("DOWNLOAD_COUNT"); ?></dt>
					<dd class="rd_dl_count"><?php echo $this->file->downloads; ?></dd>
				</div>
				<?php endif; ?>
				<?php if($this->params->def('files_show_custom_parameters', 1)) :
						foreach ($this->file->parameters as $paramname => $paramval) : 
							if (isset($paramval) and $paramval != "") :
							?>
				<div class="rd_prop <?php echo (($counter++)%2 == 0 ? "even":"odd"); ?>">
					<dt class="rd_param_key"><?php echo Jtext::_($paramname); ?></dt>
					<dd class="rd_param_key"><?php echo $paramval; ?></dd>
				</div>
				<?php 		endif; 
						endforeach;  
					  endif;
				?>

			</dl>
			<div class="rd_desc rd_full">
				<p><?php echo $this->file->text; ?></p>
			</div>	
			<div class="rd_status">
				<?php if ($this->file->hot):?><span class="rd_hot"><span><?php echo ""?></span></span><?php endif; ?>
				<?php if ($this->file->new):?><span class="rd_new"><span><?php echo ""?></span></span><?php endif; ?>
				<?php if (!$this->file->new && $this->file->updated):?><span class="rd_updated"><span><?php echo ""?></span></span><?php endif; ?>
			</div>
			<div class="rd_buttons">
				<?php if ($this->params->def('files_show_download_link', 1)): ?><a href="<?php echo JRoute::_($this->file->download_link); ?>" class="rd_button"><span><?php echo Jtext::_("DOWNLOAD"); ?></span></a><?php else: ?><a href="index.php?option=com_user&amp;task=register">Please Register to Download</a><?php endif; ?>
			</div>
		</div>
	</div>
</div>