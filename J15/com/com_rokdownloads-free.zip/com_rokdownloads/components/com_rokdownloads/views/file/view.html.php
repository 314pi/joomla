<?php
/**
 * @version $Id: view.html.php 18489 2010-02-03 00:44:48Z btowles $
 * @package RocketTheme
 * @subpackage	RokDownloads
 * @copyright Copyright (C) 2008 RocketWerx. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport( 'joomla.application.component.view');

/**
 * @package		RocketTheme
 * @subpackage	RokDownloads
 *
 * @since 1.5
 */
class RokdownloadsViewFile extends RokDownloadView
{
	function display( $tpl = null)
	{
		global $mainframe;

		$user		   =& JFactory::getUser();
		$document	   =& JFactory::getDocument();
		$dispatcher	   =& JDispatcher::getInstance();
		$pathway	   =& $mainframe->getPathway();
		$params 	   =& $mainframe->getParams('com_rokdownloads');
		
		$model = & $this->getModel();
		$uri 		=& JFactory::getURI();
		$user		=& JFactory::getUser();
		$aid		= (int) $user->get('aid', 0);

		// Load the menu object and parameters
		// $menu = &JMenu::getInstance("site");
		// Get the menu item object
		$menus = &JSite::getMenu();
		$menu  = $menus->getActive();
		
		// $item = $menu->getActive();
		$state		=& $this->get('state');
		$mparams    =& $state->get('parameters.menu');
		
		$params->merge($mparams);

		if (0 == (int)$this->get('Id')) {
			$model->setId((int)$params->get('filetodisplay'));
		}
		$file	=& $this->get('File');
		
		if ($file->id == 0)
		{
			$id = JRequest::getVar( 'id', '', 'default', 'int' );
			return JError::raiseError( 404, JText::_( 'Not found or Unauthorized', (int)$id ) );
		}
		
		$limitstart	= JRequest::getVar('limitstart', 0, '', 'int');
		
		if ($file->access <= $aid) {
			$params->set('files_show_download_link', 1);
		}
		else {
			$params->set('files_show_download_link', $params->get('files_show_download_for_no_access',1));
		}
		
		/*
		 * Process the prepare content plugins
		 */
		JPluginHelper::importPlugin('content');
		$results = $dispatcher->trigger('onPrepareContent', array (& $file, & $params, $limitstart));
		
		/*
		 * Handle the Joomla breadcrumbs
		 */		
		$page_title = $params->get('page_title');
		
		if($menu && $menu->query['view'] != 'file')
		{
			$parents = $model->getParents((int)$params->get('top_level_folder'));
			for ($i = 1; $i < count($parents)-1; $i++){ 
				$pathway->addItem($parents[$i]->displayname, $parents[$i]->detail_link);
			}
			if (count($parents) != 1) { 
				$pathway->addItem($file->displayname, '');
				$page_title .=  ' - ' . $file->displayname;
			}
		}
		
		$document->setTitle( $page_title);
		$file->title = $page_title;
		
		// Populate metadata
		if ($file->metadesc) {
			$document->setDescription( $file->metadesc );
		}
		if ($file->metakey) {
			$document->setMetadata('keywords', $file->metakey);
		}

		if ($mainframe->getCfg('MetaTitle') == '1') {
			$mainframe->addMetaTag('title', $page_title);
		}
		if ($mainframe->getCfg('MetaAuthor') == '1') {
			$mainframe->addMetaTag('author', $file->author);
		}

		$mdata = new JParameter($file->metadata);
		$mdata = $mdata->toArray();
		foreach ($mdata as $k => $v)
		{
			if ($v) {
				$document->setMetadata($k, $v);
			}
		}
		
		/*
		 * Handle display events
		 */
		$file->event = new stdClass();
		$results = $dispatcher->trigger('onAfterDisplayTitle', array ($file, &$params, $limitstart));
		$file->event->afterDisplayTitle = trim(implode("\n", $results));

		$results = $dispatcher->trigger('onBeforeDisplayContent', array (& $file, & $params, $limitstart));
		$file->event->beforeDisplayContent = trim(implode("\n", $results));

		$results = $dispatcher->trigger('onAfterDisplayContent', array (& $file, & $params, $limitstart));
		$file->event->afterDisplayContent = trim(implode("\n", $results));
		
		$trimmed_parents = array(); 
		if($menu && $menu->query['view'] != 'file')
		{
			foreach ( $parents as $parent) {
				if ($parent->folder ==	 1) {
					$trimmed_parents[] = $parent;
				}
			}
		}
		
		$print = JRequest::getBool('print');
		if ($print) {
	      $document->setMetaData('robots', 'noindex, nofollow');
	    }
       
		$viewtype = $menu->query['view'];
		$this->assignRef('viewtype', $viewtype);
		$this->assignRef('breadcrumbs', $trimmed_parents);
		$this->assignRef('params', $params);
		$this->assignRef('file', $file);
		$request_url = $uri->toString();
		$this->assignRef('request_url',	$request_url);
		parent::display($tpl);
	}
}