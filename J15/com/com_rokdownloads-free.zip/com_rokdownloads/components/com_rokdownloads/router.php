<?php


/**
 * @version $Id: router.php 18489 2010-02-03 00:44:48Z btowles $
 * @package RocketTheme
 * @subpackage	RokDownloads
 * @copyright Copyright (C) 2008 RocketWerx. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 */
$download_tree = null;

function RokdownloadsBuildRoute(& $query) {
	$menuitem_row = null;
	$item_row = null;
	$downloads = array();
	$tmpstack = array();
	$segments = array ();
	$menuitem = null;
	
	
	// cases   
	// top level   				ItemId, Option
	// rss/atom 				ItemId, Option, view, id (non slug), format=feed, type rss/atom
	// folder/file link			ItemId, Option, view, id (slug)
	// download link			ItemId, Option, view, id (slug), task=download


	if (isset ($query['id'])) {
		// Get list from cache/function
		$cache = & JFactory :: getCache('com_rokdownloads_router');
		$downloads = $cache->call('RokdownloadGetDownloadsLists');
		
		// Get the menu info
		
		$menu = & JSite :: getMenu();
		$menuitem = $menu->getItem((int) $query['Itemid']);
		$menuitemParams = new JParameter($menuitem->params);
		$menu_download_item = (int) $menuitemParams->get("top_level_folder");
		if ($menu_download_item == 0) {
			$menu_download_item = (int) $menuitemParams->get("filetodisplay");
		}
		$menuitem_row = $downloads[$menu_download_item];

		// get a clean id and the row if nessesary
		$cleanid = (strpos($query['id'], ":")) ? strtok($query['id'], ":") : $query['id'];
		if (is_numeric($cleanid) && array_key_exists($cleanid, $downloads)){
			$tmp_item_row = $downloads[$cleanid];
			$item_row = clone($tmp_item_row);
			
			//get the path stack that is correct
			$tmpstack = array_reverse($item_row->displaypath);
			for ($i = 0; $i < count($menuitem_row->displaypath); $i++){
				array_pop($tmpstack);
			}
			$item_row->displaypath = array_reverse($tmpstack);
			
			//add the id to the last item in the path (make the slug)
			if (count($item_row->displaypath) > 0) {
				$item_row->displaypath[count($item_row->displaypath)-1] = $item_row->id . ":" .$item_row->displaypath[count($item_row->displaypath)-1];
			}
			
			//build up the output path
			foreach ( $item_row->displaypath as $pathsegment ) {
	       		$segments[] = $pathsegment;
			}
		
			if (isset ($query['task'])) { // download link
				$segments[] = $query['task'];
				unset($query['task']);
			} 
			unset($query['id']);
		}
	}
	
	if (isset ($query['format']) && $query['format'] == "feed" && isset ($query['type'])) // rss/atom feed
	{
		$segments[] =  	$query['format'];
		unset($query['format']);
		$segments[] = $query['type'];
		unset($query['type']);
	} 

	// Dont pass out the view as a get query
	if (isset ($query['view'])) {
		unset ($query['view']);
	}

	return $segments;
}

function RokdownloadsParseRoute($segments) {
	$vars = array ();
	$count = count($segments);
	$oldstyle = false;
	// see if its using old style SEF
	if (($segments[0] == 'folder' ||$segments[0] == 'file' || $segments[0] == 'download')) {
		$id = explode( ':', $segments[$count-1] );
		$vars['id'] = (int) $id[0];
		if	((int)$vars['id'] > 0) {
			$oldstyle = true;
		}
	}
	
	if ($oldstyle) { 
		switch($segments[0])
		{
			case 'folder':
				$vars['view'] = 'folder';
			break;
			case 'file':
				$vars['view'] = 'file';
			break;
			default:
				$vars['task'] = 'download';
			break;
	   	}
	}
	else {
		// Use the path style SEF
		
		$cache = & JFactory :: getCache('com_rokdownloads_router');
		$downloads = $cache->call('RokdownloadGetDownloadsLists');
		
		$menu = & JSite :: getMenu();
		$menuitem = & $menu->getActive();
		$menuitemParams = new JParameter($menuitem->params);
		$menu_download_item = (int) $menuitemParams->get("top_level_folder");
		if ($menu_download_item == 0) {
			$menu_download_item = (int) $menuitemParams->get("filetodisplay");
			$vars['id'] = $menu_download_item;
		}
		$menuitem_row = $downloads[$menu_download_item];
	
		if ($count >= 2 && ($segments[$count-1] == 'rss' || $segments[$count-1] == 'atom')) {
			$vars['type'] = $segments[$count-1];
			$vars['format'] = $segments[$count-2];
			$count = $count-2;
		}
		if ($count >= 2 && $segments[$count-1] == 'download') {
			$vars['task'] = $segments[$count-1];
			$count = $count-1;
		}
		if ($count >= 1){ 
			if (strpos($segments[$count-1], ":")) {
				$slug = explode(':', $segments[$count -1]);
				$vars['id'] = (int) $slug[0];
				$item_row = $downloads[(int)$vars['id']];
				if ($item_row->folder){
					$vars['view'] = 'folder';
				}
				else {
					$vars['view'] = 'file';
				}
			}
			if ($count ==  1 && $segments[$count-1] == 'download') {
				$vars['task'] = $segments[$count-1];
				$count =$count-1;
			}
		}
		if ($count == 0 && !array_key_exists('id',$vars)) {
			$vars['id'] = $menu_download_item;
			$item_row = $downloads[(int)$vars['id']];
			if ($item_row->folder){
				$vars['view'] = 'folder';
			}
			else {
				$vars['view'] = 'file';
			}
		}

	}
	return $vars;
}

function RokdownloadGetDownloadsLists() {
	global $download_tree;
	
	$downloads = array ();
	if ($download_tree == null) {
		$db = & JFactory :: getDBO();
		$query = "SELECT node.id as id, node.name as name, node.displayname as displayname, node.path as path, node.folder as folder, node.lft as lft, node.rgt as rgt, (COUNT(parent.id) - 1) AS depth " .
		"FROM #__rokdownloads AS node, #__rokdownloads AS parent " .
		"WHERE node.lft >= parent.lft AND node.lft <= parent.rgt " .
		"GROUP BY node.id " .
		"ORDER BY node.lft;";
		$db->setQuery($query);
		$downloads = $db->loadObjectList("id");
		
		$path_stack = array ();
		$current_depth = 0;
		$last = null;
		reset($downloads);
		while ( list($id) = each($downloads) ) {
  			$download =& $downloads[$id];


	 		if ($last != null) { 
				if ($download->lft > $last->lft  && $download->rgt < $last->rgt) {  //is a child of the last
					// sure its a parent add to path_stack
					array_push($path_stack, RokdownloadGetDownloadsListsGetAlias($last->displayname));
					$current_depth++;
				}
			 	else if ($download->lft > $last->rgt+1) {  // new parent
			 		while ($current_depth > $download->depth) {
			 			array_pop($path_stack);
			 			$current_depth--;	
			 		}
			 	}
			}
			// put the parent path stack in the download
			$download->displaypath = $path_stack;
			// add the current download to the its path stack
			array_push($download->displaypath, RokdownloadGetDownloadsListsGetAlias($download->displayname));	
			$last = $download;
		}
		$download_tree = $downloads;
	}
	else {
		$downloads = &$download_tree;
	}
	return $downloads;
}

function RokdownloadGetDownloadsListsGetAlias($displayname) {
	// Strip extension is there is one
	$name = $displayname;
	$ext = strrchr($name, '.');
	if ($ext !== false) {
		$name = substr($name, 0, -strlen($ext));
	}
	// lower case the name
	$name = JString :: strtolower($name);
	// Change spaces and periods to  dashes
	$name = JString :: str_ireplace(" ", "-", $name);
	$name = JString :: str_ireplace(".", "-", $name);
	return JFilterOutput::stringURLSafe($name);
}