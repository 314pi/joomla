<?php
/**
 * @version $Id: rokdownloads.php 18489 2010-02-03 00:44:48Z btowles $
 * @package RocketTheme
 * @subpackage	RokDownloads
 * @copyright Copyright (C) 2008 RocketWerx. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 */
defined('_JEXEC') or die();
 
/**
 * Rokdownloads Component Controller
 *
 * @package		RocketTheme
 * @subpackage	RokDownloads
 *
 * @since 1.5
 */
class TableRokdownloads extends JTable {
	
	var $ignoreFiles = array('.svn','CVS','.DS_Store','index.html','index.html','.htaccess');

	// Databased fields
	var  $id = 0;
	var  $name = '';
	var  $displayname = '';
	var  $path = '';
	var  $folder = 0;
	var  $filesize = 0;
	var  $introtext = '';
	var  $fulltext = '';
	var  $thumbnail = '';
	var  $access = -1;
	var  $params = '';
	var  $downloads = 0;
	var  $published = 0;
	var  $lft = -1;
	var  $rgt = -1;
	var  $created_time = '0000-00-00 00:00:00';
	var  $created_by = 0;
	var  $modified_time = '0000-00-00 00:00:00';
	var  $modified_by = 0;
	var  $checked_out_time = '0000-00-00 00:00:00';
	var  $checked_out = 0;
	var  $metadata = '';
	var  $metadesc = '';
	var  $metakey = '';

	//functional fields

	var  $_missing = true;
	var  $_readable = false;
	var  $_fsid = 0;
	var  $_fsparent = 0;
	
	var  $_children = array();
	var  $_loadedfromdb = false;
	


	var $_json_passed_internal_fields = array('_missing','_readable','_children');

	function getJsonObject() {
    	$o = (object) NULL;
    	$pubProps =& $this->getPublicProperties();
    	$pubProps = array_merge(array_keys($pubProps), array_values($this->_json_passed_internal_fields));
	    foreach ($pubProps as $key => $value) {
	       if ($value != '_children') {
	       		$o->{$value} = $this->$value;
	       }
	       else {
	       		$o->{$value} = array();
	       		foreach($this->$value as $arraykey => $arrayvalue) {
	       			$o->_children[]=$arrayvalue->getJsonObject();
	       		}
	       }
	    }
    	return($o);
	}

	function __construct( &$db )
	{
		parent::__construct( '#__rokdownloads', 'id', $db );
	}

	function fromJFolder($array) {
		if (!is_array($array)) {
            return;
        }
       	$this->name = $array['name'];
       	$this->displayname = $this->name;
       	$this->path = JPath::clean(str_replace(JPath::clean(COM_ROKDOWNLOADS_BASE), "/", $array['fullname']),"/");
        if (is_dir($array['fullname'])) $this->folder = 1;
        $this->_fsid = $array['id'];
        $this->_fsparent = $array['parent'];
        //$this->modified_time = filemtime(JPath::clean($array['fullname']));
        $this->filesize = filesize($array['fullname']);
        $this->_readable = is_readable($array['fullname']);
        $this->_missing = false;
	}


	function fromFilesystem($fullpath) {
		// Get the component configuration
		$compparams = &JComponentHelper::getParams("com_rokdownloads");
		
		// get the filename
		$file = basename($fullpath);
		
		if (is_file($fullpath) && substr($file, 0, 1) != '.' && !in_array(strtolower($file), $this->ignoreFiles)) {
			$this->name = JPath::clean($file);
			$this->displayname = $this->name;
			$this->path = JPath::clean(str_replace(COM_ROKDOWNLOADS_BASE, '/', $fullpath),"/");
			$this->filesize = filesize($fullpath);
        	$this->_readable = is_readable($fullpath);
        	$this->_missing = false;
        	
        	//Set default thumbnail based on file extention if there is a thumnail for it.
        	$info = pathinfo($fullpath);
        	
        	if (array_key_exists('extension',$info) && strlen(strtolower($info['extension'])) > 0 && is_file(JPATH_SITE.DS.THUMB_FOLDER.DS.strtolower($info['extension']).".png")) 
        	{
        		$this->thumbnail = strtolower($info['extension']).".png";
        	}
        	else
        	{
        		$this->thumbnail = $compparams->get('default_file_thumb');
        	}
		}
		else {
			//TODO: display error here
			return false;
		}
	}

	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 * @since 1.0
	 */
	function TableRokdownloads(& $db) {
		parent :: __construct('#__rokdownloads', 'id', $db);
	}

	/**
	* Overloaded bind function
	*
	* @acces public
	* @param array $hash named array
	* @return null|string	null is operation was satisfactory, otherwise returns an error
	* @see JTable:bind
	* @since 1.5
	*/

	function bind($from, $ignore = '') {
		$fromArray    = is_array( $from );
        $fromObject    = is_object( $from );


		if (!$fromArray && !$fromObject)
        {
            $this->setError( JText::sprintf('ERROR.BIND_FAILED', get_class( $this )));
            $this->setErrorNum(20);
            return false;
        }
        if ($fromArray) {
        	if (key_exists('params', $from) && is_array($from['params'])) {
				$registry = new JRegistry();
				$registry->loadArray($from['params']);
				$from['params'] = $registry->toString();
			}
        }
        else if ($fromObject) {
			if (is_array($from->params)) {
				$registry = new JRegistry();
				$registry->loadArray($from->params);
				$from->params = $registry->toString();
			}
        }

		$retobject = parent :: bind($from, $ignore);

		if ($this->path != '') {
			$this->_missing = !(file_exists(JPath::clean(COM_ROKDOWNLOADS_BASE.$this->path)));
			if (!$this->_missing) $this->_readable = is_readable(JPath::clean(COM_ROKDOWNLOADS_BASE.$this->path));
		}
		
		return $retobject;
	}

	/**
	 * Overloaded check method to ensure data integrity
	 *
	 * @access public
	 * @return boolean True on success
	 * @since 1.0
	 */
	function check() {
		/** check for valid file name */
		if (trim($this->name) == '') {
			$this->setError(JText::_('ERROR.DOWNLOAD_ITEM_MUST_HAVE_NAME'));
			return false;
		}
		// name sure there is a displayname
		if (trim($this->displayname) == '') {
			$this->displayname = $this->name;
		}

		return true;
	}

	function load($oid = null) {
		$ret =& parent :: load($oid);
		if ($ret) {
			$this->_loadedfromdb = true;

		}
		return $ret;
	}

	function getFullPath() {
		return JPath::clean(COM_ROKDOWNLOADS_BASE.$this->path);
	}

	function move( $dirn, $where='' ) {
		return false;
	}

	function getNextOrder ( $where='' )
    {
    	return false;
    }

	function reorder( $where='' )
    {
    	return false;
    }
    function getParent() {
    	$query = ' Select node.id from #__rokdownloads as node where node.lft = ' .
				 ' (SELECT MAX(tree.lft) FROM' .
				 ' (SELECT node.id as id, node.lft as lft FROM  #__rokdownloads  AS node,' .
				 ' #__rokdownloads AS parent WHERE parent.lft > node.lft and parent.rgt < node.rgt' .
				 ' AND parent.id = ' . $this->id . ' ORDER BY node.lft	) AS tree)';
		$this->_db->setQuery($query);
		$retparent = $this->_db->loadResult();
		if ($retparent) {
			$ret =& JTable::getInstance('TableRokdownloads','');
			$ret->load($retparent);
			return $ret;
		}
		return $retparent;
    }
    
    function store( $updateNulls=false ){
    	$fullpath =  JPath::clean(COM_ROKDOWNLOADS_BASE.$this->path);
    	$this->filesize = filesize($fullpath);
    	return parent::store($updateNulls);
    }
}

