<?php
/**
 * @version $Id: file.php 18489 2010-02-03 00:44:48Z btowles $
 * @package RocketTheme
 * @subpackage	RokDownloads
 * @copyright Copyright (C) 2008 RocketWerx. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 */
 
// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport('joomla.filesystem.file');
jimport('joomla.filesystem.folder');
jimport('joomla.utilities.error');


/**
 * Rokdownloads Component Controller File
 *
 * @package		RocketTheme
 * @subpackage	RokDownloads
 *
 * @since 1.5
 */
class RokdownloadsControllerFile extends RokdownloadsController
{

	/**
	 * Upload a file
	 *
	 * @since 1.5
	 */
	function upload()
	{
		global $mainframe;

		// Check for request forgeries
		JRequest::checkToken( 'request' ) or die( 'Invalid Token' );

		jimport('joomla.utilities.error');
		jimport('joomla.filesystem.file');
		
		
		$model	=& $this->getModel('rokdownloads');
		$err = null;
		$pid 		= JRequest::getInt('pid');
		$file 		= JRequest::getVar( 'Filedata', '', 'files', 'array' );
		$folder		= JRequest::getVar( 'folder', '', '', 'path' );
		$format		= JRequest::getVar( 'format', 'html', '', 'cmd');
		$return		= JRequest::getVar( 'return-url', null, 'post', 'base64' );
		$err		= null;
		
		// Set FTP credentials, if given
		jimport('joomla.client.helper');
		//JClientHelper::setCredentialsFromRequest('ftp');

		// Make the filename safe
		jimport('joomla.filesystem.file');
		$file['name']	= JFile::makeSafe($file['name']);

		if (isset($file['name'])) {
			//check to make sure the directory is set
			if (!$pid > 0) {
				if ($format == 'json') {
					jimport('joomla.error.log');
					$log = &JLog::getInstance('upload.error.php');
					$log->addEntry(array('comment' => JText::_("WARN.SELECT_FOLDER_FIRST").': '.$err));
					header('HTTP/1.0 415 Unsupported Media Type');
					die(JText::_("WARN.SELECT_FOLDER_FIRST"));
				} else {
					JError::raiseNotice(100, JText::_($err));
					// REDIRECT
					if ($return) {
						$mainframe->redirect(base64_decode($return).'&folder='.$folder);
					}
					return;
				}
			}

			$parent = $model->getFile($pid);

			if (!$parent || !$parent->folder) {
				echo JText::_("ERROR.INVALID_PARENT_FOLDER");
				return;
			}
			$target_file_path = COM_ROKDOWNLOADS_BASE.$parent->path;
			$relative_target_file = JPath::clean($parent->path.DS.$file['name'],"/");
			$target_file = JPath::clean($target_file_path.DS.JFile::makeSafe($file['name']));
			

			if (0 != (int)$file['error']) {
				if ($format == 'json') {
					jimport('joomla.error.log');
					$log = &JLog::getInstance('upload.error.php');
					$log->addEntry(array('comment' => JText::_("ERROR.UPLOADER_REPORTED_ERROR").': '.$err));
					header('HTTP/1.0 400 Bad Request');
					die(JText::_("ERROR.UPLOADER_REPORTED_ERROR"));
				} else {
					JError::raiseNotice(100, JText::_($err));
					// REDIRECT
					if ($return) {
						$mainframe->redirect(base64_decode($return).'&folder='.$folder);
					}
					return;
				}
			}

			if (JFile::exists($target_file)) {
				if ($format == 'json') {
					jimport('joomla.error.log');
					$log = &JLog::getInstance('upload.error.php');
					$log->addEntry(array('comment' => JText::sprintf('ERROR.FILE_ALREADY_EXISTS', $relative_target_file)));
					header('HTTP/1.0 409 Conflict');
					die(JText::sprintf('ERROR.FILE_ALREADY_EXISTS', $relative_target_file));
				} else {
					JError::raiseNotice(100, JText::sprintf('ERROR.FILE_ALREADY_EXISTS', $relative_target_file));
					// REDIRECT
					if ($return) {
						$mainframe->redirect(base64_decode($return).'&folder='.$folder);
					}
					return;
				}
			}
			if (JFolder::exists($target_file)) {
				if ($format == 'json') {
					jimport('joomla.error.log');
					$log = &JLog::getInstance('upload.error.php');
					$log->addEntry(array('comment' => JText::sprintf('ERROR.FOLDER_ALREADY_EXISTS',$relative_target_file)));
					header('HTTP/1.0 409 Conflict');
					die(JText::sprintf('ERROR.FOLDER_ALREADY_EXISTS',$relative_target_file));
				} else {
					JError::raiseNotice(100, JText::sprintf('ERROR.FOLDER_ALREADY_EXISTS',$relative_target_file));
					// REDIRECT
					if ($return) {
						$mainframe->redirect(base64_decode($return).'&folder='.$folder);
					}
					return;
				}
			}

			if (!JFile::upload($file['tmp_name'], $target_file)) {
				if ($format == 'json') {
					jimport('joomla.error.log');
					$log = &JLog::getInstance('upload.error.php');
					$log->addEntry(array('comment' => JText::sprintf('ERROR.CANNOT_UPLOAD_FILE',$target_file_path)));
					header('HTTP/1.0 400 Bad Request');
					die(JText::sprintf('ERROR.CANNOT_UPLOAD_FILE',$target_file_path));
				} else {
					JError::raiseWarning(100, JText::sprintf('ERROR.CANNOT_UPLOAD_FILE',$target_file_path));
					// REDIRECT
					if ($return) {
						$mainframe->redirect(base64_decode($return).'&folder='.$folder);
					}
					return;
				}
			} else {
				if ($format == 'json') {
					jimport('joomla.error.log');
					$log = &JLog::getInstance();
					$log->addEntry(array('comment' => $folder));
					die('Upload complete');
				} else {
					$mainframe->enqueueMessage(JText::_('SUCCESS.UPLOAD_COMPLETE'));
					// REDIRECT
					if ($return) {
						$mainframe->redirect(base64_decode($return).'&folder='.$folder);
					}
					return;
				}
			}
		} else {
			$mainframe->redirect('index.php', 'Invalid Request', 'error');
		}
	}
	
	function uploadJava($tmpl=null) {
		
		global $mainframe;

		// Check for request forgeries
		//JRequest::checkToken( 'request' ) or die( 'Invalid Token' );
		JRequest::checkToken() or jexit( 'ERROR: Invalid Token' );
		
		$model	=& $this->getModel('rokdownloads');
		$err = null;
		$pid 		= JRequest::getInt('pid');
		$file 		= JRequest::getVar( 'Filedata', '', 'files', 'array' );
		$folder		= JRequest::getVar( 'folder', '', '', 'path' );
		$format		= JRequest::getVar( 'format', 'html', '', 'cmd');
		$return		= JRequest::getVar( 'return-url', null, 'post', 'base64' );
		$err		= null;

		//check to make sure the directory is set
		if (!$pid > 0) {
			echo "ERROR: " .JText::_("WARN.SELECT_FOLDER_FIRST");
			return;
		}

		$parent = $model->getFile($pid);

		if (!$parent || !$parent->folder) {
			echo "ERROR: ". JText::_("ERROR.INVALID_PARENT_FOLDER");
			return;
		}

		$relpathinfos = JRequest::getVar( 'relpathinfo', '-1', 'post', 'ARRAY' );
		$md5sums = JRequest::getVar( 'md5sum', '-1', 'post', 'ARRAY' );
		
		// associate paths with files
		$i=0;
		foreach ($_FILES as $file => $fileArray) {
			$dirpath = '';
			
			$source_file_path = $fileArray[ 'tmp_name' ];
			
			// See if we need a different relative path
			if ($relpathinfos[$i]){
				$dirpath = JPath::clean($relpathinfos[$i]);
			}

			$target_file_path = COM_ROKDOWNLOADS_BASE.$parent->path;
			if (JString::strlen($dirpath)>0) {
				$target_file_path .= DS.$dirpath;
			}
			$relative_target_file = JPath::clean($parent->path."/".$dirpath."/".$fileArray['name'], "/");
			$target_file = JPath::clean($target_file_path . DS. JFile::makeSafe($fileArray['name']));
		
			//check the md5sum to see if it matches
			if (md5_file($source_file_path) != $md5sums[$i]){
				echo "ERROR: ". JText::sprintf("MD5 Sum does not match for file %s.", $$relative_target_file);
				return;		
			}

			// make sure that php doesnt think there is an error			
			if ($fileArray['error'] != 0){
				echo "ERROR: ". JText::sprintf("Unknown error in uploading file %s.", $relative_target_file) ;
				return;	
			}
						
			//check to make sure the file doesnt already exsist
			if (JFile::exists($target_file)) {
				echo "ERROR: " . JText::sprintf("The file %s already exsists. Cannot overwrite.",  $relative_target_file);
				return;		
			}
			if (JFolder::exists($target_file)) {
				echo "ERROR: " . JText::sprintf("%s is a folder Cannot overwrite.",  $relative_target_file);
				return;	
			}
			
			//check for directory... create if its does not exist.
			if (!JFolder::exists($target_file_path)) {
				if (!JFolder::create($target_file_path)){
					echo "ERROR: " . JText::sprintf("Error creating directory %s",  $target_file_path);
					return;	
				}
			}
			//move tmp file to real file
			if( !JFile::upload( $source_file_path, $target_file) ) {
			    echo "ERROR: ". JText::sprintf("Unable to move uploaded file %s to %s", $source_file_path, $target_file_path);
			    return;
			}	
			$i++;
		}
		
		$model->importUnregisteredFolders();
		
		foreach ($relpathinfos as $key => $path) {
			$newfolder = $model->getFileFromPath($parent->path.DS.$path);
			//echo $newfolder->path + "\n";
			$model->importUnregisteredFiles($newfolder);
		}
		
		echo "SUCCESS";	
	}
}
?>