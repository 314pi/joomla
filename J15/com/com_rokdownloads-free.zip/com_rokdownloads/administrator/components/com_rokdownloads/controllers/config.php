<?php
/**
 * @version $Id: config.php 18489 2010-02-03 00:44:48Z btowles $
 * @package RocketTheme
 * @subpackage	RokDownloads
 * @copyright Copyright (C) 2008 RocketWerx. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 */


jimport( 'joomla.filesystem.folder' );
jimport( 'joomla.filesystem.file' );
jimport( 'joomla.filesystem.path' );

/**
 * @package		RocketTheme
 * @subpackage	RokDownloads
 * 
 * @since 1.5
 */
class RokdownloadsControllerConfig extends JController
{
	/**
	 * Custom Constructor
	 */
	function __construct( $default = array())
	{
		$default['default_task'] = 'edit';
		parent::__construct( $default );

		$this->registerTask( 'apply', 'save' );
	}

	/**
	 * Show the configuration edit form
	 * @param string The URL option
	 */
	function edit()
	{
		global $mainframe;
		$component = 'com_rokdownloads';

		// load the component's language file
		$lang = & JFactory::getLanguage();
		$lang->load( $component );

		JRequest::setVar('view', 'config');
		JRequest::setVar('component', $component);
		parent::display();
	}

	/**
	 * Save the configuration
	 */
	function save()
	{
		$component = JRequest::getVar( 'component' );

		$table =& JTable::getInstance('component');
		if (!$table->loadByOption( $component ))
		{
			JError::raiseWarning( 500, 'Not a valid component' );
			return false;
		}

		$post = JRequest::get( 'post' );
		$post['option'] = $component;
		
		// Clean up the root folder
		$downloads_root_folder  = trim($post['params']['downloads_root_folder_manage']);
		$downloads_root_folder = preg_replace('#[/\\\\]$#', '', $downloads_root_folder);
		// See if its a valid dir
		if (!JFolder::exists(JPath::clean(JPATH_SITE.DS.$downloads_root_folder))){
			JError::raiseWarning( 500, JText::_('Invalid Root Download Folders') );
			$this->setRedirect('index.php?option=com_rokdownloads&controller=config');
			return false;
		}
		$post['params']['downloads_root_folder_manage']=$downloads_root_folder;
		
		$thumbnail_folder = trim($post['params']['thumbnail_folder']);
		$thumbnail_folder = preg_replace('#[/\\\\]$#', '', $thumbnail_folder);
		// See if its a valid dir
		if (!JFolder::exists(JPath::clean(JPATH_SITE.DS.$thumbnail_folder))){
			JError::raiseWarning( 500, JText::_('Invalid Thumbnail Folder') );
			$this->setRedirect('index.php?option=com_rokdownloads&controller=config');
			return false;
		}
		$post['params']['thumbnail_folder']=$thumbnail_folder;
		
		$default_folder_thumb = trim($post['params']['default_folder_thumb']);
		// See if its a valid dir
		if (!JFile::exists(JPath::clean(JPATH_SITE.DS.$thumbnail_folder.DS.$default_folder_thumb))){
			JError::raiseWarning( 500, JText::_('Invalid Default Folder Icon') );
			$this->setRedirect('index.php?option=com_rokdownloads&controller=config');
			return false;
		}
		
		$default_file_thumb = trim($post['params']['default_file_thumb']);
		// See if its a valid dir
		if (!JFile::exists(JPath::clean(JPATH_SITE.DS.$thumbnail_folder.DS.$default_file_thumb))){
			JError::raiseWarning( 500, JText::_('Invalid Default File Icon') );
			$this->setRedirect('index.php?option=com_rokdownloads&controller=config');
			return false;
		}
		
		$table->bind( $post );
		// pre-save checks
		if (!$table->check()) {
			JError::raiseWarning( 500, $table->getError() );
			return false;
		}

		// save the changes
		if (!$table->store()) {
			JError::raiseWarning( 500, $table->getError() );
			return false;
		}

		//$this->setRedirect( 'index.php?option=com_config', $msg );
		$msg = "Configuration has been saved";
		$this->setRedirect('index.php?option=com_rokdownloads&controller=config', $msg);
	}

	/**
	 * Cancel operation
	 */
	function cancel()
	{
		$this->setRedirect('index.php?option=com_rokdownloads&controller=config');
	}
}