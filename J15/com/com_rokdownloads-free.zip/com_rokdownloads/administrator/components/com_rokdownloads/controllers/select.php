<?php
/**
 * @version $Id: rokdownload.php 8294 2009-01-25 08:08:03Z btowles $
 * @package RocketTheme
 * @subpackage	RokDownloads
 * @copyright Copyright (C) 2008 RocketWerx. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 */


// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

/**
 * RokDownload Controller Rokdownload
 *
 * @package		RocketTheme
 * @subpackage	RokDownloads
 *
 * @since 1.5
 */
class RokdownloadsControllerSelect extends RokdownloadsController
{
	function __construct()
	{
		parent::__construct();

		// Register Extra tasks
		//$this->registerDefaultTask('edit' );
	}
}
?>
