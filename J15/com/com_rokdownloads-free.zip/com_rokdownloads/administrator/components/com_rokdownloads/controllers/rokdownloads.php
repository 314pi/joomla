<?php
/**
 * @version $Id: rokdownloads.php 18489 2010-02-03 00:44:48Z btowles $
 * @package RocketTheme
 * @subpackage	RokDownloads
 * @copyright Copyright (C) 2008 RocketWerx. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 */
 
// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

/**
 * Rokdownloads Component Controller Rokdownloads
 *
 * @package		RocketTheme
 * @subpackage	RokDownloads
 *
 * @since 1.5
 */
class RokdownloadsControllerRokdownloads extends RokdownloadsController
{
	/**
	 * Custom Constructor
	 */
	function __construct( $default = array())
	{
		$default['default_task'] = 'display';
		parent::__construct( $default );
	}

	/**
	 * Show the main rokdownloads files page
	 */
	function display()
	{
		global $mainframe;
		$component = 'com_rokdownloads';
		// load the component's language file
		$lang = & JFactory::getLanguage();
		$lang->load( $component );
		parent::display();
	}

	function getfolders()
	{
		$component = 'com_rokdownloads';
		// load the component's language file
		$lang = & JFactory::getLanguage();
		$lang->load( $component );
		// Set the default view name from the Request
		JRequest::setVar('view', 'rokdownloads');
		JRequest::setVar('component', $component);
		JRequest::setVar('format', 'raw');

		$view = &$this->getView('rokdownloads','raw');

		// Push a model into the view
		$model	= &$this->getModel( 'rokdownloads' );
		if (!JError::isError( $model )) {
			$view->setModel( $model, true );
		}
		$view->getfolders();
	}
	
	function getsubfolders()
	{
		$component = 'com_rokdownloads';
		// load the component's language file
		$lang = & JFactory::getLanguage();
		$lang->load( $component );
		// Set the default view name from the Request
		JRequest::setVar('view', 'rokdownloads');
		JRequest::setVar('component', $component);
		JRequest::setVar('format', 'raw');

		$view = &$this->getView('rokdownloads','raw');

		// Push a model into the view
		$model	= &$this->getModel( 'rokdownloads' );
		if (!JError::isError( $model )) {
			$view->setModel( $model, true );
		}
		$view->getsubfolders();
	}

	function getFilesForFolder()
	{

		$component = 'com_rokdownloads';
		// load the component's language file
		$lang = & JFactory::getLanguage();
		$lang->load( $component );
		// Set the default view name from the Request
		JRequest::setVar('view', 'rokdownloads');
		JRequest::setVar('component', $component);
		JRequest::setVar('format', 'raw');

		$view = &$this->getView('rokdownloads','raw');

		// Push a model into the view
		$model	= &$this->getModel( 'rokdownloads' );
		if (!JError::isError( $model )) {
			$view->setModel( $model, true );
		}
		$view->getFilesForFolder();
	}
	function move()
	{
		$component = 'com_rokdownloads';
		// load the component's language file
		$lang = & JFactory::getLanguage();
		$lang->load( $component );
		// Set the default view name from the Request
		JRequest::setVar('view', 'rokdownloads');
		JRequest::setVar('component', $component);
		JRequest::setVar('format', 'raw');
		$view = &$this->getView('rokdownloads','raw');
		// Push a model into the view
		$model	= &$this->getModel( 'rokdownloads' );
		if (!JError::isError( $model )) {
			$view->setModel( $model, true );
		}
		$view->move();
		$this->cleanCache();
	}
	
	
	function upload()
	{
		$component = 'com_rokdownloads';
		// load the component's language file
		$lang = & JFactory::getLanguage();
		$lang->load( $component );
		// Set the default view name from the Request
		JRequest::setVar('view', 'rokdownloads');
		JRequest::setVar('component', $component);
		JRequest::setVar('format', 'raw');
		$view = &$this->getView('rokdownloads','raw');
		// Push a model into the view
		$model	= &$this->getModel( 'rokdownloads' );
		if (!JError::isError( $model )) {
			$view->setModel( $model, true );
		}
		$view->upload();
		$this->cleanCache();
	}
	
	function uploadselect() {
		global $mainframe;
		$component = 'com_rokdownloads';
		// load the component's language file
		$lang = & JFactory::getLanguage();
		$lang->load( $component );
		JRequest::setVar('view', 'rokdownloads');
		JRequest::setVar('component', $component);
		JRequest::setVar('layout', 'uploadselect');
		$view = &$this->getView('rokdownloads','html');
		$model	= &$this->getModel( 'rokdownloads' );
		if (!JError::isError( $model )) {
			$view->setModel( $model, true );
		}
		$view->uploadSelect();
		$this->cleanCache();
	}
	
	function newfolder() {
		global $mainframe;
		$component = 'com_rokdownloads';
		// load the component's language file
		$lang = & JFactory::getLanguage();
		$lang->load( $component );
		JRequest::setVar('view', 'rokdownloads');
		JRequest::setVar('component', $component);
		JRequest::setVar('layout', 'uploadselect');
		$view = &$this->getView('rokdownloads','html');
		$model	= &$this->getModel( 'rokdownloads' );
		if (!JError::isError( $model )) {
			$view->setModel( $model, true );
		}
		$view->newfolder();
		$this->cleanCache();
	}
	
	function movefiles() {
		global $mainframe;
		$component = 'com_rokdownloads';
		// load the component's language file
		$lang = & JFactory::getLanguage();
		$lang->load( $component );
		JRequest::setVar('view', 'rokdownloads');
		JRequest::setVar('component', $component);
		JRequest::setVar('layout', 'uploadselect');
		$view = &$this->getView('rokdownloads','html');
		$model	= &$this->getModel( 'rokdownloads' );
		if (!JError::isError( $model )) {
			$view->setModel( $model, true );
		}
		$view->movefiles();
		$this->cleanCache();
	}
	
	function delete()
	{
		$component = 'com_rokdownloads';
		// load the component's language file
		$lang = & JFactory::getLanguage();
		$lang->load( $component );
		// Set the default view name from the Request
		JRequest::setVar('view', 'rokdownloads');
		JRequest::setVar('component', $component);
		JRequest::setVar('format', 'raw');
		$view = &$this->getView('rokdownloads','raw');
		// Push a model into the view
		$model	= &$this->getModel( 'rokdownloads' );
		if (!JError::isError( $model )) {
			$view->setModel( $model, true );
		}
		$view->delete();
		$this->cleanCache();
	}
	
	function publish()
	{
		$component = 'com_rokdownloads';
		// load the component's language file
		$lang = & JFactory::getLanguage();
		$lang->load( $component );
		// Set the default view name from the Request
		JRequest::setVar('view', 'rokdownloads');
		JRequest::setVar('component', $component);
		JRequest::setVar('format', 'raw');
		$view = &$this->getView('rokdownloads','raw');
		// Push a model into the view
		$model	= &$this->getModel( 'rokdownloads' );
		if (!JError::isError( $model )) {
			$view->setModel( $model, true );
		}
		$view->publish();
		$this->cleanCache();
	}
	
	function unpublish()
	{
		$component = 'com_rokdownloads';
		// load the component's language file
		$lang = & JFactory::getLanguage();
		$lang->load( $component );
		// Set the default view name from the Request
		JRequest::setVar('view', 'rokdownloads');
		JRequest::setVar('component', $component);
		JRequest::setVar('format', 'raw');
		$view = &$this->getView('rokdownloads','raw');
		// Push a model into the view
		$model	= &$this->getModel( 'rokdownloads' );
		if (!JError::isError( $model )) {
			$view->setModel( $model, true );
		}
		$view->unpublish();
		$this->cleanCache();
	}
	function addnewfolder()
	{
		$component = 'com_rokdownloads';
		// load the component's language file
		$lang = & JFactory::getLanguage();
		$lang->load( $component );
		// Set the default view name from the Request
		JRequest::setVar('view', 'rokdownloads');
		JRequest::setVar('component', $component);
		JRequest::setVar('format', 'raw');
		$view = &$this->getView('rokdownloads','raw');
		// Push a model into the view
		$model	= &$this->getModel( 'rokdownloads' );
		if (!JError::isError( $model )) {
			$view->setModel( $model, true );
		}
		$view->addnewfolder();
		$this->cleanCache();
	}
}
