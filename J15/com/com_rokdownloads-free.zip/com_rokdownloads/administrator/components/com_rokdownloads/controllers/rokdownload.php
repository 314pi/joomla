<?php
/**
 * @version $Id: rokdownload.php 18489 2010-02-03 00:44:48Z btowles $
 * @package RocketTheme
 * @subpackage	RokDownloads
 * @copyright Copyright (C) 2008 RocketWerx. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 */


// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

/**
 * RokDownload Controller Rokdownload
 *
 * @package		RocketTheme
 * @subpackage	RokDownloads
 *
 * @since 1.5
 */
class RokdownloadsControllerRokdownload extends RokdownloadsController
{
	function __construct()
	{
		parent::__construct();

		// Register Extra tasks
		//$this->registerDefaultTask('edit' );
	}


	function save()
	{
		global $mainframe;
		$model = $this->getModel('rokdownload');
		$rdsmodel =  $this->getModel('rokdownloads');
		
		$post	= JRequest::get('post');
		$cid	= JRequest::getVar( 'cid', array(0), 'post', 'array' );
		$post['id'] = $cid[0];
		
		$retstore = $model->store($post, $rdsmodel);
		if ($retstore >= 0) {
			$msg = JText::_( 'Item Saved' );
			$mainframe->enqueueMessage($msg);
			// Check the item in so that it can be edited by someone else
			$model->checkin($post['id']);
			$this->setRedirect('index.php?option=com_rokdownloads&controller=rokdownloads&selectedFolder='.$retstore);
		} else {
			$msg = JText::_( $model->getError() );
			$mainframe->enqueueMessage($msg, 'error');
			$this->setRedirect('index.php?option=com_rokdownloads&controller=rokdownload&task=display&view=rokdownload&layout=form&fid='.$post['id']);
		}
		$this->cleanCache();
	}
	function apply()
	{
		global $mainframe;
		$model = $this->getModel('rokdownload');
		$rdsmodel =  $this->getModel('rokdownloads');
		
		$post	= JRequest::get('post');
		$cid	= JRequest::getVar( 'cid', array(0), 'post', 'array' );
		$post['id'] = $cid[0];
		
		$retstore = $model->store($post, $rdsmodel);
		if ($retstore >= 0) {
			$msg = JText::_( 'Item Saved' );
			$mainframe->enqueueMessage($msg);
			// Check the item in so that it can be edited by someone else
			$this->setRedirect('index.php?option=com_rokdownloads&controller=rokdownload&task=display&view=rokdownload&layout=form&fid='.$post['id']);
		} else {
			$msg = JText::_( $model->getError() );
			$mainframe->enqueueMessage($msg, 'error');
			$this->setRedirect('index.php?option=com_rokdownloads&controller=rokdownload&task=display&view=rokdownload&layout=form&fid='.$post['id']);
		}
		$this->cleanCache();
	}

	function cancel()
	{
		$model = $this->getModel('rokdownload');
		$post	= JRequest::get('post');
		$cid	= JRequest::getVar( 'cid', array(0), 'post', 'array' );
		$post['id'] = $cid[0];
		$model->checkin($post['id']);

		$parentid = 1;
		if ($post['id'] != 1) { 		
			$parentid = $model->getParentId($post['id']);
		}
		$this->setRedirect('index.php?option=com_rokdownloads&controller=rokdownloads&selectedFolder='.$parentid);
	}
	
	function resetStats()
	{
		$component = 'com_rokdownloads';
		// load the component's language file
		$lang = & JFactory::getLanguage();
		$lang->load( $component );
		// Set the default view name from the Request
		JRequest::setVar('view', 'rokdownload');
		JRequest::setVar('component', $component);
		JRequest::setVar('format', 'raw');
		$view = &$this->getView('rokdownload','raw');
		// Push a model into the view
		$model	= &$this->getModel( 'rokdownload' );
		if (!JError::isError( $model )) {
			$view->setModel( $model, true );
		}
		$view->resetStats();
		$this->cleanCache();
	}
}
?>
