<?php
/**
 * @version $Id: controller.php 18489 2010-02-03 00:44:48Z btowles $
 * @package RocketTheme
 * @subpackage	RokDownloads
 * @copyright Copyright (C) 2008 RocketWerx. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport('joomla.application.component.controller');
jimport('joomla.application.component.helper');

/**
 * Rokdownloads Component Controller
 *
 * @package		RocketTheme
 * @subpackage	RokDownloads
 *
 * @since 1.5
 */
class RokdownloadsController extends JController
{
	function __construct() {
		parent::__construct();

			$this->refreshConfigCache();
	}

	function refreshConfigCache(){
		jimport('joomla.filesystem.folder');
		global $mainframe, $option;
		$params = &JComponentHelper::getParams($option);

		$key_manage = 'downloads_root_folder_manage';
		$key_thumbfolder = 'thumbnail_folder';

		$rootFolderManage = $params->get($key_manage);
		$thumbfolder = $params->get($key_thumbfolder);

		if (empty($rootFolderManage)) {
			$mainframe->enqueueMessage(JText::_("WARN.COMPONENT_NOT_CONFIGURED"), 'error');
			$mainframe->redirect('index.php?option=com_rokdownloads&controller=config');
		}
		
		// remove end directpory seperator
		
		if ( strrpos(trim($rootFolderManage),"/") == strlen(trim($rootFolderManage))-1 || strrpos(trim($rootFolderManage),"\\") == strlen(trim($rootFolderManage))-1 ){
			$rootFolderManage = substr(trim($rootFolderManage),0,strlen(trim($rootFolderManage))-1);
		}
		

		define('COM_ROKDOWNLOADS_FOLDER',$rootFolderManage);
		define('COM_ROKDOWNLOADS_BASE', JPATH_SITE.DS.COM_ROKDOWNLOADS_FOLDER);
		if (!JFolder::exists(COM_ROKDOWNLOADS_BASE)){
			$mainframe->enqueueMessage(JText::_("WARNING.DOWNLOAD_ROOT_FOLDER_IS_INVALID"), 'error');
			$mainframe->redirect('index.php?option=com_rokdownloads&controller=config');
		}
		
		
		
		define('COM_ROKDOWNLOADS_BASEURL', $mainframe->getSiteURL().COM_ROKDOWNLOADS_FOLDER);
		define('THUMB_FOLDER', $thumbfolder);
	}
	
	function cleanCache(){
		$cache =& JFactory::getCache('', 'callback', 'file');
		$cache->clean( 'com_rokdownloads_router' );
		$cache->clean( 'mod_rokdownloads_latest-public');
		$cache->clean( 'mod_rokdownloads_latest-registered');
		$cache->clean( 'mod_rokdownloads_latest-special');
		$cache->clean( 'mod_rokdownloads_recent_updates-public');
		$cache->clean( 'mod_rokdownloads_recent_updates-registered');
		$cache->clean( 'mod_rokdownloads_recent_updates-special');
		$cache->clean( 'mod_rokdownloads_most_downloaded-public');
		$cache->clean( 'mod_rokdownloads_most_downloaded-registered');
		$cache->clean( 'mod_rokdownloads_most_downloaded-special');
	}

	function display() {

		$vName = JRequest::getCmd('task', 'display');
		switch ($vName)
		{
            case 'display':
                parent::display();
                break;
			case 'select':
			default:
				$mName = 'select';
				$vName = 'select';
                $document = &JFactory::getDocument();
                $vType		= $document->getType();

                // Get/Create the view
                $view = &$this->getView($vName, $vType);

                $view->addTemplatePath(JPATH_COMPONENT_ADMINISTRATOR.DS.'views'.DS.strtolower($vName).DS.'tmpl');

                // Get/Create the model
                if ($model = &$this->getModel($mName)) {
                    // Push the model into the view (as default)
                    $view->setModel($model, true);
                }
                // Display the view
                $view->display();
				break;
		}
	}
}
?>
