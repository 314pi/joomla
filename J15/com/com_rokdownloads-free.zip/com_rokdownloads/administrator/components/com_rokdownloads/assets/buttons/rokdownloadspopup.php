<?php
/**
 * @version $Id: rokdownloadspopup.php 18489 2010-02-03 00:44:48Z btowles $
 * @package RocketTheme
 * @subpackage	RokDownloads
 * @copyright Copyright (C) 2008 RocketWerx. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 */

// Check to ensure this file is within the rest of the framework
defined('JPATH_BASE') or die();

/**
 * Renders a RokDownloads Popup button
 *
 * @package		RocketTheme
 * @subpackage	RokDownloads
 *
 * @since 1.5
 */
class JButtonRokDownloadsPopup extends JButton
{
	/**
	 * Button type
	 *
	 * @access	protected
	 * @var		string
	 */
	var $_name = 'RokDownloadsPopup';

	function fetchButton( $type='RokDownloadsPopup', $name = '', $text = '', $popupfunction = 'RokPopup', $params = array())
	{
		$i18n_text	= JText::_($text);
		$class	= $this->fetchIconClass($name);
		
		JHTML::_('behavior.modal', 'a.modal', $params);
		$html = "<a href=\"#\" onclick=\"$popupfunction();return false;\" class=\"toolbar\">\n";
		$html .= "<span class=\"$class\" title=\"$i18n_text\">\n";
		$html .= "</span>\n";
		$html .= "$i18n_text\n";
		$html .= "</a>\n";
		return $html;
	}

	/**
	 * Get the button CSS Id
	 *
	 * @access	public
	 * @return	string	Button CSS Id
	 * @since	1.5
	 */
	function fetchId( $type='RokDownloadsPopup', $name = '', $text = '', $task = '', $list = true, $hideMenu = false )
	{
		return $this->_parent->_name.'-'.$name;
	}
}