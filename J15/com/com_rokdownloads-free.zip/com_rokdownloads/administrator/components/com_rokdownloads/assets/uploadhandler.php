<?php
jimport('joomla.utilities.error');
global $mainframe;
return JError::raiseError( 500, 'Layout "' . $file . '" not found' );
$err = 'calling me';
JResponse::setVar( 'Error', $err  );
return;

$err = null;
$folder = JRequest::getVar( 'dirPath', '-1', 'post', 'string' );
if ($folder=='-1') {
	$err = JText::_('WARN.SELECT_FOLDER_FIRST');
	JRequest::setVar( 'msg', $err  );
	JRequest::setVar('layout', 'jumpUpload');
	parent::display($tmpl);
}

//
//    retrieve request parameters
$file_param_name = 'file';
$file = JRequest::getVar($file_param_name,array(), 'files','array');
$file_name = $file[ 'name' ];
$file_id = JRequest::getString('fileId', '', 'post');
$partition_index = JRequest::getInt('partitionIndex', -1, 'post');
$partition_count = JRequest::getInt('partitionCount', -1, 'post');
$file_length = JRequest::getInt('fileLength', 0, 'post');

//
//    the $client_id is an essential variable,
//    this is used to generate uploaded partitions file prefix,
//    because we can not rely on 'fileId' uniqueness in a
//    concurrent environment - 2 different clients (applets)
//    may submit duplicate fileId. thus, this is responsibility
//    of a server to distribute unique clientId values
//    (or other variable, for example this could be session id)
//    for instantiated applets.
$client_id = JRequest::getString('clientId', null, 'get');

//
//    move uploaded partition to the staging folder
//    using following name pattern:
//    ${clientId}.${fileId}.${partitionIndex}
$source_file_path = $_FILES[ $file_param_name ][ 'tmp_name' ];
$target_file_path = $stage_dir . $client_id . "." . $file_id .
    "." . $partition_index;
if( !JFile::upload( $source_file_path, $target_file_path ) ) {
    echo JText::_('ERROR.CANT_MOVE_UPLOADED_FILE');
    return;
}

//
//    check if we have collected all partitions properly
$all_in_place = true;
$partitions_length = 0;
for( $i = 0; $all_in_place && $i < $partition_count; $i++ ) {
    $partition_file = $stage_dir . $client_id . "." . $file_id . "." . $i;
    if( file_exists( $partition_file ) ) {
        $partitions_length += filesize( $partition_file );
    } else {
        $all_in_place = false;
    }
}

//
//    issue error if last partition uploaded, but partitions validation failed
if( $partition_index == $partition_count - 1 &&
        ( !$all_in_place || $partitions_length != intval( $file_length ) ) ) {
    echo JText::_('ERROR.UPLOAD_VALIDATION_ERROR');
    return;
}

//
//    reconstruct original file if all ok
if( $all_in_place ) {
    $file = $upload_dir . $client_id . "." . $file_id;
    $file_handle = fopen( $file, 'a' );
    for( $i = 0; $all_in_place && $i < $partition_count; $i++ ) {
        //
        //    read partition file
        $partition_file = $stage_dir . $client_id . "." . $file_id . "." . $i;
        $partition_file_handle = fopen( $partition_file, "rb" );
        $contents = fread( $partition_file_handle, filesize( $partition_file ) );
        fclose( $partition_file_handle );
        //
        //    write to reconstruct file
        fwrite( $file_handle, $contents );
        //
        //    remove partition file
        unlink( $partition_file );
    }
    fclose( $file_handle );
}
JRequest::setVar( 'msg', $err  );
JRequest::setVar('layout', 'jumpUpload');
	parent::display($tmpl);


?>