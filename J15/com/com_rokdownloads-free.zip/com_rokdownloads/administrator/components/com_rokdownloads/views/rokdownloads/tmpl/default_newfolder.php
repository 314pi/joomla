<?php 
/**
 * @version $Id: default_newfolder.php 18489 2010-02-03 00:44:48Z btowles $
 * @package RocketTheme
 * @subpackage	RokDownloads
 * @copyright Copyright (C) 2008 RocketWerx. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 */
defined('_JEXEC') or die('Restricted access');
?>
<script type="text/javascript">
window.addEvent('load', function() {
    (function(){$('newfoldername').focus()}).delay(50);
});

function createNewFolder() {
	window.top.selectedFolder=<?php echo $this->parent->id;?>;
	if (!document.adminForm.newfolder.value.length > 0) {
		alert('<?php echo JText::_("WARN.NO_NAME_OF_FOLDER");?>');
		return false;
	}
	window.top.addnewfolder(document.adminForm.newfolder.value, <?php echo $this->parent->id;?>, window.top.successRefreshTree.bind(window.top.tree.selected), window.top.comError);
	window.top.SqueezeBox.close();
}
	var pnode = window.top.tree.selected;
</script>
<div id="msg" style="font-size:small;font-weight:bold;color:#CC0000;font-family: Helvetica, sans-serif;"><?php echo $this->msg ?></div>
<br></br>
<form method="post" action="index.php" enctype="multipart/form-data" name="adminForm" onsubmit="createNewFolder();">
	<table>
		<tr>
			<td nowrap="nowrap">
				<label><?php echo  JText::sprintf( 'LABEL.ADDING_FOLDER_UNDER', $this->parent->path); ?></label>
			</td>
		</tr>
		<tr>
			<td>
				<fieldset>
					<input class="inputbox" name="newfolder" id="newfoldername" type="text" size="25" /><input class="button" type="button" value="<?php echo  JText::_( 'LABEL.CREATE' ); ?>" name="newfoldersubmit" onclick="createNewFolder();" />
				</fieldset>
			</td>
		</tr>
	</table>
	<input type="hidden" name="option" value="com_rokdownloads" />
	<input type="hidden" name="controller" value="rokdownloads"/>
	<input type="hidden" name="tmpl" value="newfolder" />
	<input type="hidden" name="task" value="newfolder" />
</form>