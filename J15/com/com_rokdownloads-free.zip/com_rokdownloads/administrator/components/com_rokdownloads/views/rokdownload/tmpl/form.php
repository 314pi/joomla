<?php 
/**
 * @version $Id: form.php 18489 2010-02-03 00:44:48Z btowles $
 * @package RocketTheme
 * @subpackage	RokDownloads
 * @copyright Copyright (C) 2008 RocketWerx. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 */
defined('_JEXEC') or die('Restricted access'); 

?>
<script language="javascript" type="text/javascript">
	function submitbutton(pressbutton) {
		var form = document.adminForm;
		if (pressbutton == 'cancel') {
			submitform( pressbutton );
			return;
		}

		if (pressbutton == 'save' || pressbutton == 'apply') {
			// do field validation
			if (form.name.value == ""){
				alert( "<?php echo JText::_( 'ERROR.DOWNLOAD_ITEM_MUST_HAVE_NAME', true ); ?>" );
			} else {
				submitform( pressbutton );
			}	
		}
	}
	
	function resetStats() {
		parameteredAjaxCall({id: <?php echo $this->rokdownload->id; ?>}, "<?php echo $this->ajaxURI; ?>resetStats", successResetStats, comError);
	}
	
	function parameteredAjaxCall(send, url, success, failure) {
		var myXHR = new XHR(url, {headers: {'X-Request': 'JSON'}});
	    myXHR.addEvent('onFailure', failure);
		myXHR.addEvent('onSuccess', success);
		myXHR.send(url, 'json=' + Json.toString(send));			
	}
	
	var comError = function(result){
		alert("<?php  echo JText::_('ERROR.COMMUNICATIONS_ERROR'); ?>");
		tree.enable();
	}
	
	var successResetStats = function(result){
		// check to make sure its a valid return  not a logged off
		if (result == '') {
			redirectToLogin();
		}
		jsondata = Json.evaluate(result);
		if (!jsondata.result) {
				alert(jsondata.errormsg);
		}
		document.getElementById('file_stats').innerHTML = '0';
		document.adminForm.downloads.value='0';
	}
	
</script>
<style type="text/css">
	table.paramlist td.paramlist_key {
		width: 92px;
		text-align: left;
		height: 30px;
	}
</style>

<form action="index.php" method="post" name="adminForm">
	<table cellspacing="0" cellpadding="0" border="0" width="100%">
		<tr>
			<td valign="top">
		<fieldset class="adminform">
			<legend for="text" class="hasTip" title="<?php echo JText::_( 'LABEL.DETAILS' ); ?>::<?php echo JText::_('TIP.NODE_DETAILS');?>"> <?php echo JText::_( 'LABEL.DETAILS' ); ?></legend>

			<table class="admintable">

			<tr>
				<td width="100" align="right" class="key">
					<label for="name" class="hasTip" title="<?php echo ($this->rokdownload->folder)? JText::_('LABEL.FOLDER_NAME'): JText::_( 'LABEL.FILE_NAME' ); ?>::<?php echo JText::_('TIP.NAME_ON_FILESYSTEM');?>">
						<?php echo ($this->rokdownload->folder)? JText::_('LABEL.FOLDER_NAME'): JText::_( 'LABEL.FILE_NAME' ); ?>:
					</label>
				</td>
				<td>
					<input class="inputbox" type="text" name="name" id="name" size="40" maxlength="255" <?php if ($this->rokdownload->id == 1) : echo 'disabled="true"'; endif;?> value="<?php echo $this->rokdownload->name;?>"/>
				</td>
			</tr>
			<tr>
				<td width="100" align="right" class="key">
					<label for="displayname" class="hasTip" title="<?php echo JText::_( 'LABEL.DISPLAY_NAME' ); ?>::<?php echo JText::_('TIP.DISPLAY_NAME');?>">
						<?php echo JText::_( 'LABEL.DISPLAY_NAME' ); ?>:
					</label>
				</td>
				<td>
					<input class="inputbox" type="text" name="displayname" id="displayname" size="40" maxlength="255" value="<?php echo $this->rokdownload->displayname;?>" />
					
				</td>
			</tr>
			<tr>
				<td width="100" align="right" class="key">
					<label for="parentid" class="hasTip" title="<?php echo JText::_( 'LABEL.PARENT_FOLDER' ); ?>::<?php echo JText::_('TIP.PARENT_FOLDER');?>">
						<?php echo JText::_( 'LABEL.PARENT_FOLDER' ); ?>:
					</label>
				</td>
				<td>
					<?php
						 if ($this->rokdownload->id == 1) :
					?>
							<?php echo JText::_("LABEL.ROOT_FOLDER");?>
							<input class="text_area" type="hidden" name="parentid" id="name" size="32" maxlength="250" value="0" />
					<?php
						 
						 else :
							echo $this->lists['folders'];
						 endif;
					?>
				</td>
			</tr>
			<tr>
				<td valign="top" align="right" class="key">
					<label for="published" class="hasTip" title="<?php echo JText::_( 'Published' ); ?>::<?php echo JText::_('TIP.PUBLISHED');?>">
						<?php echo JText::_( 'Published' ); ?>:
					</label>
				</td>
				<td>
					<?php echo $this->lists['published']; ?>
				</td>
			</tr>
			<tr>
				<td class="key" valign="top" align="right">
					<label for="access" class="hasTip" title="<?php echo ($this->rokdownload->folder)? JText::_( 'LABEL.DISPLAY_ACCESS_LEVEL' ): JText::_( 'LABEL.DOWNLOAD_ACCESS_LEVEL' ); ?>::<?php echo  ($this->rokdownload->folder)?JText::_('TIP.DISPLAY_ACCESS_LEVEL'):JText::_('TIP.DOWNLOAD_ACCESS_LEVEL');?>">
						<?php echo ($this->rokdownload->folder)? JText::_( 'LABEL.DISPLAY_ACCESS_LEVEL' ): JText::_( 'LABEL.DOWNLOAD_ACCESS_LEVEL' ); ?>:
					</label>
				</td>
				<td>
					<?php echo JHTML::_('list.accesslevel',  $this->rokdownload); ?>
				</td>
			</tr>
			<tr>
				<td class="key">
					<label for="thumbnail" class="hasTip" title="<?php echo JText::_( 'LABEL.THUMB_IMAGE' ); ?>::<?php echo JText::_('TIP.THUMB_IMAGE');?>">
						<?php echo JText::_( 'LABEL.THUMB_IMAGE' ); ?>:
					</label>
				</td>
				<td>
					<?php echo $this->lists['image']; ?>
				</td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td>
				<script language="javascript" type="text/javascript">
				if (document.forms[0].thumbnail.options.value!=''){
					jsimg='<?php echo "../".THUMB_FOLDER?>' + getSelectedValue( 'adminForm', 'thumbnail' );
				} else {
					jsimg='../images/M_images/blank.png';
				}
				document.write('<img src=' + jsimg + ' name="imagelib" width="32" height="32" border="2" alt="<?php echo JText::_( 'Preview', true ); ?>" />');
				</script>
				</td>
			</tr>
		</table>
		</fieldset>
		<fieldset class="adminform">
			<legend for="text" class="hasTip" title="<?php echo JText::_( 'Description' ); ?>::<?php echo JText::_('TIP.DESCRIPTION'); ?>"><?php echo JText::_( 'Description' ); ?></legend>
			<table class="adminform">
			<tr>
				<td>
					<?php
					// parameters : areaname, content, width, height, cols, rows
					echo $this->editor->display( 'text',  $this->text , '100%', '350', '75', '20', array('pagebreak') ) ;
					?>
				</td>
			</tr>
			</table>
		</fieldset>
	</td>
	<td valign="top" width="320" style="padding: 7px 0 0 5px">
		
		<table width="100%" style="border: 1px dashed silver; padding: 5px; margin-bottom: 10px;">
		<tr>
			<td>
				<label for="id_stat" class="hasTip" title="<?php echo JText::_( 'LABEL.ID' ); ?>::<?php echo JText::_( 'LABEL.ID' ); ?>"><strong><?php echo JText::_( 'LABEL.ID' ); ?>:</strong></label>
			</td>
			<td>
				<?php echo ($this->rokdownload->id);?>
			</td>
		</tr>
		<tr>
			<td>
				<label for="state_stat" class="hasTip" title="<?php echo JText::_( 'State' ); ?>::<?php echo JText::_( 'TIP.DOWNLOAD_STATE' ); ?>"><strong><?php echo JText::_( 'State' ); ?>:</strong></label>
			</td>
			<td>
				<?php echo ($this->rokdownload->published)?JText::_( 'Published' ):JText::_( 'Unpublished' );?>
			</td>
		</tr>
		<?php if (!$this->rokdownload->folder) : // only show details for files ?>
		<tr>
			<td>
				<label for="filesize_stat" class="hasTip" title="<?php echo JText::_( 'LABEL.FILE_SIZE' ); ?>::<?php echo JText::_( 'TIP.FILE_SIZE' ); ?>"><strong><?php echo JText::_( 'LABEL.FILE_SIZE' ); ?>:</strong></label>
			</td>
			<td>
				<?php echo filesize_format($this->rokdownload->filesize, '%01.1f %s');?>
				<input type="hidden" name="filesize" id="filesize" value="<?php echo $this->rokdownload->filesize; ?>" size="32" maxlength="250" />
			</td>
		</tr>
		<tr>
			<td>
				<label for="downloads_stat" class="hasTip" title="<?php echo JText::_( 'Downloads' ); ?>::<?php echo JText::_( 'TIP.FILE_DOWNLOADS' ); ?>"><strong><?php echo JText::_( 'Downloads' ); ?>:</strong></label>
			</td>
			<td>
				<span id="file_stats"><?php echo $this->rokdownload->downloads;?></span>
				<span>
					<input name="reset_hits" type="button" class="button" value="<?php echo JText::_( 'Reset' ); ?>" onclick="resetStats();" />
				</span>
			</td>
		</tr>
		<?php endif; ?>
		<tr>
			<td>
				<label for="created_stat" class="hasTip" title="<?php echo JText::_( 'LABEL.CREATED' ); ?>::<?php echo JText::_( 'TIP.CREATED' ); ?>"><strong><?php echo JText::_( 'LABEL.CREATED' ); ?>:</strong></label>
			</td>
			<td>
				<?php
				if ( $this->rokdownload->created_time == $this->nullDate ):
					echo JText::_( 'LABEL.NEW_DOWNLOAD' );
				else:
					echo JHTML::_('date',  $this->rokdownload->created_time,  JText::_('DATE_FORMAT_LC2') );
				endif;
				?>
			</td>
		</tr>
		<tr>
			<td>
				<label for="modified_stat" class="hasTip" title="<?php echo JText::_( 'LABEL.MODIFIED' ); ?>::<?php echo JText::_( 'TIP.MODIFIED' ); ?>"><strong><?php echo JText::_( 'LABEL.MODIFIED' ); ?>:</strong></label>
			</td>
			<td>
				<?php
					if ( $this->rokdownload->modified_time == $this->nullDate ):
						echo JText::_( 'LABEL.NOT_MODIFIED' );
					else:
						echo JHTML::_('date',  $this->rokdownload->modified_time, JText::_('DATE_FORMAT_LC2'));
					endif;
				?>
			</td>
		</tr>
		</table>
		

		<?php
			echo $this->pane->startPane("params-pane");
			
			if (!$this->rokdownload->folder && $this->customparams != false):
				$title = JText::_( 'LABEL.PARAMETERS_CUSTOM' );
				echo $this->pane->startPanel( $title, "params-page" );
				echo $this->customparams->render('customparams');
				echo $this->pane->endPanel();
				
			endif;
			
			if (!$this->rokdownload->folder):
				$title = JText::_( 'LABEL.PARAMETERS_ARTICLE' );
				echo $this->pane->startPanel( $title, "detail-page" );
				echo $this->params->render('params');
				echo $this->pane->endPanel();
			endif;
			
			$title = JText::_( 'LABEL.METADATA_INFO' );
			echo $this->pane->startPanel( $title, "metadata-page" );
			echo $this->params->render('meta', 'metadata');
			echo $this->pane->endPanel();
			
			echo $this->pane->endPane();
		?>
			</td>
		</tr>
		</table>
	<div class="clr"></div>
	<input type="hidden" name="cid[]" value="<?php echo $this->rokdownload->id; ?>" />
	<input type="hidden" name="task" value="" />
	<input type="hidden" name="controller" value="rokdownload" />
	<input type="hidden" name="option" value="com_rokdownloads" />
	<input type="hidden" name="folder" value="<?php echo $this->rokdownload->folder; ?>" />
	<input type="hidden" name="downloads" value="<?php echo $this->rokdownload->downloads; ?>" />
	<input type="hidden" name="lft" value="<?php echo $this->rokdownload->lft; ?>" />
	<input type="hidden" name="rgt" value="<?php echo $this->rokdownload->rgt; ?>" />
	<input type="hidden" name="path" value="<?php echo $this->rokdownload->path; ?>" />
	<?php if ($this->rokdownload->id == 1): ?> 
	<input type="hidden" name="name" value="<?php echo $this->rokdownload->name ?>" />
	<?php endif; ?>
</form>