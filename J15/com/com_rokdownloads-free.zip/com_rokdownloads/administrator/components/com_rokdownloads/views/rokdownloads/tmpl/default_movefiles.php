<?php 
/**
 * @version $Id: default_movefiles.php 18489 2010-02-03 00:44:48Z btowles $
 * @package RocketTheme
 * @subpackage	RokDownloads
 * @copyright Copyright (C) 2008 RocketWerx. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 */
defined('_JEXEC') or die('Restricted access');
?>
<script type="text/javascript">

function moveFiles() {
	window.addEvent('load', function() {
        $('tofolder').focus();
    });
	
	window.top.moveSelectedFiles(document.adminForm.tofolder.options[document.adminForm.tofolder.selectedIndex].value, document.adminForm.tofolder.options[document.adminForm.tofolder.selectedIndex].text);
	window.top.SqueezeBox.close();
}
	var pnode = window.top.tree.selected;
</script>
<div id="msg" style="font-size:small;font-weight:bold;color:#CC0000;font-family: Helvetica, sans-serif;"><?php echo $this->msg ?></div>
<br></br>
<form method="post" action="index.php" enctype="multipart/form-data" name="adminForm" onsubmit="moveFiles();">
	<table>
		<tr>
			<td nowrap="nowrap">
				<label><strong><?php echo  JText::_( 'LABEL.DIALOG_MOVE' ); ?></strong></label>
			</td>
		</tr>
		<tr>
			<td>
				<fieldset>
					<?php echo  $this->lists['folders'];;?>
					<input class="button" type="button" value="<?php echo  JText::_( 'Move' ); ?>" name="movefilessubmit" onclick="moveFiles();" />
				</fieldset>
			</td>
		</tr>
	</table>
	<input type="hidden" name="option" value="com_rokdownloads" />
	<input type="hidden" name="controller" value="rokdownloads"/>
	<input type="hidden" name="tmpl" value="newfolder" />
	<input type="hidden" name="task" value="newfolder" />
</form>