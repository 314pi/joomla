<?php 
/**
 * @version $Id: default_uploadselect.php 18489 2010-02-03 00:44:48Z btowles $
 * @package RocketTheme
 * @subpackage	RokDownloads
 * @copyright Copyright (C) 2008 RocketWerx. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 */
defined('_JEXEC') or die('Restricted access');
?>
<div id="msg" style="font-size:small;font-weight:bold;color:#CC0000;font-family: Helvetica, sans-serif;"><?php echo $this->msg ?></div>
<script>
window.top.SqueezeBox.addEvent('onClose',function(){afterUpload();})

function afterUpload() {
	window.top.selectedFolder=<?php echo $this->parent->id;?>;
	window.top.forceTreeReload(window.top.tree.selected);
	window.top.SqueezeBox.close();
}

</script>
<br></br>
<center>
<table>
	<tr>
		<td nowrap="nowrap">
			<label><?php echo JText::sprintf('LABEL.UPLOADING_TO_FOLDER',$this->parent->path);?></label>
		</td>
	</tr>
	<tr>
		<td>
		<?php if($this->params->get('use_java_uploader')) : ?>
			<fieldset>
		        <applet
			            code="wjhk.jupload2.JUploadApplet.class"
			            name="JUpload"
			            archive="components/com_rokdownloads/libs/wjhk.jupload-V4.0.jar"
			            width="500"
			            height="300"
			            mayscript
			            alt="The java plugin must be installed.">
		            <param name="type"    value="application/x-java-applet;version=1.5"/>
		            <param name="postUrl"  value="index.php?option=com_rokdownloads&controller=file&tmpl=component&task=uploadJava&format=raw"/> 
		            <param name="showLogWindow" value="false"/>
		            <param name="lookAndFeel"  value="system"/> 
		            <param name="debugLevel" value="0"/>
		            <param name="stringUploadError" value="ERROR: (.*)"/>
		            <param name="stringUploadSuccess" value="SUCCESS"/>
		            <param name="serverProtocol" value="HTTP/1.1"/>
		            <param name="formdata"	value="adminForm"/>
		            <param name="nbFilesPerRequest" value="-1"/>
		            <param name="afterUploadURL" value="javascript:afterUpload();"/>
		            A Java 1.5 or higher plugin required. 
		        </applet>
			</fieldset>
			<form method="post" action="#" name="adminForm">
				<input type="hidden" name="option" value="com_rokdownloads" />
				<input type="hidden" name="controller" value="file"/>
				<input type="hidden" name="tmpl" value="component" />
				<input type="hidden" name="task" value="uploadJava" />
				<input type="hidden" name="format" value="raw" />
				<input type="hidden" name="pid" value="<?php echo $this->parent->id;?>" />
				<?php echo JHTML::_('form.token'); ?>
			</form>
		<?php else: ?>
			<form action="<?php echo JURI::base(); ?>index.php?option=com_rokdownloads&amp;controller=file&amp;task=upload&amp;tmpl=component&amp;<?php echo $this->session->getName().'='.$this->session->getId(); ?>&amp;pop_up=1&amp;pid=<?php echo $this->parent->id?>&amp;<?php echo JUtility::getToken();?>=1" id="uploadForm" method="post" enctype="multipart/form-data">
			<fieldset>
				<legend><?php echo JText::_('Upload'); ?></legend>
				<fieldset class="actions">
					<input type="file" id="file-upload" name="Filedata" />
					<input type="submit" id="file-upload-submit" value="<?php echo JText::_('LABEL.BUTTON_START_UPLOAD'); ?>"/>
					<span id="upload-clear"></span>
				</fieldset>
				<ul class="upload-queue" id="upload-queue">
					<li style="display: none" />
				</ul>
			</fieldset>
			</form>
			<form method="post" action="#" name="adminForm">
				<input type="hidden" name="option" value="com_rokdownloads" />
				<input type="hidden" name="controller" value="file"/>
				<input type="hidden" name="tmpl" value="component" />
				<input type="hidden" name="task" value="upload" />
				<input type="hidden" name="format" value="raw" />
				<input type="hidden" name="pid" value="<?php echo $this->parent->id;?>" />
				<?php echo JHTML::_('form.token'); ?>
			</form>
		<?php endif; ?>
		</td>
	</tr>
</table>
</center>
