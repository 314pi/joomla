<?php
/**
 * @version $Id: view.raw.php 18489 2010-02-03 00:44:48Z btowles $
 * @package RocketTheme
 * @subpackage	RokDownloads
 * @copyright Copyright (C) 2008 RocketWerx. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 */
 
// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport( 'joomla.application.component.view' );
require_once (JPATH_COMPONENT.DS.'libs'.DS.'json.php');
/**
 * @package		RocketTheme
 * @subpackage	RokDownloads
 *
 * @since 1.5
 */
class RokdownloadsViewRokdownload extends JView
{
	function display($tmpl=null){
		//$this->getfolders();
		$task = JRequest::getVar('task', 'getfolders');
	}
	
	function resetStats($tmpl=null){
		$results= new JSONResult();
		$post = JRequest::get( 'post' );
		$postObj = JXJson::decode($post['json']);
		$model	=& $this->getModel();
		$node = $model->getFile($postObj->id);
		$results->result = $model->resetStats($node);
		if (!$results->result) {
			$results->errormsg = JText::sprintf("ERROR.SERVER_ERROR") . "\n" . $model->getError();
		}
		echo JXJson::encode($results);
	}
	
}
?>