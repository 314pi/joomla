<?php
/**
 * @version $Id: view.html.php 18489 2010-02-03 00:44:48Z btowles $
 * @package RocketTheme
 * @subpackage	RokDownloads
 * @copyright Copyright (C) 2008 RocketWerx. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');

jimport( 'joomla.application.component.view');
jimport( 'joomla.html.html.list');
jimport( 'joomla.html.html.select');
require_once (JPATH_COMPONENT.DS.'libs'.DS.'fileutils.php');

/**
 * HTML View class for the Rokdownloads component 
 *
 * @package		RocketTheme
 * @subpackage	RokDownloads
 *
 * @since 1.5
 */
class RokdownloadsViewRokdownload extends JView
{
	function display($tpl = null)
	{
		global $mainframe;

		if($this->getLayout() == 'form') {
			$this->_displayForm($tpl);
			return;
		}

		//get the download item
		//$rokdownload =& $this->get('data');
		parent::display($tpl);
	}

	function _displayForm($tpl)
	{
		jimport('joomla.html.pane');
		global $mainframe, $option;
		$document = & JFactory::getDocument();
		$isFolder = false;

		JHTML::_('behavior.tooltip');

		$db		=& JFactory::getDBO();
		$uri 	=& JFactory::getURI();
		$user 	=& JFactory::getUser();
		$model	=& $this->getModel();

		$lists = array();

		//get the download
		$fid = JRequest::getVar('fid');
		$pid = JRequest::getVar('pid');


		if ($fid>0) {
			$file	=& $model->getFile($fid);
			$parent =& $file->getParent();
		}

		if (!$parent && $pid>0) {
			$parent	=& $model->getFile($pid);
			$isFolder=true;
		}
		$isNew		= ($file->id < 1);


		// fail if checked out not by 'me'
		if ($fid > 0 && $file->isCheckedOut( $user->get('id') )) {
			$msg = JText::sprintf( 'ERROR.CHECKED_OUT_BY_USER', $file->name );
			$mainframe->redirect( 'index.php?option='. $option, $msg );
		}



		// Set toolbar items for the page
		$text = $isNew ? JText::_( 'New' ) : JText::_( 'Edit' );
		$text .= " ";
		$text .= $file->folder ? JText::_('LABEL.FOLDER') : JText::_('LABEL.FILE');
		JToolBarHelper::title(   JText::_( 'APP.ROKDOWNLOADS' ).': <small><small>[ ' . $text.' ]</small></small>', 'rokdownload.png');
		JToolBarHelper::save('save');
		JToolBarHelper::apply('apply');
		JToolBarHelper::cancel( 'cancel', 'Close' );
		JToolBarHelper::help( 'screen.rokdownloads.edit' );
		JRequest::setVar('hidemainmenu', 1);

		$assetbase = 'components/com_rokdownloads/assets';
		$document->addScript($assetbase.'/utils/utils.js');
		$document->addStyleSheet($assetbase . '/rokdownload.css');

		// Edit or Create?
		if (!$isNew)
		{
			$file->checkout( $user->get('id') );
		}
		
		$folders =& $model->getFullDBFolders(($file->folder && $file->id > 0)?$file:null);

		if ($parent) {
			$lists['folders'] = JHTML::_('select.genericlist',   $folders, 'parentid', 'class="inputbox" size="1" ', 'id', 'path', intval($parent->id));
		}
		// build the html select list
		$lists['published'] =  JHTML::_('select.booleanlist', 'published', 'class="inputbox"', $file->published );
		
		// Imagelist
		$icon_dir = DS.THUMB_FOLDER;
		
		$lists['image'] 	= JHTML::_('list.images', 'thumbnail', $file->thumbnail, null, $icon_dir );
		//clean weblink data
		jimport('joomla.filter.output');
		JFilterOutput::objectHTMLSafe( $file, ENT_QUOTES, array('introtext','fulltext'));

		
		if (!$isFolder) {
			$paramfile 	= JPATH_COMPONENT.DS.'custom_params.xml';
			$customparams = new JParameter($file->params,$paramfile);
		}
		else
			$customparams = false;
			
		$paramfile 	= JPATH_COMPONENT.DS.'models'.DS.'rokdownload_params.xml';
		$params = new JParameter($file->params,$paramfile);
		$params->set("created",$file->created_time);
		$params->set("modified",$file->modified_time);
		$params->set('description', $file->metadesc);
		$params->set('keywords', $file->metakey);
		$params->loadINI($file->metadata);
		



		if (JString::strlen($file->fulltext) > 1) {
			$text = $file->introtext . "<hr id=\"system-readmore\" />" . $file->fulltext;
		} else {
			$text = $file->introtext;
		}
		$uri =& JFactory::getURI();
		
		$ajaxURL = $uri->current()."?option=".$option."&controller=rokdownload&format=raw&task=";
		$this->assignRef('ajaxURI', $ajaxURL);
		$this->assignRef('text', $text);
		$this->assignRef('lists',		$lists);
		$this->assignRef('rokdownload',	$file);
		$this->assignRef('params',		$params);
		$this->assignRef('customparams',		$customparams);
		$sliders = JPane::getInstance('sliders');
		$this->assignRef('pane', $sliders);
		$editor = JFactory::getEditor();
		$this->assignRef('editor', $editor);
		$uriString = $uri->toString();
		$this->assignRef('request_url',	$uriString);
		$nullDate = $model->getNullDate();
		$this->assignRef('nullDate', $nullDate);

		parent::display($tpl);
	}

}
?>
