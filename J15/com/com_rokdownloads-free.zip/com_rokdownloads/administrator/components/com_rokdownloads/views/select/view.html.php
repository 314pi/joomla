<?php
/**
* @version		$Id: view.html.php 11236 2008-11-02 02:44:35Z ian $
* @package		Joomla
* @subpackage	Media
* @copyright	Copyright (C) 2005 - 2008 Open Source Matters. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* Joomla! is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

jimport( 'joomla.application.component.view');

/**
 * HTML View class for the WebLinks component
 *
 * @static
 * @package		Joomla
 * @subpackage	Media
 * @since 1.0
 */
class RokdownloadsViewSelect extends JView
{
	function display($tpl = null)
	{
		global $mainframe;

		$config =& JComponentHelper::getParams('com_rokdownloads');
		$model	=& $this->getModel();
		
		$db 	=& JFactory::getDBO();
		$row 	=& JTable::getInstance('module');
		$query = 'SELECT menuid AS value'
			. ' FROM #__modules_menu'
			. ' WHERE moduleid = '.(int) $row->id
			;
			$db->setQuery( $query );
			$lookup = $db->loadObjectList();
			
		$lists = array();
		$app = JFactory::getApplication();
		$append = '';
		if($app->getClientId() == 1) $append = 'administrator/';
		JHTML::_('stylesheet', 'select_popup.css', $append .'components/com_rokdownloads/assets/');
		JHTML::addIncludePath(JPATH_COMPONENT_ADMINISTRATOR.DS.'libs'.DS.'html');
	
		$selections				= JHTML::_('rokdownloadmenu.linkoptions');
		$lists['menuitems']	= JHTML::_('select.genericlist',   $selections, 'menuitems', 'class="inputbox" size="15" onChange="PopulateDownloads();"', 'value', 'text', null, 'menuitems' );
		$lists['downloads']	= JHTML::_('select.genericlist',   array(), 'downloads', 'class="inputbox" size="15" WIDTH="300" STYLE="width: 300px"', 'value', 'text', null, 'downloads' );
		$lists['direct_download'] = JHTML::_('select.booleanlist', 'directdownload');
		
		$editor = JFactory::getEditor();
		
		$menu_downloads = $model->getDownloadsForMenuItems();
		
		$this->assignRef('lists',	$lists);
		$this->assignRef('menu_downloads',	$menu_downloads);
		$this->assignRef( 'session',	JFactory::getSession());
		$this->assignRef( 'config',		$config);
		$this->assignRef( 'state',		$this->get('state'));
		$this->assignRef('editor', $editor->_name);
		parent::display($tpl);
	}
}
