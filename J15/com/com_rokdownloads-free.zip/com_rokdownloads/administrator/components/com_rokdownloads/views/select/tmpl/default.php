<script language="Javascript">
<!--

function PopulateDownloads() {
	var MenuItemList = document.selectdownloadlink.menuitems;
	// Clear out the list of teams
	ClearOptions(document.selectdownloadlink.downloads);
	<?php 
	reset($this->menu_downloads);
	while (list($key, $value) = each($this->menu_downloads)) :
		$menudownloads =& $this->menu_downloads[$key];
	?>
	if (MenuItemList[MenuItemList.selectedIndex].value == "<?php echo $key; ?>") {
		<?php for ($i = 0; $i < count($menudownloads); $i++) : ?>
			AddToOptionList(document.selectdownloadlink.downloads, "<?php echo $menudownloads[$i]['id'];?>", "<?php echo $menudownloads[$i]['name'];?>");
		<?php endfor;?>
	}
	<?php endwhile; ?>
}

function ClearOptions(OptionList) {
	// Always clear an option list from the last entry to the first
	for (x = OptionList.length; x >= 0; x = x - 1) {
		OptionList[x] = null;
	}
}
function AddToOptionList(OptionList, OptionValue, OptionText) {
	// Add option to the bottom of the list
	var text = OptionText.replace(" ", "&nbsp;", "g");
	new Element('option', {value: OptionValue}).setHTML(text).inject($(OptionList));
}
var getSelText = function(el) {
    if (document.selection) return document.selection.createRange().text;
	else if (typeof el.selectionStart != 'undefined')  return el.value.substring(el.selectionStart, el.selectionEnd);
	else return '';
}
var insertAtCursor = function(el, value) {
	if (document.selection) {
		el.focus();
		var sel = document.selection.createRange();
		sel.text = value;
	}
	else if (el.selectionStart || el.selectionStart == "0") {
		var startPos = el.selectionStart;
		var endPos = el.selectionEnd;
		el.value = el.value.substring(0, startPos) + value + el.value.substring(endPos, el.value.length);
	} else {
		el.value += value;
	}
	return el;
}

function get_direct_download_value()
{
for (var i=0; i < document.selectdownloadlink.directdownload.length; i++)
   {
   if (document.selectdownloadlink.directdownload[i].checked)
      {
      var rad_val = document.selectdownloadlink.directdownload[i].value;
      }
   }
   return rad_val;
}


function onOk() {
	var parent = $(window.parent.document.body);
	var sbox = parent.getElement('#sbox-window');
	var text = parent.getElement('#text');
	
	var mitems = $(document).getElement('#menuitems');
	var ditems = $(document).getElement('#downloads');
	
	if (mitems.selectedIndex >= 0) 
		var menuId = mitems.options[mitems.selectedIndex].value;
	else
		return;
	if (ditems.selectedIndex >= 0) 
		var downloadId = ditems.options[ditems.selectedIndex].value;
	else
		return;
	
	var downloadText = ditems.options[ditems.selectedIndex].text
	var direct_download = (get_direct_download_value()==1)?'true':'false';
	
	var value = "[rokdownload menuitem=\"" + menuId +"\" downloaditem=\""+downloadId +"\" direct_download=\""+direct_download+"\"]{url}[/rokdownload]";
	var editor_type = '<?php echo $this->editor;?>';
	var html='';
	if (editor_type == 'rokpad') {
		 html = window.parent.rokeditors['<?php echo preg_replace( '#[^A-Z0-9\-\_\[\]]#i', '', JRequest::getVar('e_name') ); ?>'].codemirror.selection();
	}
	else if (editor_type == 'tinymce' || editor_type == 'jce') {
		 html = window.parent.tinyMCE.selectedInstance.selection.getContent({format : '<?php echo preg_replace( '#[^A-Z0-9\-\_\[\]]#i', '', JRequest::getVar('e_name') ); ?>'});
	}
	else if (editor_type == 'none'){ 
		html = getSelText(text);
	}
	if (!html.length) html = "linked text";
	window.parent.jInsertEditorText(value.replace('{url}', html), '<?php echo preg_replace( '#[^A-Z0-9\-\_\[\]]#i', '', JRequest::getVar('e_name') ); ?>');
	sbox.close();
}
//-->
</script>
<?php if (empty($this->menu_downloads)): ?>
	<?php echo JText::_( 'WARN.NO_MENU_ITEMS_DEFINED' ); ?>
<?php else: ?>
<form name="selectdownloadlink" action="link" method="get">
	<fieldset>
		<div style="float: right">
			<button type="button" onclick="onOk();"><?php echo JText::_('BUTTON.INSERT') ?></button>
			<button type="button" onclick="window.parent.document.getElementById('sbox-window').close();"><?php echo JText::_('Cancel') ?></button>
		</div>
	</fieldset>
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'LABEL.SELECT_ROKDOWNLOAD_LINK_ITEM' ); ?></legend>
		<table class="admintable" cellspacing="1">
			<tr>
				<td valign="top" class="key">
					<?php echo JText::_( 'LABEL.MENU_ITEM_SELECTION' ); ?>:
				</td>
				<td>
					<?php echo $this->lists['menuitems']; ?>
				</td>
				<td valign="top" class="key">
					<?php echo JText::_( 'LABEL.DOWNLOAD_SELECTION' ); ?>:
				</td>
				<td>
					<?php echo $this->lists['downloads']; ?>				
				</td>
			</tr>
		</table>
			<?php echo JText::_( 'LABEL.DIRECT_DOWNLOAD'); ?>:<?php echo $this->lists['direct_download']; ?>
	</fieldset>
</form>
<?php endif; ?>