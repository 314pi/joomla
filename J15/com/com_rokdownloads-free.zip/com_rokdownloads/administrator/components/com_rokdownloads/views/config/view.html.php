<?php
/**
 * @version $Id: view.html.php 18489 2010-02-03 00:44:48Z btowles $
 * @package RocketTheme
 * @subpackage	RokDownloads
 * @copyright Copyright (C) 2008 RocketWerx. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');

jimport( 'joomla.application.component.view');
jimport('joomla.application.component.helper');

/**
 * HTML View class for the Rokdownloads Config
 *
 * @package		RocketTheme
 * @subpackage	RokDownloads
 *
 * @since 1.5
 */
class RokdownloadsViewConfig extends JView
{
	/**
	 * Display the view
	 */
	function display($tpl = null)
	{
		global $mainframe;
		$document = & JFactory::getDocument();
		// Set toolbar items for the page
		JToolBarHelper::title(   JText::_( 'LABEL.CONFIGURATION' ), 'rokconfig.png' );
		JToolBarHelper::save();
		JToolBarHelper::cancel('cancel','Reset');
		JToolBarHelper::help( 'screen.rokdownloads' );
		

		$assetbase = 'components/com_rokdownloads/assets';
		$document->addStyleSheet($assetbase . '/rokdownload.css');
		$uri	=& JFactory::getURI();
		// Get the page/component configuration
		$model = $this->getModel();
		$params = &$model->getParams();

		$component = JRequest::getVar('component');

		$document = & JFactory::getDocument();
		$document->setTitle( JText::_('TITLE.EDIT_ROKDOWNLOADS_CONFIG') );

		$this->assignRef('params', $params);
		$this->assignRef('component', $component);
		$uristring = $uri->toString();
		$this->assignRef('request_url',	$uristring);
		parent::display($tpl);
	}

}
?>
