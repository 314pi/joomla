<?php 
/**
 * @version $Id: default.php 18489 2010-02-03 00:44:48Z btowles $
 * @package RocketTheme
 * @subpackage	RokDownloads
 * @copyright Copyright (C) 2008 RocketWerx. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 */
defined('_JEXEC') or die('Restricted access');

?>
<form action="index.php" method="post" name="adminForm" autocomplete="off">
	<fieldset>
		<legend>
			<?php echo JText::_('LABEL.CONFIGURATION');?>
		</legend>
		<?php echo $this->params->render();?>
	</fieldset>

	<input type="hidden" name="component" value="<?php echo $this->component;?>" />

	<input type="hidden" name="controller" value="config" />
	<input type="hidden" name="option" value="com_rokdownloads" />
	<input type="hidden" name="task" value="" />
</form>

	<legend><?php echo JText::_( 'LABEL.RELEVANT_PHP_SETTINGS' ); ?></legend>
		<table class="adminlist">
		<thead>
			<tr>
				<th width="250">
					<?php echo JText::_( 'LABEL.SETTING' ); ?>
				</th>
				<th>
					<?php echo JText::_( 'LABEL.VALUE' ); ?>
				</th>
			</tr>
		</thead>
		<tfoot>
		<tr>
			<th colspan="2">&nbsp;
			</th>
		</tr>
		</tfoot>
		<tbody>
		<tr>
			<td>
				<?php echo JText::_( 'LABEL.SAFE_MODE' ); ?> :
			</td>
			<td>
				<?php if (!ini_get('safe_mode')) : ?><font color="green"><strong><?php echo JText::_('LABEL.OFF');?></strong></font><?php else: ?><font color="RED"><strong><?php echo JText::_('LABEL.ON');?></strong></font> - <?php echo JText::_('DESCRIPTION.SAFE_MODE_ON');?> <?php endif; ?>
			</td>
		</tr>
		<tr>
			<td>
				<?php echo JText::_( 'LABEL.FILE_UPLOADS' ); ?> :
			</td>
			<td>
				<?php if (	ini_get('file_uploads')): ?><font color="green"><strong><?php echo JText::_('LABEL.ON');?></strong></font><?php else: ?><font color="RED"><strong><?php echo JText::_('LABEL.OFF');?></strong></font> - <?php echo JText::_('DESCRIPTION.FILE_UPLOADS_OFF');?> <?php endif; ?>
			</td>
		</tr>
		<tr>
			<td>
				<?php echo JText::_( 'LABEL.POST_MAX_SIZE' ); ?> :
			</td>
			<td>
				<strong><?php echo ini_get('post_max_size'); ?></strong>
			</td>
		</tr>
		<tr>
			<td>
				<?php echo JText::_( 'LABEL.UPLOAD_MAX_FILESIZE' ); ?> :
			</td>
			<td>
				<strong><?php echo ini_get('upload_max_filesize'); ?></strong>
			</td>
		</tr>
		</table>