<?php

/**
 * @version $Id: default.php 18489 2010-02-03 00:44:48Z btowles $
 * @package RocketTheme
 * @subpackage	RokDownloads
 * @copyright Copyright (C) 2008 RocketWerx. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 */
defined('_JEXEC') or die('Restricted access');
?>

<script type="text/javascript">

// Tree View Control
var tree;
var selectedFolder=<?php echo $this->selectedFolder; ?>;
var editurl='index.php?option=com_rokdownloads&controller=rokdownload&task=display&view=rokdownload&layout=form&fid=';
var initialTree='<?php echo $this->initialTree; ?>';
var PUBLISHED_COLOR = '#333';
var PUBLISHED_ICON = '_closed';
var MISSING_COLOR = '#999';
var MISSING_ICON = '_doc';
var UNPUBLISHED_COLOR = '#FF8C00';
var UNPUBLISHED_ICON = '_open';
var ROOT_FOLDER_ID = 1;

var k = Cookie.get('rokdownload_select');
if (!k) Cookie.set('rokdownload_select', 1);

function createTree(el){
    tree = new MooTreeControl({
        div: el,
        mode: 'files',
        grid: true,
        onReplace: function(from,to,where){
        	if (where == 'inside'){
        		from.expandParents();
        	}
        	selectedFolder = to.id;
			Cookie.set('rokdownload_select', to.id.toInt());
			moveAjax([from.id], to.id, where,  successRefreshTable, comError);
        },
        onSelect: function(node, newselection) {
        	if (newselection) {
				Cookie.set('rokdownload_select', node.id);
       			node.expandParents();
       			node.toggle(false, true);
				forceTableLoad(node);
	    		$('currentfoldertext').setText(node.data.path);
        	}
        },
	onExpand: function(obj, open) {
		if (typeof window.$rokdownloadI == 'undefined') window.$rokdownloadI = 0;
		else window.$rokdownloadI++;

		if (obj.nodes.length && window.$rokdownloadI > 2) {
			var height = this.div.getCoordinates().height;
			var tbC = $$('.mootable_container')[0];
			tbC.$height = tbC.$height || tbC.getStyle('height').toInt();
			if (tbC) {
				if (height > tbC.$height) {
					tbC.setStyle('height', height);
					table._manageHeight();
				}
				else {
					tbC.setStyle('height', tbC.$height);
					table._manageHeight();
				}
			}
		}
	},
        theme: '<?php echo $this->treebase;?>/mootree.gif',
        nodeOptions: {
            text: 'Downloads',
            open: true,
            id: ROOT_FOLDER_ID,
            data: {
            		displayname: 'Downloads',
            		path: '\<?php echo DS;?>'
            },
            icon: UNPUBLISHED_ICON
        },
		contextMenuOptions: {
			initialize:function(){
				this.fx = new Fx.Style(this.contextMenu, 'opacity', {duration: 500, wait: false}).set(0);
			},
			onShow: function(contextMenu) {
				this.fx.start(1);
			},
			onHide: function(contextMenu) {
				this.fx.start(0);
			},
			buildMenuItems: function(div, node, event){
				var span;
				span = new Element('span').setHTML( node.data.name+" - "+ node.id);
				div.appendChild(span);
				div.appendChild(new Element('br'));
				div.appendChild(new Element('hr'));
				if (!node.data.published && !node.data.missing) {
					span = new Element('span').setHTML("<img src='<?php echo $this->imagebase;?>/publish_g.png'> <?php echo JText::_('Publish');?>");
					span.addEvent('click', function(event){
						publishFolder(node);
					});
					div.appendChild(span);
				} else {
					span = new Element('span').setHTML("<img src='<?php echo $this->imagebase;?>/publish_r.png'> <?php echo JText::_('Unpublish');?>");
					span.addEvent('click', function(event){
						unpublishFolder(node);
					});
					div.appendChild(span);
				}
				// Allow Manipulation of Registered Folders
				div.appendChild(new Element('br'));
				div.appendChild(new Element('hr'));
				if (node.id != tree.root.id) {
					span = new Element('span').setHTML("<img src='<?php echo $this->imagebase;?>/publish_x.png'> <?php echo JText::_('Delete');?>");
					span.addEvent('click', function(event){
						deleteFolder(node);
					});
					div.appendChild(span);
					div.appendChild(new Element('br'));
				}
				if (!node.data.missing) { 
					span = new Element('span').setHTML("<img src='<?php echo $this->imagebase;?>/addnew.png'> <?php echo JText::_('LABEL.ADD_NEW');?>");
					span.addEvent('click', function(event){
						NewFolderPopup(node, 300, 200);
					});
					div.appendChild(span);
					div.appendChild(new Element('br'));
				}
				// Always Show the Properties Option
				div.appendChild(new Element('hr'));
				span = new Element('span').setHTML("<img src='<?php echo $this->imagebase;?>/edit.png'> <?php echo JText::_('LABEL.PROPERTIES');?>");
				span.addEvent('click', function(event){
					window.location=editurl+node.id;
				});
				div.appendChild(span);
				return div;
			}
		}
    });
    tree.disable(); // this stops visual updates while we're building the tree...
    root=tree.root;
    tree.expand();

    tree.enable(); // this turns visual updates on again.
}

// Table View Control
var table;
function createTable(el){
	var headers = [
				   {"text":"<INPUT TYPE=CHECKBOX onclick='checkAll();' name='toggle'>"	,"key":"id","sortable":false,"fixedWidth":true, "align": "center","fixedWidth":true,"defaultWidth":"30px"},
				   {"text":"","key":"id","sortable":false,"fixedWidth":true, "align": "center","fixedWidth":true,"defaultWidth":"30px"},
				   {"text":"<?php echo JText::_('LABEL.ID');?>","key":"id","sortable":false,"fixedWidth":false, "align": "center","fixedWidth":true,"defaultWidth":"50px"},
				   {"text":"<?php echo JText::_('LABEL.DISPLAY_NAME');?>","key":"displayname","fixedWidth":false,"defaultWidth":"170px"},
				   {"text":"<?php echo JText::_('LABEL.FILE_NAME');?>","key":"name","fixedWidth":false,"defaultWidth":"170px"},
				   {"text":"<?php echo JText::_('LABEL.SIZE');?>","key":"filesize","fixedWidth":true,"defaultWidth":"50px"},
				   {"text":"<?php echo JText::_('Downloads');?>","key":"downloads","align": "center","fixedWidth":true,"defaultWidth":"80px"},
				   {"text":"<?php echo JText::_('Published');?>","key":"published","align": "center","fixedWidth":true,"defaultWidth":"80px"},
				   {"text":"<?php echo JText::_('Order');?>","align": "center","fixedWidth":true,"defaultWidth":"80px"}];
	
	function publishClick(ev){
		if (this.data.published == 1)
			unpublishFile(this.data.id);
		else
			publishFile(this.data.id);
	}
	
	table = new MooTable( el, {height: '300px', headers: headers, sortable: false, useloading: false, resizable: true});
	
	table.addEvent( 'afterRow', function(data, row){
		row.cols[0].element.innerHTML = ('<INPUT TYPE=CHECKBOX NAME="cb' + data.id +'">');
		row.cols[0].element.setStyle('text-align', 'center');

		if (data.thumbnail.length <=0) {
			data.thumbnail = "rokdownload.png";
		}
		
		var filecolor = UNPUBLISHED_COLOR;
		var titletip = '';
		var overlay_class = "unpublished";
		if (data.published == 1) {
			filecolor = PUBLISHED_COLOR;
			overlay_class = "published";
		}
		if (data._missing) {
			overlay_class = "missing";
			filecolor = MISSING_COLOR;
			titletip = 'title="<?php echo JText::_('WARN.MISSING_FROM_FILESYSTEM')?>"';
		}
		
		row.cols[1].element.innerHTML = '<div class="dragable"><img src="<?php echo "../".THUMB_FOLDER?>/' + data.thumbnail +'" alt="" class="thumbnail"/><div class="'+ overlay_class +' overlay"></div></div>';
		//row.cols[1].element.innerHTML = '<div class="dragable"><div class="img" style="backround:url(<?php echo "../".THUMB_FOLDER?>/'+ data.thumbnail +'" width="16" height="16" border="2" alt="" /><div class="'+ overlay_class +'"></div></div></div>';
		row.cols[1].element.setStyle('text-align', 'center');
		
		row.cols[2].element.setStyle('cursor', 'pointer');
		row.cols[2].element.innerHTML = '<a href="' + editurl + data.id + '"' + titletip +'><font color="' + filecolor + '">' + data.id + '</font></a>';
		row.cols[2].element.setStyle('text-align', 'center');
		
		row.cols[3].element.setStyle('cursor', 'pointer');
		row.cols[3].element.innerHTML = '<a href="' + editurl + data.id + '"' + titletip +'><font color="' + filecolor + '">' + data.displayname + '</font></a>';
		

		row.cols[4].element.setStyle('cursor', 'pointer');
		row.cols[4].element.innerHTML = '<a href="' + editurl + data.id +'"' + titletip +'><font color="' + filecolor + '">' + data.name + '</font></a>';


		row.cols[5].element.innerHTML = filesize_format(data.filesize,'%01.1f %s');
		row.cols[5].element.setStyle('text-align', 'right');

		row.cols[6].element.innerHTML = data.downloads;
		row.cols[6].element.setStyle('text-align', 'center');

		//publishd button col
		if (data.published == 1)
		{
			// Set unpublish ajax url option here
			pubimage = "tick.png";
		}
		else {
			// Set publish ajax url option here
			pubimage = "publish_x.png";
		}
		row.cols[7].element.innerHTML = '<img src="<?php echo $this->imagebase;?>' + pubimage +'">';
		row.cols[7].element.setStyle('text-align', 'center');
		row.cols[7].element.setStyle('cursor', 'pointer');
		row.cols[7].element.addEvent( 'click', publishClick.bind(row) );

		row.cols[8].element.setStyle('text-align', 'center');
		row.cols[8].element.setStyle('cursor', 'pointer');
		
		if (data.pervious != 0) 
		{
		    row.cols[8].element.innerHTML += "<span><a href=\"#reorder\" onclick=\'moveAjax(["+data.id+"],"+data.pervious+",\"before\", successRefreshTable, comError);\' title=\"Move Up\"><img src=\"<?php echo $this->imagebase;?>uparrow.png\" width=\"16\" height=\"16\" border=\"0\" alt=\"Move Up\" /></a></span>";
		}
		
		if (data.next != 0) 
		{
			row.cols[8].element.innerHTML += "<span><a href=\"#reorder\" onclick=\'moveAjax([" + data.id + "]," + data.next + ",\"after\", successRefreshTable, comError);\' title=\"Move Up\"><img src=\"<?php echo $this->imagebase;?>downarrow.png\" width=\"16\" height=\"16\" border=\"0\" alt=\"Move Up\" /></a></span>"
		}
		
	});

};
var UploadPopup = function(){
	var uploadurl = "index.php?option=<?php echo $this->option;?>&tmpl=component&task=uploadselect&pid=" + tree.selected.id;
	if (tree.selected) {
		SqueezeBox.fromElement(uploadurl, {handler: 'iframe'});
	}
	else
	{
		alert('<?php echo JText::_("WARN.SELECT_UPLOAD_FOLDER");?>');
	}
}

var NewFolderPopup = function(selected, $width, $height, $top, $left){
	var newfolderurl = "index.php?option=<?php echo $this->option;?>&tmpl=component&task=newfolder&pid=" + tree.selected.id;
	if (selected) {
		SqueezeBox.fromElement(newfolderurl, {handler: 'iframe', size: {x: $width, y: $height}});
	}
	else
	{
		alert('<?php echo JText::_("WARN.SELECT_PARENT_FOLDER");?>');
	}
}

var MoveFilesPopup = function($width, $height, $top, $left){
	var ids = getSelectedFileIds();
	if (ids.length <= 0) {
		alert("<?php echo JText::_("WARN.SELECT_FILE_TO_MOVE");?>");
		return false;
	}	
	var movefilesurl = "index.php?option=<?php echo $this->option;?>&tmpl=component&task=movefiles&pid=" + tree.selected.id;
	SqueezeBox.fromElement(movefilesurl, {handler: 'iframe', size: {x: $width, y: $height}});

}

function dragAndDropInit() {
	$$('#draggable div').each(function(drag){
		new Drag.Move(drag, {
			droppables: $$('#droppable div')
		});
	 
		drag.addEvent('emptydrop', function(){
			this.setStyle('background-color', '#faec8f');
		});
	});
	 
	$$('#droppables div').each(function(drop, index){

		drop.addEvents({
			'over': function(el, obj){
				this.setStyle('background-color', '#78ba91');
			},
			'leave': function(el, obj){
				this.setStyle('background-color', '#1d1d20');
			},
			'drop': function(el, obj){
				el.remove();
				fx[index].start({
					'height': this.getStyle('height').toInt() + 30,
					'background-color' : ['#78ba91', '#1d1d20']
				});
			}
		});
	});
 
}

function forceTableLoad(folder) {
	tree.disable();
	var send={fid: folder.id};
	var url = "<?php echo $this->ajaxURI;?>getFilesForFolder";
	var myXHR = new XHR(url, {headers: {'X-Request': 'JSON'}});
	myXHR.addEvent('onFailure', function(result){
						table._emptyData();
						alert("<?php echo JText::_('ERROR.COMM_ERROR_GETTING_FILES');?>")
						tree.enable();
					});
	myXHR.addEvent('onSuccess', function(result){
						// check to make sure its a valid return  not a logged off
						if (result == '') {
							redirectToLogin();
						}
						jsondata = Json.evaluate(result);
						// Check to see if the call succeded
						table._emptyData();
						document.adminForm.toggle.checked=false;
						if (!jsondata.result) {
							alert(jsondata.errormsg);
						}
						for(var i=0,l=jsondata.data.length;i<l; i++){
					    	if (i > 0) {
					    		jsondata.data[i].pervious = jsondata.data[i-1].id;
					    	}
					    	else {
					    		jsondata.data[i].pervious = 0;
					    	}
					    	if (i == l-1) {
					    		jsondata.data[i].next = 0;
					    	}
					    	else {
					    		jsondata.data[i].next = jsondata.data[i+1].id;
					    	}
					    }
						table.loadData(jsondata.data, false);
						tree.enable();
					});
	myXHR.send(url, 'json=' + Json.toString(send));
}

function deleteFolder(folder) {
	tree.disable();
	if (folder.id == tree.root.id) {
		alert("<?php echo JText::_("WARN.CANNOT_DELETE_ROOT_FOLDER");?>");
		tree.enable();
		return;
	}
	if (!confirm("<?php echo JText::_("WARN.VERIFY_DELETE_FOLDER");?> " + folder.data.path + "?\n<?php echo JText::_("WARN.DELETES_ALL_FILES");?>")){
		tree.enable();
		return;
	}
	var parent=folder.parent;
	deleteAjax([folder.id], successRefreshTree.bind(parent), comError);
}

function getSelectedFileIds() {
	var ids=[];
	var f = document.adminForm;
	for (i=0, n=table.rows.length; i < n; i++) {
	 	cb = eval( 'f.cb' + table.rows[i].data.id );
	 	if (cb) {
			if (cb.checked){
				ids.push(table.rows[i].data.id);
			}
	 	}
	}	
	return ids;	
}

function deleteSelectedFiles() {
	tree.disable();
	var ids = getSelectedFileIds();
	
	if (ids.length <= 0) {
		alert("<?php echo JText::_("WARN.SELECT_FILES_TO_DELETE");?>");
		return false;
	}	
	var confirmtext = "<?php echo JText::_("WARN.VERIFY_DELETE_FILES");?>";
	if (!confirm(confirmtext)){
		tree.enable();
		return false;
	}
	deleteAjax(ids, successRefreshTable, comError);
}

function moveSelectedFiles(to, todesc) {
	tree.disable();
	var ids = getSelectedFileIds();
	
	var confirmtext = "<?php echo JText::_("WARN.VERIFY_MOVE_FILES");?> " + todesc;
	if (!confirm(confirmtext)){
		tree.enable();
		return false;
	}
	selectedFolder = to;
	moveAjax(ids, to, "inside", successRefreshTable, comError);
}

function deleteAjax(ids, success, failure) {
	parameteredAjaxCall({ids: ids}, "<?php echo $this->ajaxURI;?>delete", success, failure);
}

function addnewfolder(name, parentid, success, failure) {
	parameteredAjaxCall({name: name, parent: parentid}, "<?php echo $this->ajaxURI;?>addnewfolder", success, failure);
}

function moveAjax(ids, to, where, success, failure) {
	parameteredAjaxCall({ids: ids, to: to, where: where}, "<?php echo $this->ajaxURI;?>move", success, failure)
}
        
var comError = function(result){
	alert("<?php echo JText::_('ERROR.COMM_ERROR');?>");
	tree.enable();
}
var successRefreshTable = function(result){
	// check to make sure its a valid return  not a logged off
	if (result == '') {
		redirectToLogin();
	}
	jsondata = Json.evaluate(result);
	if (!jsondata.result) {
			alert(jsondata.errormsg);
	}
	forceTableLoad(tree.selected);
	tree.enable();
}

var successRefreshTree = function(result){
	// check to make sure its a valid return  not a logged off
	if (result == '') {
		redirectToLogin();
	}
	jsondata = Json.evaluate(result);
	if (!jsondata.result) {
			alert(jsondata.errormsg);
	}
	selectedFolder = this.id;
	if (this.id == tree.root.id) {
		forceTreeReload(this);
	}
	else {
		forceTreeReload(this.parent);
	}
	//forceTableLoad(this);
}

function publishAjax(ids, success, failure){
	parameteredAjaxCall({ids: ids}, "<?php echo $this->ajaxURI;?>publish", success, failure);
}

function publishSelectedFiles() {
	tree.disable();
	var ids = getSelectedFileIds();
	if (ids.length <= 0) {
		alert("<?php echo JText::_("WARN.SELECT_FILES_TO_PUBLISH");?>");
		return;
	}
	var confirmtext = "<?php echo JText::_("WARN.VERIFY_PUBLISH_FILES");?>\n";
	if (!confirm(confirmtext)){
		tree.enable();
		return;
	}
	publishAjax(ids, successRefreshTable, comError);
}
function publishFile(id) {
	var ids = [];
	ids.push(id);
	publishAjax(ids, successRefreshTable, comError);
}
function unpublishFile(id) {
	var ids = [];
	ids.push(id);
	unpublishAjax(ids, successRefreshTable, comError);
}
function unpublishAjax(ids, success, failure) {
	parameteredAjaxCall({ids: ids}, "<?php echo $this->ajaxURI;?>unpublish", success, failure);
}

function parameteredAjaxCall(send, url, success, failure) {
	var myXHR = new XHR(url, {headers: {'X-Request': 'JSON'}});
    myXHR.addEvent('onFailure', failure);
	myXHR.addEvent('onSuccess', success);
	myXHR.send(url, 'json=' + Json.toString(send));			
}

function unpublishSelectedFiles() {
	tree.disable();
	var ids = getSelectedFileIds();
	if (ids.length <= 0) {
		alert("<?php echo JText::_("WARN.SELECT_FILES_TO_UNPUBLISH");?>");
		return;
	}
	var confirmtext = "<?php echo JText::_("WARN.VERIFY_UNPUBLISH_FILES");?>\n";
	if (!confirm(confirmtext)){
		tree.enable();
		return;
	}
	unpublishAjax(ids, successRefreshTable, comError);
}

function publishFolder(folder) {
	tree.disable();
	var ids = [];
	ids.push(folder.id);
	if (!confirm("<?php echo JText::_("WARN.VERIFY_PUBLISH_FOLDER");?> " + folder.data.path + "?\n<?php echo JText::_("WARN.PUBLISH_ALL_SUB_NODES");?>")){
		tree.enable();
		return;
	}
	publishAjax(ids, successRefreshTree.bind(folder), comError);
}

function unpublishFolder(folder) {
	tree.disable();
	var ids = [];
	ids.push(folder.id);
	if (!confirm("<?php echo JText::_("WARN.VERIFY_UNPUBLISH_FOLDER");?> " + folder.data.path + "?\n<?php echo JText::_("WARN.UNPUBLISH_ALL_SUB_NODES");?>")){
		tree.enable();
		return;
	}
	unpublishAjax(ids, successRefreshTree.bind(folder), comError);
}

function editFirstSelected(){
	tree.disable();
	var ids = getSelectedFileIds();
	if (ids.length == 0) {
		alert("<?php echo JText::_('WARN.SELECT_FILE_TO_EDIT');?>");
		tree.enable();
		return;
	}
	window.location=editurl+ids[0];
	return;
}


function addFolderNode(foldernode, parentNode) {
	var nodecolor = UNPUBLISHED_COLOR;
	var nodeicon = UNPUBLISHED_ICON;
	if (foldernode.published == 1) {
		nodecolor = PUBLISHED_COLOR;
		nodeicon = PUBLISHED_ICON;
	}
	if (foldernode._missing) {
		nodecolor = MISSING_COLOR;
		nodeicon = MISSING_ICON;
	}
	
	var nodeinfo = {
		text: foldernode.displayname,
		icon: nodeicon,
		id: foldernode.id,
		color: nodecolor,
		data: {
			published: (foldernode.published ==  1)?true:false,
			missing: foldernode._missing,
			readable: foldernode._readable,
			path: foldernode.path,
			displayname: foldernode.displayname,
			name: foldernode.name
		}
	};
	var subnode = parentNode.insert(nodeinfo);
	subnode.divs.main.addClass("dropable");
	if (foldernode._missing) {
		subnode.divs.main.title="<?php echo JText::_('WARN.MISSING_FROM_FILESYSTEM')?>";
	}
	for(var i=0,l=foldernode._children.length;i<l; i++){
    	addFolderNode(foldernode._children[i], subnode);
    }
    if (subnode.id == selectedFolder) {
		var sel = Cookie.get('rokdownload_select').toInt() || selectedFolder || 0;
    	/*tree.select(subnode);*/
    }
}

function addRootNode(foldernode) {
	var nodecolor = UNPUBLISHED_COLOR;
	var nodeicon = UNPUBLISHED_ICON;
	if (foldernode.published == 1) {
		nodecolor = PUBLISHED_COLOR;
		nodeicon = PUBLISHED_ICON;
	}
	if (foldernode._missing) {
		nodecolor = MISSING_COLOR;
		nodeicon = MISSING_ICON;
	}
	
	var nodeinfo = {
		text: foldernode.displayname,
		icon: nodeicon,
		id: foldernode.id,
		color: nodecolor,
		data: {
			published: (foldernode.published ==  1)?true:false,
			missing: foldernode._missing,
			readable: foldernode._readable,
			path: foldernode.path,
			displayname: foldernode.displayname,
			name: foldernode.name
		}
	};
	tree.addRootNode(nodeinfo);
    subnode = tree.root;

	subnode.divs.main.addClass("dropable");
	for(var i=0,l=foldernode._children.length;i<l; i++){
    	addFolderNode(foldernode._children[i], subnode);
    }
    if (subnode.id == selectedFolder) {
		var sel = Cookie.get('rokdownload_select').toInt() || selectedFolder || 0;
		tree.select(tree.get(sel));
    	/*tree.select(subnode);*/
    }
}
function forceTreeReload(parent) {
	tree.disable();
	if (parent.id == tree.root.id) {
		parent=tree.root;
	}
	var send ={
		parent: parent.id
	};
	var url = "<?php echo $this->ajaxURI;?>getsubfolders";
    var myXHR = new XHR(url, {headers: {'X-Request': 'JSON'}});
    myXHR.addEvent('onFailure', function(result){
		alert("<?php echo JText::_('ERROR.COMM_ERROR_GETTING_FOLDERS');?>");
		tree.enable();
	});
	myXHR.addEvent('onSuccess', function(result){
		// check to make sure its a valid return  not a logged off
		if (result == '') {
			redirectToLogin();
		}
		jsondata = Json.evaluate(result);
		if (!jsondata.result) {
			alert(jsondata.errormsg);
			tree.enable();
		}
		else{
			parent.clear();
			for(var i=0,l=jsondata.data.length;i<l;i++){
				if (jsondata.data[i].id ==  ROOT_FOLDER_ID){
					addRootNode(jsondata.data[i]);
				}
				else {
					addFolderNode(jsondata.data[i], parent);
				}
			}
			if (!selectedFolder || selectedFolder == ROOT_FOLDER_ID ) {
				tree.select(parent);
			}
			if (tree.selected) {
				tree.selected.toggle(false, true);
			}
		}
		forceTableLoad(tree.selected);
		tree.enable();
	});
	myXHR.send(url, 'json=' + Json.toString(send));
}

function populateBaseTree() {
	tree.disable();
	jsondata = Json.evaluate(initialTree);
	for(var i=0,l=jsondata.data.length;i<l;i++){
		addRootNode(jsondata.data[i]);
	}
	if (tree.selected) {
		tree.selected.toggle(false, true);
	}
	tree.enable();
}

window.addEvent('domready',function() {
    createTree('mytree');
    createTable('mytable');
    //forceTreeReload(tree.root);
    populateBaseTree();
	var sel = Cookie.get('rokdownload_select').toInt() || 0;
	tree.select(tree.get(sel));
});

/**
* Toggles the check state of a group of boxes
*
* Checkboxes must have an id attribute in the form cb0, cb1...
* @param The number of box to 'check'
* @param An alternative field name
*/
function checkAll( fldName ) {
 if (!fldName) {
	 fldName = 'cb';
 }
 var f = document.adminForm;
 var c = f.toggle.checked;
 var n2 = 0;
 for (i=0, n=table.rows.length; i < n; i++) {
 	cb = eval( 'f.' + fldName + '' + table.rows[i].data.id );
 	if (cb) {
 		cb.checked = c;
 		n2++;
 	}
 }
}
</script>
<table width="100%" cellspacing="0">
    <tr valign="top">
    	<td colspan="2">
    		<div align="center">
			<table cellspacing="0" class="legendtable">
				<tr valign="middle">
					<th><?php echo JText::_('LABEL.LEGEND');?>: </th>
					<td><div class="published overlaythumb"></div><span class="published"><?php echo JText::_('Published');?></span></td> 
					<td>|</td>
					<td><div class="unpublished overlaythumb"></div><span class="unpublished"><?php echo JText::_('Unpublished');?></span></td>
					<td>|</td>
					<td><div class="missing overlaythumb"></div><span class="missing"><?php echo JText::_('LABEL.MISSING');?></span></td>
				</tr>
			</table>
			</div>
			<div class="sectionbar">
				<div class="t">
			 		<div class="t">
						<div class="t"></div>
			 		</div>
				</div>
				<div class="m">	
					<div id="currentfolder">
						<h2><?php echo JText::_('LABEL.CURRENTLY_SELECTED_FOLDER');?></h2> : <span id="currentfoldertext">&nbsp;</span>
					</div>
				</div>
				<div class="clr"></div>
				<div class="b">
					<div class="b">
			 			<div class="b"></div>
					</div>
				</div>
			</div>	
    	</td>
    </tr>
	<tr valign="top">
		<td id="leftside">
			<div id="treeview">
				<div class="sectionbar">
					<div class="t">
				 		<div class="t">
							<div class="t"></div>
				 		</div>
					</div>	
					<div class="m">
						<table><tbody><tr>
							<td class="button">
								<a href="#" onclick="NewFolderPopup(tree.selected, 300, 200);return false;"><img src="<?php echo $this->imagebase;?>/toolbar/new.png" class="Tips1" title="<?php echo JText::_('TIP.ADD_NEW_FOLDER');?>"></a>
							</td>
							<td class="button">
								<a href="#" onclick="window.location=editurl+tree.selected.id"><img src="<?php echo $this->imagebase;?>/toolbar/edit.png" class="Tips1" title="<?php echo JText::_('TIP.EDIT_FOLDER');?>"></a>
							</td>
							<td class="button">
								<a href="#" onclick="deleteFolder(tree.selected);"><img src="<?php echo $this->imagebase;?>/toolbar/delete.png" class="Tips1" title="<?php echo JText::_('TIP.DELETE_FOLDER');?>"></a>
							</td>
							<td class="button">
								<a href="#"  onclick="publishFolder(tree.selected);"><img src="<?php echo $this->imagebase;?>/toolbar/publish.png" class="Tips1" title="<?php echo JText::_('TIP.PUBLISH_FOLDER');?>"></a>
							</td>
							<td class="button">
								<a href="#" onclick="unpublishFolder(tree.selected);"><img src="<?php echo $this->imagebase;?>/toolbar/unpublish.png" class="Tips1" title="<?php echo JText::_('TIP.UNPUBLISH_FOLDER');?>"></a>
							</td>
							
							
							</tr>
							</tbody>
						</table>
						<h2><?php echo JText::_('LABEL.FOLDERS');?></h2>
					</div>
					<div class="clr"></div>
					<div class="b">
						<div class="b">
				 			<div class="b"></div>
						</div>
					</div>
				</div>
				<br/>
				<div id="mytree" tabindex="1"></div>
			</div>
		</td>
		<td>
			<form action="index.php" method="post" name="adminForm" autocomplete="off">
				<div id="fileview">
					<div class="sectionbar">
						<div class="t">
					 		<div class="t">
								<div class="t"></div>
					 		</div>
						</div>
						<div class="m">
							<table><tbody><tr>
								<td class="button">
									<a href="#" onclick="editFirstSelected();"><img src="<?php echo $this->imagebase;?>/toolbar/edit.png" class="Tips1" title="<?php echo JText::_('TIP.EDIT_FILE');?>"></a>
								</td>
								<td class="button">
									<a href="#" onclick="deleteSelectedFiles();"><img src="<?php echo $this->imagebase;?>/toolbar/delete.png" class="Tips1" title="<?php echo JText::_('TIP.DELETE_FILES');?>"></a>
								</td>
								<td class="button">
									<a href="#"  onclick="publishSelectedFiles();"><img src="<?php echo $this->imagebase;?>/toolbar/publish.png" class="Tips1" title="<?php echo JText::_('TIP.PUBLISH_FILES');?>"></a>
								</td>
								<td class="button">
									<a href="#" onclick="unpublishSelectedFiles();"><img src="<?php echo $this->imagebase;?>/toolbar/unpublish.png" class="Tips1" title="<?php echo JText::_('TIP.UNPUBLISH_FILES');?>"></a>
								</td>
								<td class="button">
									<a href="#" onclick="MoveFilesPopup(300, 200);return false;"><img src="<?php echo $this->imagebase;?>/toolbar/move.png" class="Tips1" title="<?php echo JText::_('TIP.MOVE_FILES');?>"></a>
								</td>
								</tr>
								</tbody>
							</table>
							<h2><?php echo JText::_('Files');?></h2>
						</div>
						<div class="clr"></div>
						<div class="b">
							<div class="b">
					 			<div class="b"></div>
							</div>
						</div>
					</div>
					<br/>
					<div id="mytable" tabindex="1"></div>
				</div>
				<input type="hidden" name="component" value="<?php echo $this->component;?>" />
				<input type="hidden" name="controller" value="rokdownloads" />
				<input type="hidden" name="option" value="com_rokdownloads" />
				<input type="hidden" name="task" value="" />
			</form>
		</td>
	</tr>
</table>
<p/>
