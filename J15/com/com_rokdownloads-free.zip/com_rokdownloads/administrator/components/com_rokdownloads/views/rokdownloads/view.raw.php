<?php
/**
 * @version $Id: view.raw.php 18489 2010-02-03 00:44:48Z btowles $
 * @package RocketTheme
 * @subpackage	RokDownloads
 * @copyright Copyright (C) 2008 RocketWerx. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 */
 
// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport( 'joomla.application.component.view' );

require_once (JPATH_COMPONENT.DS.'libs'.DS.'json.php');

/**
 * @package		RocketTheme
 * @subpackage	RokDownloads
 *
 * @since 1.5
 */
 class RokdownloadsViewRokdownloads extends JView
{
	function display($tmpl=null){
		//$this->getfolders();
		$task = JRequest::getVar('task', 'getfolders');
	}

	function getfolders($tmpl=null){
		$results= new JSONResult();
		$post = JRequest::get( 'post' );
		$model	=& $this->getModel();
		$postObj = JXJson::decode($post['json']);
		$model->importUnregisteredFolders();
		$dirs =& $model->getFolderTree($postObj->parent);
		$results->result=true;
		$results->data = array();
		foreach($dirs as $key => $value) {
			$results->data[]=$value->getJsonObject();
		}
		echo JXJson::encode($results);
	}
	
	function getsubfolders($tmpl=null){
		$results= new JSONResult();
		$post = JRequest::get( 'post' );
		$model	=& $this->getModel();
		$postObj = JXJson::decode($post['json']);
		$model->importUnregisteredFolders();
		$dirs =& $model->getSubFolderTree($postObj->parent);
		$results->result=true;
		$results->data = array();
		foreach($dirs as $key => $value) {
			$results->data[]=$value->getJsonObject();
		}
		echo JXJson::encode($results);
	}

	function getFilesForFolder($tmpl=null){
		$results= new JSONResult();
		$post = JRequest::get( 'post' );
		$model	=& $this->getModel();
		$postObj = JXJson::decode($post['json']);
		$folder =& $model->getFile($postObj->fid);
		$model->importUnregisteredFiles($folder);
		$filelist =& $model->getDBFilesForFolder($folder);
		if (is_array($filelist)) {
			$results->result = true;
			$results->data = array();
			foreach($filelist as $key => $value) {
				$results->data[]=$value->getJsonObject();
			}
 		}
 		else
 			$results->errormsg = $model->getError(null,false);
		echo JXJson::encode($results);
	}

	function move($tmpl=null){
		$results= new JSONResult();
		$post = JRequest::get( 'post' );
		$postObj = JXJson::decode($post['json']);
		$model	=& $this->getModel();
		$toFolder = $model->getFile($postObj->to);
		foreach($postObj->ids as $nodeid) {
			$node = $model->getFile($nodeid);
			$results->result = $model->reorderNode($node,  $toFolder->id, $postObj->where);
			if (!$results->result) {
				$results->errormsg = JText::sprintf("ERROR.SERVER_ERROR_MOVING", $node->path, $model->getError());
				break;
			}
		}
		echo JXJson::encode($results);
	}
	
	
	
	function delete($tmpl=null){
		$results= new JSONResult();
		$post = JRequest::get( 'post' );
		$postObj = JXJson::decode($post['json']);
		$model	=& $this->getModel();

		foreach($postObj->ids as $nodeid) {
			$node = $model->getFile($nodeid);
			$results->result = $model->deleteNode($node);
			if (!$results->result) {
				$results->errormsg = JText::sprintf("ERROR.SERVER_ERROR_DELETING", $node->path, $model->getError());
				break;
			}
		}
		echo JXJson::encode($results);
	}
	
	function publish($tmpl=null){
		$results= new JSONResult();
		$post = JRequest::get( 'post' );
		$postObj = JXJson::decode($post['json']);
		$model	=& $this->getModel();
		
		foreach($postObj->ids as $nodeid) {
			$node = $model->getFile($nodeid);
			if ($node->folder) {
				$model->findUnregistered();
			}
			$results->result = $model->publish($node);
			if (!$results->result) {
				$results->errormsg = JText::sprintf("ERROR.SERVER_ERROR_PUBLISHING", $node->path, $model->getError());
				break;
			}
		}
		echo JXJson::encode($results);
	}
	
	function unpublish($tmpl=null){
		$results= new JSONResult();
		$post = JRequest::get( 'post' );
		$postObj = JXJson::decode($post['json']);
		$model	=& $this->getModel();
		
		foreach($postObj->ids as $nodeid) {
			$node = $model->getFile($nodeid);
			$results->result = $model->unpublish($node);
			if (!$results->result) {
				$results->errormsg = JText::sprintf("ERROR.SERVER_ERROR_PUBLISHING", $node->path, $model->getError());
				break;
			}
		}
		echo JXJson::encode($results);
	}
	
	function addnewfolder($tmpl=null){
		$results= new JSONResult();
		$post = JRequest::get( 'post' );
		$postObj = JXJson::decode($post['json']);
		$model	=& $this->getModel();
		
		$parent = $model->getFile($postObj->parent);
		$name = $postObj->name;

		$results->result = $model->newFolder($name, $parent);
		if (!$results->result) {
			$results->errormsg = JText::sprintf("ERROR.SERVER_ERROR_ADDING_NEW_FOLDER", $name, $model->getError());
		}
		echo JXJson::encode($results);
	}
}
?>
