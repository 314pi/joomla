<?php
/**
 * @version $Id: view.html.php 32452 2011-01-10 21:43:13Z djamil $
 * @package RocketTheme
 * @subpackage	RokDownloads
 * @copyright Copyright (C) 2008 RocketWerx. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport( 'joomla.application.component.view' );
jimport( 'joomla.html.html.list');
jimport( 'joomla.html.html.select');
require_once (JPATH_COMPONENT.DS.'libs'.DS.'fileutils.php');
require_once (JPATH_COMPONENT.DS.'libs'.DS.'json.php');

/**
 * @package		RocketTheme
 * @subpackage	RokDownloads
 *
 * @since 1.5
 */
class RokdownloadsViewRokdownloads extends JView
{
	/**
	 * Display the view
	 */
	function display($tpl = null)
	{
		global $mainframe;

		$model	=& $this->getModel();
		$component = JRequest::getVar('component');
		$selectedFolder = JRequest::getVar('selectedFolder');
		if ($selectedFolder < 1) {
			$selectedFolder = 1;
		}
		$option = JRequest::getVar('option');
		$document = & JFactory::getDocument();
		JHTML::_('behavior.tooltip');

		$document->setTitle( JText::_('LABEL.ROKDOWNLOADS_MANAGER') );
		JToolBarHelper::title(   JText::_( 'LABEL.ROKDOWNLOADS_MANAGER' ),  'rokdownload.png');
		JHTML::_('behavior.keepalive');
		$bar = & JToolBar::getInstance('toolbar');
		$bar->addButtonPath(JPATH_SITE.DS.'administrator'.DS.'components'.DS.'com_rokdownloads'.DS.'assets'.DS.'buttons'.DS);
		$bar->appendButton( 'RokDownloadsPopup', 'upload', "Upload", "UploadPopup", array('size'=> "{x: 750, y: 450}"));
		JToolBarHelper::divider();
		JToolBarHelper::help( 'screen.rokdownloads' );

		$uri	=& JFactory::getURI();

		// Get the page/component configuration
		$assetbase = 'components/com_rokdownloads/assets';
		$document->addScript($assetbase.'/utils/utils.js');
		
		$document->addStyleSheet($assetbase . '/rokdownload.css');

		// Add Mootools
		//$document->addScript($assetbase . '/mootools.v1.12.js');

		//Add mootree
		$treebase = $assetbase.'/tree/';
		$imagebase = $assetbase.'/images/';
		$document->addScript($treebase . 'mootree.js');
		$document->addStyleSheet($treebase . 'mootree.css');

		//add mootable
		$tablebase =  $assetbase.'/table/';
		$document->addScript($tablebase.'mootable.js');
		$document->addStyleSheet($tablebase.'mootable.css');
		
		
		// Get the initial tree structure
		$results= new JSONResult();
		$model->importUnregisteredFolders();
		$dirs =& $model->getFolderTree();
		$results->result=true;
		$results->data = array();
		foreach($dirs as $key => $value) {
			$results->data[]=$value->getJsonObject();
		}
		$initialTree =& JXJson::encode($results);

		
		//Set base Ajax call url
		$ajaxURL = $uri->current()."?option=".$option."&format=raw&task=";
		
		$this->assignRef('initialTree', $initialTree); 
		$this->assignRef('ajaxURI', $ajaxURL);
		$this->assignRef('folders',$dirs);
		$this->assignRef('treebase',$treebase);
		$this->assignRef('imagebase',$imagebase);
		$this->assignRef('component', $component);
		$this->assignRef('selectedFolder',$selectedFolder);
		$this->assignRef('request_url',	$uri->toString());
		$this->assignRef('option', $option);
		
		
		parent::display($tpl);
	}
	
	function uploadselect ($tmpl=null) {
		global $mainframe, $option;
		$config =& JComponentHelper::getParams('com_media');
		$model	=& $this->getModel();
		$pid = JRequest::getVar('pid');
		$parent = $model->getFile($pid);
		$this->assignRef('parent', $parent);
		$msg = '';
		$this->assignRef('msg',$msg);
		$this->assignRef( 'session', JFactory::getSession());
		$this->assignRef( 'params', JComponentHelper::getParams($option));
		
		$document = & JFactory::getDocument();
		$document->addStyleSheet('components/com_media/assets/mediamanager.css');
		
		if ($config->get('enable_flash', 1)) {
			JHTML::_('behavior.uploader', 'file-upload', array('allowDuplicates' => false));
		}
		
		
		parent::display("uploadselect");
		
	}
	
	function newfolder ($tmpl=null) {
		global $mainframe;
		$model	=& $this->getModel();
		$pid = JRequest::getVar('pid');
		$parent = $model->getFile($pid);
		
		$this->assignRef('parent', $parent);
		$msg = '';
		$this->assignRef('msg',$msg);
		parent::display("newfolder");
	}
	
	function movefiles ($tmpl=null) {
		global $mainframe;
		
		$model	=& $this->getModel();
		$pid = JRequest::getVar('pid');
		$parent = $model->getFile($pid);
		$this->assignRef('parent', $parent);
		$folders =& $model->getFullDBFolders();
		$lists['folders'] = JHTML::_('select.genericlist', $folders, 'tofolder', 'class="inputbox" size="1" ', 'id', 'path');
		$this->assignRef('lists',		$lists);
		$msg = '';
		$this->assignRef('msg',$msg);
		parent::display("movefiles");
	}
}
?>

