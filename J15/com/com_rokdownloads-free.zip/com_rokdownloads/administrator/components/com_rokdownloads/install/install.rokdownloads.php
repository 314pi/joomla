<?php
/**
 * @version $Id: install.rokdownloads.php 18489 2010-02-03 00:44:48Z btowles $
 * @package RocketTheme
 * @subpackage	RokDownloads
 * @copyright Copyright (C) 2008 RocketWerx. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 */
 // no direct access
defined('_JEXEC') or die('Restricted access');
jimport('joomla.filesystem.folder');
jimport('joomla.filesystem.file');	
 
class Status {
	var $STATUS_FAIL = 'Failed';
	var $STATUS_SUCCESS = 'Success';
	var $infomsg = array();
	var $errmsg = array();
	var $status;
}

$rok_database = JFactory::getDBO();
$rok_install_status = array();

function rok_com_install() {
	return com_rokdownloads_install();
}

function com_rokdownloads_install() {
	global $rok_install_status;
	$db = JFactory::getDBO();
	
	$status = new Status();
	$status->status = $status->STATUS_FAIL;
	$status->component = "com_rokdownloads";
	
	// See if we need to apply the rokversions table fix
	if(!com_rokdownloads_check_for_versions_table_fix_096a($db, $status)){
		return false;
	}
	
	//see if the versions table is there
	if (!com_rokdownloads_check_for_versions_table($db)) {
		if (com_rokdownloads_check_for_table($db)) {
			if (!com_rokdownloads_upgrade_to_96a($db,$status)){
				return false;
			}
		}
		if (!com_rokversions_newtable($db,$status)) {
			return false;
		}
	}
	
	// update the rokversions table
	if (!com_rokversions_update_version($db, $status)) {
		return false;
	}
	
	if (!com_rokdownloads_check_for_table($db)) {
		if (!com_rokdownloads_newtable($db, $status)){
			return false;
		}

	}
	if (!com_rokdownloads_upgrade_paths($db, $status)) {
		return false;
	}
	
	

	// Create the default rokdownloads folder if it doesnt exist 
	if (!JFolder::exists(JPATH_SITE.DS."rokdownloads")){
		JFolder::create(JPATH_SITE.DS."rokdownloads");
	}
	
	if (!com_rokdownloads_initial_data_population($db, $status)){
		return false;
	}
	if(!com_rokdownloads_update_menu_items($db, $status)){
		
		return false;
	}
	
	if (count($status->errmsg) == 0) {
		$status->status = $status->STATUS_SUCCESS;
	}
	
	$rok_install_status["com_rokdownloads"] = $status;
	return true;
}


/**
 * Create the base data for the #__rokdownloads table if its not in there
 */ 
function com_rokdownloads_initial_data_population($db, &$status) {
	// Check to see if Root Folder is defined
	$check_query = "select id from #__rokdownloads where id = 1";
	$db->setQuery($check_query);
	if (!$db->query()) {
		$status->errormsg[] = $db->getErrorMsg();
		print_r($status);
		return false;
	}
	else if ($db->getNumRows() == 0) {
		// Insert the main downloads folder
		$root_folder_insert = 
		"insert into `#__rokdownloads` " .
		"(`id`, `name`     ,`displayname`,`path`,                          `folder`,`introtext`,`thumbnail`,`params`,`lft`,`rgt`) VALUES " .
		"(1 , 'Downloads','Downloads'  ,'/'    ,1       ,''         ,''         ,''      ,1    ,2    ) ";
		$db->setQuery($root_folder_insert);
		if (!$db->query()) {
			$status->errormsg[] = $db->getErrorMsg();
			print_r($status);
			return false;
		}
		return true;
	}
	else {
		$status->introtext[] = JText::_("Root Folder entry already exists.  Ignoring.");
		return true;
	}
}

function com_rokdownloads_update_menu_items($db, &$status) {
	$db->setQuery("SELECT id FROM #__components WHERE name= 'RokDownloads'");
	
	if (!$db->query()) {
		$status->errormsg[] = $db->getErrorMsg();
		return false;
	}
	else {
		$id = $db->loadResult();
		// edit admin menus
		$db->setQuery("UPDATE #__components SET admin_menu_alt = 'Manage download items/files' WHERE parent='$id' AND name = 'Manager'");
		if (!$db->query()) {
			$status->errormsg[] = $db->getErrorMsg();
			return false;
		}
		$db->setQuery("UPDATE #__components SET admin_menu_alt = 'Configure Rokdownloads' WHERE parent='$id' AND name = 'Configuration'");
		if (!$db->query()) {
			$status->errormsg[] = $db->getErrorMsg();
			return false;
		}
	}
	return true;
}

function com_rokdownloads_check_for_table($db) {
	$table_check_query = "select id from #__rokdownloads where id = 1";
	$db->setQuery($table_check_query);
	if (!$db->query()) {
		return false;
	}
	return true;
}

function com_rokdownloads_check_for_versions_table($db) {
	$table_check_query = "select count(product) from #__rokversions";
	$db->setQuery($table_check_query);
	if (!$db->query()) {
		return false;
	}
	return true;
}

function com_rokdownloads_check_for_versions_table_fix_096a($db, $status) {
	$conf =& JFactory::getConfig();
	$prefix 	= $conf->getValue('config.dbprefix');
	if ("jos" != $prefix && !com_rokdownloads_check_for_versions_table($db)) {
		$version = com_rokdownloads_get_rokdownloads_version($db, $status, "jos");		
		if("0.96a" == $version) {
			if (!com_rokversions_newtable($db, $status)) {
				return false;
			}
			
			if (!com_rokversions_update_version($db, $status, "0.96a")) {
				return false;
			}
		}
	}
	return true;
}

function com_rokdownloads_get_rokdownloads_version($db, &$status, $prefix = "jos") {
	if ($prefix != "jos"){ 
		$query = "select version from from " . $prefix . "_rokversions where product = 'rokdownloads'";
	}
	else {
		$query = "select version from from #__rokversions where product = 'rokdownloads'";
	}
	$db->setQuery($query);
	if (!$db->query()) {
		$status->errormsg[] = $db->getErrorMsg();
		return false;
	}
	$version = $db->loadResult();
	return $version;
}
	
function com_rokdownloads_upgrade_to_96a($db, &$status){
	$query = "ALTER TABLE #__rokdownloads ADD COLUMN metadata text";
	$db->setQuery($query);
	if (!$db->query()) {
		$status->errormsg[] = $db->getErrorMsg();
		return false;
	}
	$query = "ALTER TABLE #__rokdownloads ADD COLUMN metadesc text";
	$db->setQuery($query);
	if (!$db->query()) {
		$status->errormsg[] = $db->getErrorMsg();
		return false;
	}
	$query = "ALTER TABLE #__rokdownloads ADD COLUMN metakey text"; 
	$db->setQuery($query);
	if (!$db->query()) {
		$status->errormsg[] = $db->getErrorMsg();
		return false;
	}
	return true;
}


function com_rokdownloads_upgrade_paths($db, &$status){
	$query = "update #__rokdownloads set path = REPLACE(path, '\\\\', '/')";
	$db->setQuery($query);
	if (!$db->query()) {
		$status->errormsg[] = $db->getErrorMsg();
		echo  $db->getErrorMsg();
		return false;
	}
	$query = "update #__rokdownloads set path = REPLACE(path, '//','/')";
	$db->setQuery($query);
	if (!$db->query()) {
		$status->errormsg[] = $db->getErrorMsg();
		echo  $db->getErrorMsg();
		return false;
	}
	$query = "update #__rokdownloads set path = CONCAT('/',path)";
	$db->setQuery($query);
	if (!$db->query()) {
		$status->errormsg[] = $db->getErrorMsg();
		echo  $db->getErrorMsg();
		return false;
	}
	$query = "update #__rokdownloads set path = REPLACE(path, '//','/')";
	$db->setQuery($query);
	if (!$db->query()) {
		$status->errormsg[] = $db->getErrorMsg();
		echo  $db->getErrorMsg();
		return false;
	}
	return true;

}

function com_rokdownloads_newtable($db, &$status) {
	$create_rokdownloads_table_sql =
		"CREATE TABLE IF NOT EXISTS `#__rokdownloads` " .
		"( " .
		"   `id` int(10) NOT NULL auto_increment, " .
		"   `name` text NOT NULL, " .
		"   `displayname` text NOT NULL, " .
		"   `path` text NOT NULL, " .
		"   `folder` tinyint(4) NOT NULL default '0', " .
		"   `filesize` bigint(19) NOT NULL default '0', " .
		"   `introtext` mediumtext, " .
		"   `fulltext` mediumtext, " .
		"   `thumbnail` varchar(255) default NULL, " .
		"   `access` int(10) NOT NULL default '0', " .
		"   `params` text, " .
		"   `downloads` int(10) NOT NULL default '0', " .
		"   `published` tinyint(4) NOT NULL default '0', " .
		"   `lft` int(10) unsigned NOT NULL, " .
		"   `rgt` int(10) unsigned NOT NULL, " .
		"   `created_time` datetime NOT NULL default '0000-00-00 00:00:00', " .
		"   `created_by` int(10) NOT NULL default '0', " .
		"   `modified_time` datetime NOT NULL default '0000-00-00 00:00:00', " .
		"   `modified_by` int(10) NOT NULL default '0', " .
		"   `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00', " .
		"   `checked_out` int(10) NOT NULL default '0', " .
		"   `metadata` text, " .
		"   `metadesc` text, " .
		"   `metakey` text, " .
		"   PRIMARY KEY (`id`), " .
		"   KEY `filesize` (`filesize`), " .
		"   KEY `downloads` (`downloads`), " .
		"   KEY `published` (`published`), " .
		"   KEY `access` (`access`), " .
		"   KEY `created_time` (`created_time`), " .
		"   KEY `checked_out_time` (`checked_out_time`), " .
		"   KEY `modified_time` (`modified_time`), " .
		"   KEY `IX_rokdownloads_lft` (`lft`), " .
		"   KEY `IX_rokdownloads_rgt` (`rgt`), " .
		"   KEY `IX_rokdownloads_tree` (`lft`,`rgt`) " .
		") " .
		"ENGINE=MyISAM CHARACTER SET utf8";
	$db->setQuery($create_rokdownloads_table_sql);
	if (!$db->query()) {
		$status->errormsg[] = $db->getErrorMsg();
		return false;
	}
	return true;
}

function com_rokversions_newtable($db, &$status) {
	
	$query =
		"CREATE TABLE IF NOT EXISTS `#__rokversions` " .
		"( " .
		"   `product` varchar(255) NOT NULL, " .
		"   `version` varchar(255) NOT NULL " .
		") " .
		"ENGINE=MyISAM CHARACTER SET utf8";
	$db->setQuery($query);
	if (!$db->query()) {
		$status->errormsg[] = $db->getErrorMsg();
		return false;
	}
	$query = "insert into #__rokversions (product,version) values ('rokdownloads','\1.0.2')";
	$db->setQuery($query);
	if (!$db->query()) {
		$status->errormsg[] = $db->getErrorMsg();
		return false;
	}
	return true;
}

function com_rokversions_update_version($db, &$status, $version = "\1.0.2") {
	$query = "update #__rokversions set version = '" . $version . "' where product = 'rokdownloads'";
	$db->setQuery($query);
	if (!$db->query()) {
		$status->errormsg[] = $db->getErrorMsg();
		return false;
	}
	return true;
}
