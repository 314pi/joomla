<?php

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * Utility class working with menu select lists
 *
 * @static
 * @package 	Joomla.Framework
 * @subpackage	HTML
 * @since		1.5
 */
class JHTMLRokDownloadMenu
{
	/**
	* Build the multiple select list for Rokdownload menu Items 
	*/
	function linkoptions( $all=false, $unassigned=false )
	{
		$db =& JFactory::getDBO();
	
		$mitems = array();

		// get a list of the menu items
		$query = 'SELECT m.id, m.parent, m.name, m.menutype'
		. ' FROM #__menu AS m'
		. ' ORDER BY m.menutype, m.parent, m.ordering'
		;
		$db->setQuery( $query );
		$all_mitems = $db->loadObjectList('id');
		
		
		
		// get a list of the menu items
		$query = 'SELECT m.id' 
		. ' FROM #__menu AS m , #__components c'
		. ' WHERE c.id = m.componentid and c.name = "RokDownloads"'
		. ' ORDER BY m.menutype, m.parent, m.ordering'
		;
		$db->setQuery( $query );
		$download_items = $db->loadResultArray();
		
		
		$keep_items = array();
		foreach ($download_items as $d_id) {			
			$current_item = $all_mitems[$d_id];
			$keep_items[$current_item->id]=$current_item->id;
			$next_id = $current_item->parent;
			while ($next_id != 0) 
			{
				$current_item = $all_mitems[$next_id];
				$keep_items[$current_item->id]=$current_item->id;		
				$next_id = $current_item->parent;
			}
		}
		
		// get only the keepers
		foreach($all_mitems as $miposs) {
			if (array_key_exists($miposs->id, $keep_items)) {
				$mitems[] = $miposs;
			}
		}
		
		if (!empty($mitems)) { 
			$mitems_temp = $mitems;		
			// establish the hierarchy of the menu
			$children = array();
			// first pass - collect children
			foreach ( $mitems as $v )
			{
				$id = $v->id;
				$pt = $v->parent;
				$list = @$children[$pt] ? $children[$pt] : array();
				array_push( $list, $v );
				$children[$pt] = $list;
			}
			// second pass - get an indent list of the items
			$list = JHTMLRokDownloadMenu::TreeRecurse( intval( $mitems[0]->parent ), '', array(), $children, 9999, 0, 0 );
	
			// Code that adds menu name to Display of Page(s)
			$mitems_spacer 	= $mitems_temp[0]->menutype;
	
			$mitems = array();
			if ($all | $unassigned) {
				$mitems[] = JHTML::_('select.option',  '<OPTGROUP>', JText::_( 'Menus' ) );
	
				if ( $all ) {
					$mitems[] = JHTML::_('select.option',  0, JText::_( 'All' ) );
				}
				if ( $unassigned ) {
					$mitems[] = JHTML::_('select.option',  -1, JText::_( 'Unassigned' ) );
				}
	
				$mitems[] = JHTML::_('select.option',  '</OPTGROUP>' );
			}
	
			$lastMenuType	= null;
			$tmpMenuType	= null;
			$downad_menu_items = array_flip($download_items);
			foreach ($list as $list_a)
			{
				if ($list_a->menutype != $lastMenuType)
				{
					if ($tmpMenuType) {
						$mitems[] = JHTML::_('select.option',  '</OPTGROUP>' );
					}
					$mitems[] = JHTML::_('select.option',  '<OPTGROUP>', $list_a->menutype );
					$lastMenuType = $list_a->menutype;
					$tmpMenuType  = $list_a->menutype;
				}
	
				$mitems[] = JHTML::_('select.option',  $list_a->id, $list_a->treename, 'value', 'text', (array_key_exists($list_a->id, $downad_menu_items))?false:true);
			}
			if ($lastMenuType !== null) {
				$mitems[] = JHTML::_('select.option',  '</OPTGROUP>' );
			}
		}
		return $mitems;
	}

	function treerecurse( $id, $indent, $list, &$children, $maxlevel=9999, $level=0, $type=1 )
	{
		if (@$children[$id] && $level <= $maxlevel)
		{
			foreach ($children[$id] as $v)
			{
				$id = $v->id;

				if ( $type ) {
					$pre 	= '<sup>|_</sup>&nbsp;';
					$spacer = '.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
				} else {
					$pre 	= '- ';
					$spacer = '&nbsp;&nbsp;';
				}

				if ( $v->parent == 0 ) {
					$txt 	= $v->name;
				} else {
					$txt 	= $pre . $v->name;
				}
				$pt = $v->parent;
				$list[$id] = $v;
				$list[$id]->treename = "$indent$txt";
				$list[$id]->children = count( @$children[$id] );
				$list = JHTMLRokDownloadMenu::TreeRecurse( $id, $indent . $spacer, $list, $children, $maxlevel, $level+1, $type );
			}
		}
		return $list;
	}
}