<?php
	/**
	 * @version		$Id: fileutils.php 4369 2008-04-30 01:51:00Z wonderslug $
	 * @package		JXtended
	 * @subpackage	Webservices
	 * @copyright	Copyright (C) 2007 Louis Landry. All rights reserved.
	 * @license		GNU/GPL
	 */
	
	// Check to ensure this file is included in Joomla!
	defined('_JEXEC') or die();

    /**
     * Format a number of bytes into a human readable format.
     * Optionally choose the output format and/or force a particular unit
     *
     * @param   int     $bytes      The number of bytes to format. Must be positive
     * @param   string  $format     Optional. The output format for the string
     * @param   string  $force      Optional. Force a certain unit. B|KB|MB|GB|TB
     * @return  string              The formatted file size
     */
    function filesize_format($bytes, $format = '', $force = '')
    {
        $force = strtoupper($force);
        $defaultFormat = '%01d %s';
        if (strlen($format) == 0)
            $format = $defaultFormat;
 
        $bytes = max(0, (int) $bytes);
 
        $units = array('B', 'KB', 'MB', 'GB', 'TB', 'PB');
 
        $power = array_search($force, $units);
 
        if ($power === false)
            $power = $bytes > 0 ? floor(log($bytes, 1024)) : 0;
 
 		if (0 == $power) $format = $defaultFormat;
        return sprintf($format, $bytes / pow(1024, $power), $units[$power]);
    }
?>
