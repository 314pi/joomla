<?php
/**
 * @version $Id: rokdownloads.php 7406 2008-12-16 22:02:27Z btowles $
 * @package RocketTheme
 * @subpackage	RokDownloads
 * @copyright Copyright (C) 2008 RocketWerx. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport( 'joomla.application.component.model' );

/**
 * Rockdownloads Component Rokdownloads Model
 *
 * @package		RocketTheme
 * @subpackage	RokDownloads
 *
 * @since 1.5
 */
class RokdownloadsModelSelect extends JModel
{
	function getDownloadMenus()
	{
	 global $mainframe;  
		$app = &JFactory::getApplication();
		
		// load the list of menu items
		$query = 'SELECT m.id as id, m.parent as parent, m.name as name, m.menutype as menutype, m.type as type' .
				' FROM #__menu m, #__components c' .
				' where c.id = m.componentid and c.name = "RokDownloads" m.ordering != 0' .
				' ORDER BY m.menutype, m.parent, m.ordering'
				;

		$this->_db->setQuery($query);
		$menuItems = $this->_db->loadObjectList();
		var_dump($menuItems);
	}
	
	function getDownloadsForMenuItems() {
	
		$menu_downloads = array();
		
		$query = 'SELECT m.id as id, m.params as params ' .
				' FROM #__menu m, #__components c' .
				' where c.id = m.componentid and c.name = "RokDownloads" and m.ordering != 0' .
				' ORDER BY m.menutype, m.parent, m.ordering'
				;

		$this->_db->setQuery($query);
		if (!$this->_db->query())
	    {
	    	return $menu_downloads;
	    }
		$menuItems = $this->_db->loadObjectList('id');
		
		$query = 'SELECT node.id as id, node.name AS name, (COUNT(parent.name) - 1) as depth' .
		' FROM #__rokdownloads AS node,' .
		' #__rokdownloads AS parent' .
		' WHERE node.lft BETWEEN parent.lft AND parent.rgt' .
		' GROUP BY node.name' . 
		' ORDER BY node.lft';
		
		$this->_db->setQuery($query);
		if (!$this->_db->query())
	    {
	    	return array();
	    }
		$downloads = $this->_db->loadObjectList('id');
		
		reset($menuItems);
		while (list($key, $value) = each($menuItems)) {
			$menuItem =& $menuItems[$key];
			$params = new JParameter($menuItem->params);
			
			$folder = true;
			$downloadItem_id = $params->get('top_level_folder',false);
			if (!$downloadItem_id) {
				$downloadItem_id = $params->get('filetodisplay');
				$folder = false;
			}
			
			if (!$folder) {
				$menu_downloads[$menuItem->id][0] = array('id' => $downloads[$downloadItem_id]->id, 'name' => $downloads[$downloadItem_id]->name);
				continue;
			}
			else { 
				$current_menu_set = array();
				$start_depth = 0;
				$populating = false;
				reset($downloads);
				while (list($dwn_key, $dwn_value) = each($downloads)) {
					$download =& $downloads[$dwn_key];
					
					if (!$populating && $download->id == $downloadItem_id){
						$populating = true;
						$start_depth = $download->depth;
						$current_menu_set[] = array('id' => $download->id, 'name' => $download->name);
					}
					else if ($populating && $download->depth > $start_depth) {
						$indent = '';
						for ($i = 0; $i < ($download->depth - $start_depth); $i++){
							$indent .= "  ";
						}
						$indent .= "- " . $download->name;
						$current_menu_set[] = array('id' => $download->id, 'name' => $indent);
					}
					else if ($populating && $download->depth == $start_depth){
						break;
					}
				}
				$menu_downloads[$menuItem->id] = $current_menu_set;
			} 		
		} 
		return $menu_downloads;
	}
}
?>
