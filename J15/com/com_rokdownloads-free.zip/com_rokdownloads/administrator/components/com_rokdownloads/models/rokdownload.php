<?php
/**
 * @version $Id: rokdownload.php 20130 2010-03-16 00:34:26Z btowles $
 * @package RocketTheme
 * @subpackage	RokDownloads
 * @copyright Copyright (C) 2008 RocketWerx. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport('joomla.application.component.model');

/**
 * Rokdownloads Component Model Rokdownload
 *
 * @package		RocketTheme
 * @subpackage	RokDownloads
 *
 * @since 1.5
 */
class RokdownloadsModelRokdownload extends JModel
{

	function __construct()
	{
		parent::__construct();

		$array = JRequest::getVar('fid',  0, '', 'array');
		$this->getFile((int)$array[0]);

	}

	function getFile($id) {
		$row =& $this->getTable('rokdownloads');
		if (!$row->load($id)) {
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
		return $row;
	}

	/**
	 * Gets the full hierarchy of ordered folders from the database.
	 *
	 * @access public
	 * @return Array An ordered array of folders if successfull and false if not
	 */
	function getFullDBFolders($excludefolder = null){
		$query = 'SELECT node.*, (COUNT(parent.name) - 1) AS depth  '
				.'FROM #__rokdownloads AS node, '
                .'#__rokdownloads AS parent '
                .'WHERE node.lft >= parent.lft AND node.lft <= parent.rgt And node.folder = 1 '
                .'GROUP BY node.id '
                .'ORDER BY node.lft';
        $dbrows = $this->_getList($query);
        if (!$dbrows) {
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
        $folders = array();
        foreach ($dbrows  as $dbrow) {

        	if ($excludefolder != null) {
        		if (!(($dbrow->lft >= $excludefolder->lft) && ($dbrow->rgt <= $excludefolder->rgt)))
        		{
        			$folder =& $this->getTable("rokdownloads");
        			$folder->bind($dbrow);
					$folders[] = $folder;
        		}
        	}
        	else {
        		$folder =& $this->getTable("rokdownloads");
        	  	$folder->bind($dbrow);
        		$folders[] = $folder;
        	}

        }
        return $folders;
	}

	function getNullDate() {
		return $this->_db->getNullDate();
	}

	/**
	 * Method to checkin/unlock the download item
	 *
	 * @access	public
	 * @return	boolean	True on success
	 * @since	1.5
	 */
	function checkin($fileid = null)
	{
		if (!$fileid) {
			return false;
		}
		$file =& $this->getFile($fileid);
		if(!$file->checkin()) {
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
		return true;
	}

	/**
	 * Method to checkout/lock the download item
	 *
	 * @access	public
	 * @param	int	$uid	User ID of the user checking the article out
	 * @return	boolean	True on success
	 * @since	1.5
	 */
	function checkout($fileid, $uid = null)
	{
		if (!$fileid) {
			return false;
		}
		$file =& $this->getFile($fileid);
		
		// Make sure we have a user id to checkout the item with
		if (is_null($uid)) {
			$user	=& JFactory::getUser();
			$uid	= $user->get('id');
		}
		// Lets get to it and checkout the thing...
		if(!$file->checkout($uid)) {
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
		return true;
	}

	/**
	 * Method to store the download item into database
	 *
	 * @access	public
	 * @return	boolean	True on success
	 * @since	1.5
	 */
 	function store($data, $rdsmodel)
	{
		// check for changes
		// validate changes
		// check to see if there is already file/folder of that name in parrent folder 
		// move/rename if needed
		// save changes to db
		jimport('joomla.filesystem.file');
		jimport('joomla.filesystem.folder');
		
		

		$original = $this->getFile($data['id']);

		$row =& $this->getTable('rokdownloads');

		// Bind the form fields to the rokdownload table
		if (!$row->bind($data)) {
			$this->setError($this->_db->getErrorMsg());
			return -1;
		}
		
		$this->saveContentPrep($row);
		
		$path = "";
		
		if ($row->id != 1) {
		
			// set the correct path
			$original_parent =& $original->getParent();
			
			$parent =& $this->getFile($data['parentid']);
			
			$path  = $parent->path;
		}
		if ($path != "/"){
			$path .= "/";
		}
		if ($row->id != 1) {
			$path .= $row->name;
		}
		
		// Make sure the download item is valid
		if (!$row->check()) {
			$this->setError($row->getError());
			return -1;
		}
		$user	=& JFactory::getUser();
		$uid	= $user->get('id');
		
		$params		= JRequest::getVar( 'params', null, 'post', 'array' );


		$row->created_by = $original->created_by;
		if ($params['created'] == $original->created_time) {
			$row->created_time = $original->created_time;
		}
		else {
			$row->created_time = $params['created'];
		}
		
		$row->modified_by = $uid;
		if ($params['modified'] == $original->modified_time) {
			$row->modified_time = gmdate('Y-m-d H:i:s');	
		}
		else {
			$row->modified_time = $params['modified'];
		}
		
		if ($params['downloads'] != '') {
			$row->downloads = $params['downloads'];
		}
		
		// Check to see if path has changed
		if ($path != $original->path) {
			$fullpath = JPath::clean(COM_ROKDOWNLOADS_BASE.$path);
			$allready_there_folder  = JFolder::exists($fullpath);
			$allready_there_file  = JFile::exists($fullpath);	
			if ($allready_there_folder || $allready_there_file) {
				$this->setError(JText::_('WARN.FILE_OR_FOLDER_ALREADY_EXISTS'));
				return -1;
			}
			$row->path = $path;
		}
		
		$customparams		= JRequest::getVar( 'customparams', null, 'post', 'array' );
		// Build parameter INI string
		if (is_array($customparams))
		{
			$txt = array ();
			foreach ($customparams as $k => $v) {
				$txt[] = "$k=$v";
			}
			$row->params = implode("\n", $txt);
		}
		
		
		// Get metadata string
		$metadata = JRequest::getVar( 'meta', null, 'post', 'array');
		if (is_array($metadata))
		{
			$txt = array();
			foreach ($metadata as $k => $v) {
				if ($k == 'description') {
					$row->metadesc = $v;
				} elseif ($k == 'keywords') {
					$row->metakey = $v;
				} else {
					$txt[] = "$k=$v";
				}
			}
			$row->metadata = implode("\n", $txt);
		}
		
		// Lock Table
		$DBL = new DB($this->_db);
		$DBL->lock();
		
		// Store the download item to the database
		// We will adjust order in a sec
		if (!$row->store()) {
			$this->setError($this->_db->getErrorMsg());
			$DBL->unlock();
			return -1;
		}
		if ($path != $original->path) {
			//rename or move
			
			if ($row->id != 1 && $original_parent->id != $parent->id) {
				$reorderres = $rdsmodel->reorderNode($row, $parent->id);
				if (!$reorderres) {
					$this->setError($rdsmodel->getError(null,false));
					$DBL->unlock();
					return -1;
				}
			}

			$moveresult = false;
			if ($row->folder) {
				 //Move the nodes into the hole and update paths
				$old_path_length = strlen($original->path);
				$query = 'UPDATE #__rokdownloads set path=concat("'.$this->_db->getEscaped($row->path).'","'.$this->_db->getEscaped("/").'",substr(path from '.$old_path_length.'+2)) '
						.' where lft > '. $row->lft . ' and rgt < ' . $row->rgt;
				$this->_db->setQuery( $query );
			    if (!$this->_db->query())
			    {
			    	$this->setError($this->_db->getErrorMsg());
			    	$DBL->unlock();
			    	return false;
		}
			    $moveresult = JFolder::move($original->getFullPath(),$row->getFullPath());
			}
			else
			{
				$moveresult = JFile::move($original->getFullPath(),$row->getFullPath());
			}
			if (!$moveresult) {
				$this->setError(JText::_('ERROR.MOVING_FILE'));
		        $DBL->unlock();
				return -1;
			}
		}
		$DBL->unlock();
		if ($row->id != 1)
			return $parent->id;
		else
			return 1;
	}

 	function saveContentPrep( &$row )
	{

		// Get submitted text from the request variables
		$text = JRequest::getVar( 'text', '', 'post', 'string', JREQUEST_ALLOWRAW );

		// Clean text for xhtml transitional compliance
		jimport('joomla.filter.output');
		$text		= str_replace( '<br>', '<br />', $text );

		// Search for the {readmore} tag and split the text up accordingly.
		$tagPos	= JString::strpos( $text, '<hr id="system-readmore" />' );

		if ( $tagPos === false )
		{
			$row->introtext	= $text;
		} else
		{
			$row->introtext	= JString::substr($text, 0, $tagPos);
			$row->fulltext	= JString::substr($text, $tagPos + 27 );
		}


		return true;
	}
	
	function getParentId($id=0) {
		if ($id == 0) {
			return $id;
		}
		$file = $this->getFile($id);
		$parent = $file->getParent();
		return $parent->id;
	}

	/**
	* Function to reset Hit count of an article
	*
	*/
	function resetHits($redirect, $id)
	{
		global $mainframe;

		// Initialize variables
		$db	= & JFactory::getDBO();

		// Instantiate and load an article table
		$row = & JTable::getInstance('content');
		$row->Load($id);
		$row->hits = 0;
		$row->store();
		$row->checkin();

		$msg = JText::_('SUCCESS.RESET_DOWNLOAD_COUNT');
		$mainframe->redirect('index.php?option=com_content&sectionid='.$redirect.'&task=edit&id='.$id, $msg);
	}
   /**
	* Function to reset Hit count of an article
	*
	*/
	function resetStats($file)
	{
		$query = "UPDATE #__rokdownloads set downloads = 0 where id = " . $file->id; 
		$this->_db->setQuery( $query );
	    if (!$this->_db->query())
	    {
	    	$this->setError($this->_db->getErrorMsg());
	    	return false;
	    }
        return true;
	}	
}	
