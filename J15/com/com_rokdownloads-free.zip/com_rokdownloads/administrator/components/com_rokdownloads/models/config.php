<?php
/**
 * @version $Id: config.php 18489 2010-02-03 00:44:48Z btowles $
 * @package RocketTheme
 * @subpackage	RokDownloads
 * @copyright Copyright (C) 2008 RocketWerx. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport( 'joomla.application.component.model' );

/**
 * Rokdownloads Component Model Config
 *
 * @package		RocketTheme
 * @subpackage	RokDownloads
 *
 * @since 1.5
 */
class RokdownloadsModelConfig extends JModel
{
	/**
	 * Get the params for the configuration variables
	 */
	function &getParams($component="com_rokdownloads")
	{
		static $instance;

		if ($instance == null)
		{
			$table =& JTable::getInstance('component');
			$table->loadByOption( $component );

			// work out file path
			$option	= preg_replace( '#\W#', '', $table->option );
			$path	= JPATH_ADMINISTRATOR.DS.'components'.DS.$option.DS.'admin_config.xml';

			if (file_exists( $path )) {
				$instance = new JParameter( $table->params, $path );
			} else {
				$instance = new JParameter( $table->params );
			}
		}
		return $instance;
	}
}
?>
