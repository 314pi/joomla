/**
 CREATE TABLE IF NOT EXISTS `#__rokdownloads` 
( 
   `id` int(10) NOT NULL auto_increment, 
   `name` text NOT NULL, 
   `displayname` text NOT NULL, 
   `path` text NOT NULL, 
   `folder` tinyint(4) NOT NULL default '0', 
   `filesize` bigint(19) NOT NULL default '0', 
   `introtext` mediumtext, 
   `fulltext` mediumtext, 
   `thumbnail` varchar(255) default NULL, 
   `access` int(10) NOT NULL default '0', 
   `params` text, 
   `downloads` int(10) NOT NULL default '0', 
   `published` tinyint(4) NOT NULL default '0', 
   `lft` int(10) unsigned NOT NULL, 
   `rgt` int(10) unsigned NOT NULL, 
   `created_time` datetime NOT NULL default '0000-00-00 00:00:00', 
   `created_by` int(10) NOT NULL default '0', 
   `modified_time` datetime NOT NULL default '0000-00-00 00:00:00', 
   `modified_by` int(10) NOT NULL default '0', 
   `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00', 
   `checked_out` int(10) NOT NULL default '0', 
   `metadata` text,
   `metadesc` text,
   `metakey` text,
   PRIMARY KEY (`id`), 
   KEY `filesize` (`filesize`), 
   KEY `downloads` (`downloads`), 
   KEY `published` (`published`), 
   KEY `access` (`access`), 
   KEY `created_time` (`created_time`), 
   KEY `checked_out_time` (`checked_out_time`), 
   KEY `modified_time` (`modified_time`), 
   KEY `IX_rokdownloads_lft` (`lft`), 
   KEY `IX_rokdownloads_rgt` (`rgt`), 
   KEY `IX_rokdownloads_tree` (`lft`,`rgt`) 
) 
ENGINE=MyISAM CHARACTER SET utf8;

CREATE TABLE IF NOT EXISTS `#__rokversions` 
( 
   `product` varchar(255) NOT NULL,
   `version` varchar(255) NOT NULL
) 
ENGINE=MyISAM CHARACTER SET utf8;
*/