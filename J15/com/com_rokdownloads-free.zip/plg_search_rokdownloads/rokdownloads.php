<?php
/**
 * @version		$Id$
 * @package RocketTheme
 * @subpackage	RokDownloads
 * @copyright Copyright (C) 2008 RocketWerx. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 * 
 * Original Written by Ivo Apostolov
 * Original Copyright and licence (C) 2008 Protos Extensions. All rights reserved. GNU/GPL
 */



// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
require_once (JPATH_SITE.DS.'components'.DS.'com_rokdownloads'.DS.'models'.DS.'downloadItem.php');

$mainframe->registerEvent( 'onSearch', 'plgSearchRokdownloads' );
$mainframe->registerEvent( 'onSearchAreas', 'plgSearchRokdownloadsAreas' );
JPlugin::loadLanguage( 'plg_search_rokdownloadsfolder' );

function &plgSearchRokdownloadsAreas()
{
	static $areas = array(
		'downloads' => 'Downloads'
	);
	return $areas;
}



/**
* Rokdownloadsfolder Search method
*
* The sql must return the following fields that are used in a common display
* routine: href, title, section, created, text, browsernav
* @param string Target search string
* @param string mathcing option, exact|any|all
* @param string ordering option, newest|oldest|popular|alpha|category
* @param mixed An array if the search it to be restricted to areas, null if search all
 */
function plgSearchRokdownloads( $text, $phrase='', $ordering='', $areas=null )
{
	$db		=& JFactory::getDBO();
	$user	=& JFactory::getUser();
	$aid		= (int) $user->get('aid', 0);
	$menu 		= &JSite::getMenu();
	
	if (is_array( $areas )) {
		if (!array_intersect( $areas, array_keys( plgSearchRokdownloadsAreas() ) )) {
			return array();
		}
	}


	// load plugin params info
 	$plugin =& JPluginHelper::getPlugin('search', 'rokdownloads');
 	$pluginParams = new JParameter( $plugin->params );
 	$available_ids=array();
 	$filemenu_files = array();
	$foldermenu_files = array();
	$menu_info = array();
 	
 	//
	//Get the File Menu Files which are available to list
	//
	$FileMenuItems = array();
	$fili = $menu->getItems('link', 'index.php?option=com_rokdownloads&view=file');
	if (is_array($fili) && count($fili) > 0) {
		$FileMenuItems = $fili;
	} else if ($fili != null)  {
		$FileMenuItems[] = $fili;
	}
	if (count($FileMenuItems) > 0) {
		foreach ($FileMenuItems as $filemenuitem) {
			if ($filemenuitem->access <= $aid) {
				$item_params = new JParameter($filemenuitem->params);
				$filemenu_files[$filemenuitem->id] = $item_params->get('filetodisplay');
				$menu_info[$filemenuitem->id] = $filemenuitem->name;
			}
		}	
	}
	//Merge File menu files into all posible files
	$available_ids = array_merge($available_ids, $filemenu_files);
		

	// 
	// Get the Folder Menu Folders which are available to search
	//
	$FolderMenuItems = array();
	$foli = $menu->getItems('link', 'index.php?option=com_rokdownloads&view=folder');
	if (is_array($foli) && count($foli) > 0) {
		$FolderMenuItems = $foli;
	}else if ($foli != null) {
		$FolderMenuItems[] = $foli;
	}
	
	// Get the top level folders from folder menus that are accessable
	$folders_per_menu = array();
	$top_level_folders=array();
	if (count($FolderMenuItems) > 0) {
		foreach ($FolderMenuItems as $foldermenuitem) {
			if ($foldermenuitem->access <= $aid && $foldermenuitem->published == 1) {
				$menu_info[$foldermenuitem->id] = $foldermenuitem->name;
				$item_params = new JParameter($foldermenuitem->params);
				$top_level_folders[$foldermenuitem->id] = $item_params->get('top_level_folder');
				$available_menu_folders = array();
				$wanted_folders_query = "SELECT snode.id " .
					" FROM #__rokdownloads AS snode, #__rokdownloads AS sparent " .
					" WHERE snode.lft BETWEEN sparent.lft AND sparent.rgt " .
					" AND sparent.id = " . $item_params->get('top_level_folder') .
					" AND snode.folder = 1 " .
					" AND snode.access <= ". $aid .
					" AND snode.published = 1 " .
					" GROUP BY snode.id " .
					" ORDER BY snode.lft ";
		
				$db->setQuery($wanted_folders_query);
				$available_menu_folders = $db->loadResultArray(0);
				if(count($available_menu_folders)>0){
					$folders_per_menu[$foldermenuitem->id] = $available_menu_folders;
					$available_ids = array_merge($available_ids, $available_menu_folders);
				}
			}
		}
	}
	
	// Get accessable files under the top level folders
	if (count($top_level_folders) > 0) {
		foreach ($top_level_folders as $folder_menu_id => $top_folder_id) {
			$all_folder_files = array();
			$wanted_files_query = "SELECT " .
									"node.id " .
									"from #__rokdownloads as node, " .
									"( " .
									"    SELECT snode.id as id, snode.lft as lft, snode.rgt as rgt " .
									"    FROM #__rokdownloads AS snode, #__rokdownloads AS sparent " .
									"    WHERE snode.lft BETWEEN sparent.lft AND sparent.rgt " .
									"    AND sparent.id = " . $top_folder_id .
									"    AND snode.folder = 1 " .
									"    AND snode.access <= " . $aid .
									"    GROUP BY snode.id " .
									"    ORDER BY snode.lft " .
									") " .
									" as wantedfolders " .
									" WHERE node.lft between wantedfolders.lft and wantedfolders.rgt " .
									" AND node.folder=0 " .
									" AND node.published = 1 " .
									" GROUP BY node.id";
			$db->setQuery($wanted_files_query);
			$all_folder_files = $db->loadResultArray(0);
			if (is_array($all_folder_files) && count($all_folder_files) > 0) {
				$unwanted_files_query ="SELECT " .
										"node.id " .
										"from #__rokdownloads as node, " .
										"( " .
										"SELECT snode.id as id, snode.lft as lft, snode.rgt as rgt " .
										"    FROM #__rokdownloads AS snode, #__rokdownloads AS sparent " .
										"    WHERE snode.lft BETWEEN sparent.lft AND sparent.rgt " .
										"    AND sparent.id = " . $top_folder_id .
										"    AND snode.folder = 1 " .
										"    AND snode.access > " . $aid .
										"    GROUP BY snode.id " .
										"    ORDER BY snode.lft " .
										") " .
										"as unwantedfolders " .
										"WHERE node.lft between unwantedfolders.lft and unwantedfolders.rgt " .
										"AND node.folder=0 " .
										"AND node.published = 1 " .
										"GROUP BY node.id";
				$db->setQuery($unwanted_files_query);
				$unwanted_files = $db->loadResultArray(0);
				if (count($unwanted_files) > 0){
					$wanted_files = $all_folder_files;
					$all_folder_files = array_diff($wanted_files, $unwanted_files);
				}
			}
			if (count($all_folder_files) > 0) {
				$foldermenu_files[$folder_menu_id] = $all_folder_files;
			}
		}
	}
	
	//Merge Folder menu files into all posible files
	foreach ($foldermenu_files as $folderfiles) 
	{
		$available_ids = array_merge($available_ids, $folderfiles);
	}
		
	// clean up folder ids
	$available_ids = array_unique($available_ids);
	
	if (empty($available_ids)) {
		return array();
	}
	
	// get the folder where statement
	$available_ids_where = "(". implode(",",$available_ids).")";
	
	$limit = $pluginParams->def( 'search_limit', 50 );

	$text = trim( $text );
	if ($text == '') {
		return array();
	}
	$section 	= JText::_( 'Downloads' );

	$wheres 	= array();
	switch ($phrase)
	{
		case 'exact':
			$text		= $db->Quote( '%'.$db->getEscaped( $text, true ).'%', false );
			$wheres2 	= array();
			$wheres2[] 	= 'LOWER(a.name) LIKE '.$text;
			$wheres2[] 	= 'LOWER(a.displayname) LIKE '.$text;
			$wheres2[] 	= 'LOWER(a.introtext) LIKE '.$text;
			$wheres2[] 	= 'LOWER(a.fulltext) LIKE '.$text;
			$where 		= '(' . implode( ') OR (', $wheres2 ) . ')';
			break;

		case 'all':
		case 'any':
		default:
			$words 	= explode( ' ', $text );
			$wheres = array();
			foreach ($words as $word)
			{
				$word		= $db->Quote( '%'.$db->getEscaped( $word, true ).'%', false );
				$wheres2 	= array();
				$wheres2[] 	= 'LOWER(a.name) LIKE '.$word;
				$wheres2[] 	= 'LOWER(a.displayname) LIKE '.$word;
				$wheres2[] 	= 'LOWER(a.introtext) LIKE '.$word;
				$wheres2[] 	= 'LOWER(a.fulltext) LIKE '.$word;
				$wheres[] 	= implode( ' OR ', $wheres2 );
			}
			$where 	= '(' . implode( ($phrase == 'all' ? ') AND (' : ') OR ('), $wheres ) . ')';
			break;
	}

	switch ( $ordering )
	{
		case 'oldest':
			$order = 'a.created_time ASC';
			break;

		case 'popular':
			$order = 'a.downloads DESC';
			break;

		case 'alpha':
			$order = 'a.displayname ASC';
			break;

		case 'newest':
		default:
			$order = 'a.created_time DESC';
	}

	$query = 'SELECT a.displayname AS title, a.introtext AS text, a.created_time AS created,'
	. ' a.downloads, a.published, a.folder, a.name, a.fulltext, a.id, "2" AS browsernav'
	. ' FROM #__rokdownloads AS a'
	. ' WHERE ('. $where .')'
	. ' AND a.id in ' . $available_ids_where
	. ' AND a.published = 1'
	. ' ORDER BY '. $order;
	
	$db->setQuery( $query, 0, $limit );
	$rows = $db->loadObjectList();
	
	reset($rows);
	while (list($key, $row) = each($rows)) {
		$rows[$key]->section = $db->Quote($section);
		$menu_id=0;
		$url_ender = "";
		$view_type = "file";
		
		// See if its a top level folder menu
		if (in_array($row->id, $top_level_folders)) {		
			reset($top_level_folders);
			while (list($ikey, $fid) = each($top_level_folders)) {
				if ($fid == $row->id) {
					$menu_id = $ikey;
					$url_ender .= $menu_id;
					$view_type = "folder";
					break;
				}
			}
		}
		// See if its a top level file menu
		else if (in_array($row->id, $filemenu_files)) {		
			reset($filemenu_files);
			while (list($tlfkey, $fid) = each($filemenu_files)) {
				if ($fid == $row->id) {
					$menu_id = $tlfkey;
					$url_ender .= $tlfkey;
					$view_type = "file";
					break;
				}
			}
		}
		else 
		{
			//Looks through all of the sub folders in the menus
			$found_folder = false;
			reset($folders_per_menu);
			while (list($sfkey, $farray) = each($folders_per_menu)) {
				if (in_array($row->id, $farray)) {
					$menu_id = $sfkey;
					$url_ender .= $menu_id."&id=".RokdownloadsModelDownloadItem::getSlug($row) ;
					$view_type = "folder";
					$found_folder = true;
					break;
				}
			}
			//Look through all of the sub files of the menu if its not a folder
			if (!$found_folder) {
				reset($foldermenu_files);
				while (list($fikey, $farray) = each($foldermenu_files)) {
					if (in_array($row->id, $farray)) {
						$menu_id = $fikey;
						$url_ender .= $menu_id."&id=".RokdownloadsModelDownloadItem::getSlug($row) ;
						$view_type = "file";
						break;
					}
				}
			}
		}
		$rows[$key]->section = $menu_info[$menu_id];
		$rows[$key]->href = JRoute::_('index.php?option=com_rokdownloads&view='.$view_type.'&Itemid=' . $url_ender);
	}
	return $rows;
}