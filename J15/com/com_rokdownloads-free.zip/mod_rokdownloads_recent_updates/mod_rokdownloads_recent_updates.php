<?php
/**
 * @version		$Id$
 * @package RocketTheme
 * @subpackage	RokDownloads
 * @copyright Copyright (C) 2008 RocketWerx. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 * 
 * Original Written by Ivo Apostolov
 * Original Copyright and licence (C) 2008 Protos Extensions. All rights reserved. GNU/GPL
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

// Include the syndicate functions only once
require_once (dirname(__FILE__).DS.'helper.php'); 

// add module css  
global $mainframe; 
$cssfile = "rokdownloads-modules.css";  

// If the template has a css override use it   
$csspath = "";   
$tPath = 'templates/'.$mainframe->getTemplate().'/html/com_rokdownloads/'. $cssfile;    
if (file_exists(JPATH_BASE.DS.$tPath)) {     
	$csspath = JURI::base().'/'.$tPath;
} else {
	$csspath = JURI::base().'/components/com_rokdownloads/css/'.$cssfile;
}

$user =& JFactory::getUser();
$aid  = (int) $user->get('aid', 0);
switch ($aid) {
    case 0:
        $level = "public";
        break;
    case 1:
        $level = "registered";
        break;
    case 2:
        $level = "special";
        break;
}

$cache =& JFactory::getCache('mod_rokdownloads_recent_updates-'.$level);
$list = $cache->call(array('modRecentlyupdatedRokdownloadsHelper', 'getList'), $params);
require(JModuleHelper::getLayoutPath('mod_rokdownloads_recent_updates'));