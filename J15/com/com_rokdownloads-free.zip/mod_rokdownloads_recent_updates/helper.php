<?php
/**
 * @version		$Id$
 * @package RocketTheme
 * @subpackage	RokDownloads
 * @copyright Copyright (C) 2008 RocketWerx. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 * 
 * Original Written by Ivo Apostolov
 * Original Copyright and licence (C) 2008 Protos Extensions. All rights reserved. GNU/GPL
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

require_once (JPATH_SITE.DS.'components'.DS.'com_rokdownloads'.DS.'models'.DS.'downloadItem.php');

// Build the helper class
class modRecentlyupdatedRokdownloadsHelper
{
	function getList(&$params)
	{
		global $mainframe;
		$lists	= array();
		// connect to the database via the Joomla! method
		$db			= &JFactory::getDBO();
		// Limit of the files to display
		$count		= (int) $params->get('count', 5);
		$access_restricted_downloads = (int) $params->get('access_restricted_downloads', 1);
		// Get the correct Itemid
		$menu 		= &JSite::getMenu();
		
		$user		=& JFactory::getUser();
		$aid		= (int) $user->get('aid', 0);
		
		$possible_files = array();
		$filemenu_files = array();
		$foldermenu_files = array();
		
		
		//
		//Get the File Menu Files which are available to list
		//
		$FileMenuItems = array();
		$fili = $menu->getItems('link', 'index.php?option=com_rokdownloads&view=file');
		if (is_array($fili) && count($fili) > 0) {
			$FileMenuItems = $fili;
		} else if ($fili != null)  {
			$FileMenuItems[] = $fili;
		}
		if (count($FileMenuItems) > 0) {
			foreach ($FileMenuItems as $filemenuitem) {
				if ($filemenuitem->access <= $aid) {
					$item_params = new JParameter($filemenuitem->params);
					$filemenu_files[$filemenuitem->id] = $item_params->get('filetodisplay');
				}
			}	
		}
		//Merge File menu files into all posible files
		$possible_files = array_merge($possible_files, $filemenu_files);
		
		// 
		// Get the Folder Menu Files which are available to list
		//
		$FolderMenuItems = array();
		$foli = $menu->getItems('link', 'index.php?option=com_rokdownloads&view=folder');
		if (is_array($foli) && count($foli) > 0) {
			$FolderMenuItems = $foli;
		}else if ($foli != null) {
			$FolderMenuItems[] = $foli;
		}
		
		// Get the top level folders from folder menus that are accessable
		$top_level_folders = array();
		if (count($FolderMenuItems) > 0) {
			foreach ($FolderMenuItems as $foldermenuitem) {
				if ($foldermenuitem->access <= $aid  && $foldermenuitem->published == 1) {
					$item_params = new JParameter($foldermenuitem->params);
					$top_level_folders[$foldermenuitem->id] = $item_params->get('top_level_folder');	
				}
			}
		}
		
		// Get accessable files under the top level folders
		if (count($top_level_folders) > 0) {
			foreach ($top_level_folders as $folder_menu_id => $top_folder_id) {
				$all_folder_files = array();
				$wanted_files_query = "SELECT " .
										"node.id " .
										"from #__rokdownloads as node, " .
										"( " .
										"    SELECT snode.id as id, snode.lft as lft, snode.rgt as rgt " .
										"    FROM #__rokdownloads AS snode, #__rokdownloads AS sparent " .
										"    WHERE snode.lft BETWEEN sparent.lft AND sparent.rgt " .
										"    AND sparent.id = " . $top_folder_id .
										"    AND snode.folder = 1 " .
										"    AND snode.access <= " . $aid .
										"    GROUP BY snode.id " .
										"    ORDER BY snode.lft " .
										") " .
										"as wantedfolders " .
										"WHERE node.lft between wantedfolders.lft and wantedfolders.rgt " .
										"AND node.folder=0 " .
										"AND node.published = 1 " .
										(($access_restricted_downloads == 0) ? "AND node.access <= " . $aid :"") .
										" GROUP BY node.id";
				$db->setQuery($wanted_files_query);
				$all_folder_files = $db->loadResultArray(0);
				if (is_array($all_folder_files) && count($all_folder_files) > 0) {
					$unwanted_files_query ="SELECT " .
											"node.id " .
											"from #__rokdownloads as node, " .
											"( " .
											"SELECT snode.id as id, snode.lft as lft, snode.rgt as rgt " .
											"    FROM #__rokdownloads AS snode, #__rokdownloads AS sparent " .
											"    WHERE snode.lft BETWEEN sparent.lft AND sparent.rgt " .
											"    AND sparent.id = " . $top_folder_id .
											"    AND snode.folder = 1 " .
											"    AND snode.access > " . $aid .
											"    GROUP BY snode.id " .
											"    ORDER BY snode.lft " .
											") " .
											"as unwantedfolders " .
											"WHERE node.lft between unwantedfolders.lft and unwantedfolders.rgt " .
											"AND node.folder=0 " .
											"AND node.published = 1 " .
											"GROUP BY node.id";
					$db->setQuery($unwanted_files_query);
					$unwanted_files = $db->loadResultArray(0);
					if (count($unwanted_files) > 0){
						$wanted_files = $all_folder_files;
						$all_folder_files = array_diff($wanted_files, $unwanted_files);
					}
				}
				if (count($all_folder_files) > 0) {
					$foldermenu_files[$folder_menu_id] = $all_folder_files;
				}
			}
		}
		
		//Merge Folder menu files into all posible files
		foreach ($foldermenu_files as $folderfiles) 
		{
			$possible_files = array_merge($possible_files, $folderfiles);
		}
		// weed out any dupes between folder menu files and file menu files
		$possible_files = array_unique($possible_files);

		// Select files only
		$query = 'SELECT * FROM #__rokdownloads WHERE id in (';
		$i = 0;
		foreach (array_unique($possible_files) as $posfile)
		{
			if ($i)
			{
				$query .= ",";	
			}
			$query .= $posfile;
			$i++;
		}
		$query .= ') AND modified_time!=created_time ORDER by modified_time DESC';
	
		$db->setQuery($query, 0, $count);
		$rows = $db->loadObjectList();
		$i		= 0;
	
		if (count($rows) > 0) {
			foreach ( $rows as $row )
			{
				$menu_id = 0;
				if (in_array($row->id, $filemenu_files)) {		
					foreach ($filemenu_files as $key => $fid) {
						if ($fid == $row->id) {
							$menu_id = $key;
							break;
						}
					}
				}
				else 
				{
					foreach($foldermenu_files as $key => $farray) {
						if (in_array($row->id, $farray)) {
							$menu_id = $key;
							break;
						}
					}
					
				}
				$lists[$i]->link = JRoute::_('index.php?option=com_rokdownloads&view=file&Itemid=' . $menu_id . '&id='. RokdownloadsModelDownloadItem::getSlug($row));
				$lists[$i]->modified_time = JHTML::_('date',  $row->modified_time,  JText::_('DATE_FORMAT_MODULE') );
				// Get the displayname
				$lists[$i]->text = htmlspecialchars( $row->displayname );
				$i++;
			}
		}
		return $lists;
	}
}