<?php
/**
 * @version	$Id$
 * @package RokDownloads
 * @copyright Copyright (C) 2008 RocketWerx. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();
?>

1. Copyright and disclaimer
---------------------------


2. Changelog
------------
This is a non-exhaustive (but still near complete) changelog for
the Rocketwerx RokDownloads, including alpha, beta and release
candidate versions.

Legend:

* -> Security Fix
# -> Bug Fix
+ -> Addition
^ -> Change
- -> Removed
! -> Note

=======

-------------------- 1.1 Release [10-Jan-2011] ---------------------

10-Jan-2011 Djamil Legato
# Fixed JS to work with new ES5 specifications adopted by Firefox and Chrome

-------------------- 1.0 Release [15-Mar-2010] ---------------------

15-Mar-2010 Brian Towles
* Fix for controller url exploit

01-Mar-2010 Brian Towles
# Fixed folder/file rename not working. 

-------------------- 1.0b9 Beta Release [28-Feb-2010] ---------------------
# Fixed corrupted uploader jar.

-------------------- 1.0b8 Beta Release [02-Feb-2010] ---------------------
02-Feb-2010 Brian Towles
# Fix for moving of folders and files
# Fixed RokDownloads button on front end
+ Added size adjustment when saving a file
^ Moved to new install system

19-October-2009 Brian Towles
# Fixed move of file and folder bug from within the edit form.

-------------------- 1.0b7 Beta Release [10-October-2009] ---------------------
10-October-2009 Brian Towles
# Fixed router for downloads from file type menu items under SEF
^ Changed all internal pathing to be / based instead of local platform.  These changes should fix the file already exisits error on bad paths and duplicate file entry creation.
+ Added conversion to unified path on install
# Fixed inconsistent line endings on directory paths 

-------------------- 1.0b6 Beta Release [06-October-2009] ---------------------
05-October-2009 Brian Towles
# Fixed download lockup on bad permissions files
# Fixed Missing path directory separators that caused duplicate files
^ Changed router for better SEO handling
# Fixed uninstall warnings

-------------------- 1.0b5 Beta Release [21-September-2009] ---------------------
21-September-2009 Brian Towles
# Fixed SEF issues with File view
# Fixed File view options not working.
 
-------------------- 1.0b4 Beta Release [05-August-2009] ---------------------

05-August-2009 Brian Towles
# Fixed content plugin to support selecting text in tinyMCE, JCE, RokPad, and None.
# Fixed content plugin for the link into editors.
# Fixed display of Downloads button when "Show Download Button on No Access" is set to Hide
# Cleaned up Search plugin.

-------------------- 1.0b3 Beta Release [18-June-2009] ---------------------
18-June-2009 Brian Towles
+ Added Sorting on menu items of subfolders and files

15-June-2009 Brian Towles
# Fixed Plugin uninstall issue
+ Added message for no menu items to content plugin
# Fixed trashed menu items showing up in content plugin

-------------------- 1.0b2 Beta Release [22-April-2009] ---------------------
22-April-2009 Brian Towles
# Minor bug fix to editor button

-------------------- 1.0b1 Beta Release [25-MARCH-2009] ---------------------
25-March-2009 Brian Towles
# Removed extraneous xdebug statement

-------------------- 0.98a Alpha Release [24-MARCH-2009] ---------------------
24-March-2009 Brian Towles
+ Added RokDownloads Link Content Plugin and Button Plugin  
# Minor language fix
# Fixed Plugin support and event support for Folder display.

26-Feburary-2009 Brian Towles
# Cleaned up Display name output for Aliases and Slugs
# Removed stray pass by reference in install

-------------------- 0.97a Alpha Release [12-February-2009] ---------------------
25-January-2009 Brian Towles
^ Changed format of SEF urls to be more path based
^ Changes some of the look and feel of the Manager admin to help with user understanding of state of items
+ Added post_max_size and upload_max_size tp php config display to help diagnose problems for people.
+ Added caching to SEF generation
+ Added cache clearing on admin changes
+ Added alias field to display items to support some content plugins
# Fixed partial render of a page after download.
# Fixed search plugin bug with aliases and slugs.
+ Added support for handling incoming old style SEF
^ Moved to Alternate PHP control structure syntax for html templates
# Fixed partial page render after download
# Fixed SEF issue for lower level downloads

26-December-2008 Brian Towles
+ Added caching to Modules

-------------------- 0.96a Alpha Release [20-December-2008] ---------------------
20-December-2008
# Fixed file count bug on front end

17-December-2008 Brian Towles
+ Added check to make sure downloads root folder exists.

16-December-2008 Brian Towles
+ Added Java Based Uploader
# Fixed parent folder for edit of file/folder
# Added table locking to file edits to hopefully stop duplicate files on edit

12-December-2008 Brian Towles
# Fixed performance on front end for larger directory lists.

08-December-2008 Brian Towles
^ Moved custom params to administrator/components/com_rokdownloads/custom_params.xml
^ Moved default thumbs and thumbs folder to under images/rokdownload_thumbs
+ Added RSS/ATOM feed capability to folders menu items.
+ Added rokversions table install to track product versions
+ Added metadata support and upgraded the rokdownloads table to support it.
# Added check on set_time_limit to remove warning for safe mode runs
+ Added manual changing of created date/modified date/downloads count

-------------------- 0.95a Alpha Release [20-August-2008] ---------------------

20-August-2008 Brian Towles
# Fixed backwards create table sql compatibility for mysql4

18-August-2008 Brian Towles
+ Added Module and Plugin translations
^ Added correct section to search plugin results
^ Changed Date format for modules and component
# Fixed content plugin access to folder/file text
^ Moved to a text only on folder and file detail view (No split intro and full)
^ Added seperate control of File list view fields versus file detail view fields on the Folder view
+ Added support for non flash uploader

17-August-2008 Brian Towles
# fixed thumbnail icons for non root based installations
^ Changed Icons for Folder publish state
+ Added settable default folder and file icons.
+ Added plugins to install and uninstall in batch with component
+ Added created and modified dates/times to modules

16-August-2008 Brian Towles
^ Changed install to more programatic method.
+ Added modules to install as batch with component
+ Added uninstall for modules as batch with component
# Changed download flushing to hopefully fix memory error on large downloads


08-July-2008 Brian Towles
# Fixed SEF usage with joomla .htaccess mod_rewrite

07-July-2008 Brian Towles
# Fixed usage of "jos" prefixed tables in queries.

02-July-2008 Brian Towles
# Fixed SEF links to remove spaces
^ Changed the was File and Folder access levels work. File access levels now mean Access To Download While Folder access level means Access to Display


-------------------- 0.94a Alpha Release [1-July-2008] ---------------------

30-June-2008 Brian Towles
# Fixed "Fatal error: Only variables can be passed by reference in" errors
# Fixed spelling issues
# Fixed ignoring of index.html index.htm .htaccess files
+ Added Apply button to folder and edit form.
# Fixed File and Folder labelling in edit form.
# Fixed Download Button language entries.
# Removed Spacers from Parameter rendering on front end
# Fixed SEF routing issues and naming.
- Removed unused css field form menu options

-------------------- 0.93a Alpha Release [14-May-2008] ---------------------

14-May-2008 Brian Towles
+ Added legend to Admin view.

13-May-2008 Brian Towles
# Fixed apostrophe in folder name causing bad tree issue

13-May-2008 Andy Miller
+ Added folder state cookie

12-May-2008 Andy Miller
^ Changed RokDownloads icons
# Fixed some missing lang strings
# Fixed thumbs path issue in manager

12-May-2008 Brian Towles
# Fixed binary output bug when downloading zips, etc...
^ Cleaned up php files to not have closed brackets on no output files.
- Removed non used templates directory

10-May-2008 Brian Towles
# Fixed select then edit on admin table

10-May-2008 Andy Miller
+ Added ability to control file title action

09-May-2008 Andy Miller
# Fixed some issues with SEF and custom routes
# Fixed issue with thumbnail image paths and SEF
# Fixed issue with detail view not showing full text
+ Added mediamanager css to the fancyuploader modal

-------------------- 0.92a Alpha Release [08-May-2008] ---------------------

07-May-2008 Andy Miller
# Fixed bug with long filenames breaking mootable in the admin
# Fixed issue and layout with rokdownloads breadcrumbs
+ Added ability to turn off Folder title display
^ Changed behavior of breadcrumbs to show top level folder

06-May-2008 Brian Towles
+ Added breadcrumbs object to folders view to allow for directory hierarchy listing
^ Refactored front end models for better object inheritance

05-May-2008 Brian Towles
+ Added parent object to folders and files in folder view to allow for better navigation
+ Added separate option to toggle sub folder thumbnails
# Spelling fixes in language files

04-May-2008 Brian Towles
# Fixed tree display bug when Directory is missing doesn't refresh items below it in the tree.
# Fixed bug that showed blank entry on .DS_Store file   added it to ignored files.
# Fixed folder rename munging sub folder and file paths in database
# Fixed big handling no extension files for thumbnails


-------------------- 0.91a Alpha Release [30-April-2008] ---------------------

30-Apr-2008 Brian Towles
# Removed PHP Shortcut Tags
# Fixed tree sub folder duplication issue
# Fix call by ref error in model/rokdownloads.php
# Fix bug in manifest and build which caused Joomla to think its an older version
 

------------- Initial Changelog Creation ---------------