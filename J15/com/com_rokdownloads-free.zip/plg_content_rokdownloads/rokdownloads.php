<?php

// Check to ensure this file is included in Joomla!
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin' );
jimport( 'joomla.filesystem.file' );

/**
 * RokDownload Link Content Plugin
 *
 * @package		Joomla
 * @subpackage	Content
 * @since 		1.5
 */
class plgContentRokDownloads extends JPlugin
{
	var $_debug;
	var $_library = array();
	var $_initialized = false;
	var $_instanceId = 0;
	
	function plgContentRokDownloads(& $subject, $config) {
		parent :: __construct($subject, $config);
		$this->_instanceId = rand(1000, 9999);
		
		$this->_debug = JRequest::getVar('debug_plg_content_rokdownloads') == true ? true : false;
		//$this->_debug = true;
    }
    
    function _PHP4() {
  		if (version_compare( phpversion(), '5.0' ) < 0) {
  			if (!$this->_initialized) {
  			  //Something is wrong with PHP4... let's repeat the work...	
  				$this->_instanceId = rand(1000, 9999);
  				$this->_initialize();
  			}
  			return true;
  		} else {
  		  return false;
  		}  		
    }
    
    function _initialize() {
        
		if ($this->_initialized) {
			JError::raiseWarning( '1' , 'plg_content_rokdownloads instanceId=' . $this->_instanceId . ' was initialized already');
			return true;
		}
		
		$inifile = JPATH_ROOT.DS.'plugins'.DS.'content'.DS.'rokdownloads'.DS.'rokdownloads.ini';
		
		if (!JFile::exists($inifile)) {
			JError::raiseWarning( '1' , 'Cannot find  macro file : ' . $inifile);
			return true;
		}
		
		$this->_library = $this->_readIniFile($inifile, $this->_library);
        
    }
    
    /**
	 * Edit the content to render the link for the rokdownload
	 *
	 * @param 	object		The article object.  Note $article->text is also available
	 * @param 	object		The article params
	 * @param 	int			The 'page' number
	 * @return	string
	 */
	function onBeforeDisplayContent( &$article, &$params, $limitstart )
	{
		$this->_initialize();

		//simple performance check to determine whether bot should process further
	    if ( strpos( $article->text, '[rokdownload' ) === false) {
			return '';
		}
		
		$menu = &JSite::getMenu();
		$cache = & JFactory :: getCache('plg_content_rokdownloads');
		$downloads = $cache->call(array('plgContentRokDownloads','_getDownloads'));


		if ($this->_debug) var_dump ($this->_library);
		

	    foreach ($this->_library  as $key => $val) {
	        $search         = array();
            $replace        = array();
	        
	        $key            = str_replace("[","\[",$key);
	        $key            = str_replace("]","\]",$key);
	        $tokens         = array();
	        $key_regexp = '%'.preg_replace('%\{([a-zA-Z0-9_]+)\}%', '(?P<$1>.*?)',$key).'%s';
	        if ($this->_debug) var_dump ($key_regexp);
	        preg_match_all($key_regexp,$article->text,$results);
	        if (!empty($results[0])) {
	            if ($this->_debug) var_dump ($results);
    	        $search = array_merge($search, $results[0]);
    	        foreach ($results as $k => $v) {
    	            if (!is_numeric($k)) {
    	                $tokens[] = $k;
    	            }
    	        }

                for($i=0;$i< count($results[0]);$i++) {
					// get the menu info
					if (!$found_menuitem = $menu->getItem($results['menuitem'][$i])) {
						JError::raiseWarning( '1' , 'Unable to fine menu item ' .$results['menuitem'][$i]. 'in rokdownload link');
						continue;
					}	
					
					if (!array_key_exists($results['downloaditem'][$i], $downloads)) {
						JError::raiseWarning( '1' , 'Unable to fine download item ' . $results['downloaditem'][$i]. 'in rokdownload link');
						continue;
					}
					$found_downloaditem = $downloads[$results['downloaditem'][$i]];
					$found_direct_download = ($results['direct_download'][$i]== "true")? true: false;
			 
					$view = ($found_downloaditem->folder == true)? "folder" : "file";
					$task = (!$found_downloaditem->folder && $found_direct_download)? "&task=download":"";
					$uri =& JURI::getInstance();
					$results['url'][$i] = $uri->toString( array('scheme', 'host', 'port')).JRoute::_("index.php?option=com_rokdownloads&view=" . $view . "&Itemid=". $found_menuitem->id . $task . "&id=" . $found_downloaditem->id);
	            	$tokens[] = 'url';
	            	
	                $tmpval = $val;
	                foreach ($tokens as $token) {
	                    $tmpval = str_replace("{".$token."}",$results[$token][$i],$tmpval);
	                }
	                $replace[] = $tmpval;
                }
	        }
	        $article->text = str_replace($search,$replace,$article->text);
	    }
		
		return '';
	}
	
	function _getDownloads() {
		$downloads = array ();
		$db = & JFactory :: getDBO();
		$query = "SELECT node.id as id, node.name as name, node.displayname as displayname, node.path as path, node.folder as folder " .
		"FROM #__rokdownloads AS node";
		$db->setQuery($query);
		$downloads = $db->loadObjectList("id");
		foreach ( $downloads as $id => $download ) {
			$download->alias = 	plgContentRokDownloads::_getDownloadsAlias($download->displayname);
       		$download->slug = $download->id + ":" + $download->alias;
		}
		return $downloads;
	}

	function _getDownloadsAlias($displayname) {
		// Strip extension is there is one
		$name = $displayname;
		$ext = strrchr($name, '.');
		if ($ext !== false) {
			$name = substr($name, 0, -strlen($ext));
		}
		// lower case the name
		$name = JString :: strtolower($name);
		// Change spaces and periods to  dashes
		$name = JString :: str_ireplace(" ", "-", $name);
		$name = JString :: str_ireplace(".", "-", $name);
		return JFilterOutput::stringURLSafe($name);
	}
	
	function _readIniFile($path, $library) {
        jimport( 'joomla.filesystem.file' );
        $content = JFile::read($path);
        $data = explode("\n",$content);

		foreach ($data as $line) {
		    //skip comments
		    if (strpos($line,"#")!==0 and trim($line)!="" ) {
		       $div = strpos($line,"]=");
		       $library[substr($line,0,$div+1)] = substr($line,$div+2);
		    }
		}
		return $library;
    }
}