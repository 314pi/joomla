<?php 
// no direct access
defined('_JEXEC') or die('Restricted access'); ?>

<div class="rd-module<?php echo $params->get('moduleclass_sfx'); ?>"> 
	<ul class="rd-mostdownloaded" >
		<?php foreach ($list as $item) :  ?>
			<li>
				<a href="<?php echo $item->link; ?>">
				<?php echo $item->text; ?></a> <span>(<?php echo $item->downloads; ?>)</span>
			</li>
		<?php endforeach; ?>
	</ul>
</div>