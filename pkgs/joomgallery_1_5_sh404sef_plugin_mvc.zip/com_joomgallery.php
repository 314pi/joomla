<?php
// $HeadURL: https://joomgallery.org/svn/joomgallery/JG-1.5/Addons/Plugin%20sh404SEF/trunk/com_joomgallery.php $
// $Id: com_joomgallery.php 2634 2011-01-08 11:19:01Z aha $
/**
 * sh404SEF support for com_joomgallery (JoomGallery 1.5.6) component.
 * Version 1.5.6
 * 20101108
 * Author : JoomGallery Team
 * contact : team@joomgallery.net
 *
 * {shSourceVersionTag: Version 1.5}
 *
 * This is a sh404SEF native plugin file
 * copy this file in directory /component/com_sh404sef/sef_ext/
 */
defined( '_JEXEC' ) or die( 'Direct Access to this location is not allowed.' );

// ------------------  standard plugin initialize function - don't change ---------------------------
global $sh_LANG, $sefConfig;
$shLangName = '';
$shLangIso = '';
$title = array();
$shItemidString = '';
$dosef = shInitializePlugin( $lang, $shLangName, $shLangIso, $option);
$sefConfig = &shRouter::shGetConfig();

// ------------------  standard plugin initialize function - don't change ---------------------------

// ------------------  load language file - adjust as needed ----------------------------------------
//$shLangIso = shLoadPluginLanguage( 'com_joomgallery', $shLangIso, '_SEF_SAMPLE_TEXT_STRING');
// ------------------  load language file - adjust as needed ----------------------------------------

/**
 * Get category path
 *
 * @param integer current category id
 * @return catpath
 */
if( !function_exists( 'sh404plugin_catalias' ) )
{
  function sh404plugin_catalias($catid)
  {
    // Get the alias of category
    $database = &JFactory::getDBO();
    $database->setQuery("SELECT cid,alias FROM #__joomgallery_catg WHERE cid=".$catid);
    return $database->loadObject();
  }
}
if( !function_exists( 'sh404plugin_imgalias' ) )
{
  // Get the alias of image
  function sh404plugin_imgalias($imgid)
  {
    $database = &JFactory::getDBO();
    $database->setQuery("SELECT id,alias FROM #__joomgallery WHERE id=".$imgid);
    return $database->loadObject();
  }
}
if( !function_exists( 'sh404plugin_getusername' ) )
{
  function sh404plugin_getusername($userid){
    $database = &JFactory::getDBO();
    $database->setQuery("SELECT username from #__users WHERE id=".$userid);
    $result = $database->loadResult();
    return $result;
  }
}

$jgoption = isset($option) ? @$option: null;

// Remove common URL from GET vars list,
// so that they don't show up as query string in the SEF URL
shRemoveFromGETVarsList('option');
shRemoveFromGETVarsList('lang');

$Itemid = isset($Itemid) ? @$Itemid : null;
if (!is_null($Itemid))
{
  shRemoveFromGETVarsList('Itemid');
}
$limit = isset($limit) ? @$limit : null;
if (!is_null($limit))
{
  shRemoveFromGETVarsList('limit');
}
$task = isset($task) ? @$task : null;
shRemoveFromGETVarsList('task');

$view = isset($view) ? @$view : null;
shRemoveFromGETVarsList('view');

// Start by inserting the menu element title in order
// 1. setting in sh404SEF Backend 'By component'
// 2. menutitle
// 3. nothing
//$Itemid = isset($Itemid) ? @$Itemid : null;
$shJoomGallery = shGetComponentPrefix($option);
$shJoomGallery = empty($shJoomGallery) ?  getMenuTitle($option, $task, $Itemid, null, $shLangName) : $shJoomGallery;

if (!empty($shJoomGallery)) {
  $title[] = $shJoomGallery;
}

// Main parameter of JoomGallery to decide the sef conversion
$jgmainparam = null;

if (is_null($task) || $task == 'display')
{
  // No task (implicit task=display)
  // or task = display
  // so take the view parameter
  $jgmainparam = $view;
}
else
{
  $jgmainparam = $task;
}

switch($jgmainparam)
{
  // Tasks with common names
  case 'savenametag':
  case 'removenametag':
  case 'delete':         //delete image in userpanel
  case 'savecategory':
  case 'display':
  case 'removeall':
  case 'removeimage':
  case 'save':
  case 'switchlayout':
    $title[] = $jgmainparam;
    break;

  // Handling of task and view
  case 'upload':
    if (is_null($task))
    {
      $tab = isset($tab) ? @$tab : '';
      $title[] = $tab.'upload';
      shRemoveFromGETVarsList('tab');
    }
    else
    {
      $type = isset($type) ? @$type : '';
      $title[] = 'taskupload'.$type;
      shRemoveFromGETVarsList('type');
    }
    break;

  case 'selectnametag':
    $tmpl = isset($tmpl) ? @$tmpl : null;
    if(!is_null($tmpl))
    {
      shRemoveFromGETVarsList('tmpl');
    }
    $title[] = $jgmainparam;
    break;

  // Task: favourites, add image to list
  case 'addimage':
    $imgid = isset($id) ? @$id : null;
    $title[] = 'addimage-'.$imgid;
    shRemoveFromGETVarsList('id');
    break;
  // Task: favourites, prepare zip for download
  case 'createzip':
    $title[] = strtolower(JText::_('createzip'));
    break;

  // Task: detail view, remove comment
  // no SEF because of a huge number of future orphaned URL in database of sh404SEF
  case 'removecomment':
    $dosef = false;
    break;

  // Task: detail view, send comment
  case 'comment':
  // Task: detail view, download an image
  case 'download':
  // Task: detail view, click at icon to open a box to select a user of nametag
  case 'send2friend':
  // Task: detail view, send vote
  case 'vote':
    $imgid = isset($id) ? @$id : null;
    $imgaliasobj = sh404plugin_imgalias($imgid);
    $imgalias = $imgaliasobj->alias;

    switch($task)
    {
      case 'comment':
        $title[] = strtolower(JText::_('JGS_DETAIL_COMMENTS_SEND_COMMENT'))
                   .'-'
                   .$imgalias;
         break;
      case 'removecomment':
        $cmtid = isset($cmtid) ? @$cmtid : null;
        $title[] = 'removecomment-'
                   .$imgalias.'-'
                   .$cmtid;
        shRemoveFromGETVarsList('cmtid');
        break;
      case 'download':
        $title[] = 'download'
                   .'-'
                   .$imgalias;
         break;
      case 'send2friend':
        $title[] = strtolower(JText::_('JGS_DETAIL_SENDTOFRIEND'))
                   .'-'
                   .$imgalias;
        break;
      case 'vote':
       $title[] = strtolower(JText::_('JGS_DETAIL_RATING_VOTE'))
                   .'-'
                   .$imgalias;
        break;
    }

    // ajax - voting, vote view
    if(is_null($task) && $view == 'vote')
    {
      $title[] = 'ajax-'
                   .strtolower(JText::_('JGS_DETAIL_RATING_VOTE'))
                   .'-'
                   .$imgalias;
       shRemoveFromGETVarsList('format');
    }

    shRemoveFromGETVarsList('id');
    break;

  // View: category
  case 'category':
    // Get the category alias from DB
    $catid = isset($catid) ? @$catid : null;
    $cataliasobj = sh404plugin_catalias($catid);
    $title[] = $cataliasobj->alias;
    shRemoveFromGETVarsList('catid');

    // Variables for frontend sort
    $orderby = isset($orderby) ? @$orderby : null;
    $orderdir = isset($orderdir) ? @$orderdir : null;
    $startpage = isset($startpage) ? @$startpage : null;

    if ($orderby != null ) {
      $title[]= 'order='.$orderby;
      shRemoveFromGETVarsList('orderby');
    }
    if ($startpage != null ) {
      $title[]= 'start='.$startpage;
      shRemoveFromGETVarsList('startpage');
    }

    if ($orderdir != null ) {
      $title[]= 'dir='.$orderdir;
      shRemoveFromGETVarsList('orderdir');
    }
  break;

  // View: detail view url or image url
  case 'detail':
  case 'image':
    $imgid = isset($id) ? @$id : null;

    // Get the category of the image from DB
    $database->setQuery("SELECT catid FROM #__joomgallery WHERE id=".$imgid);
    $catid = $database->loadResult();

    // Get alias of category
    $cataliasobj = sh404plugin_catalias($catid);
    $title[] = $cataliasobj->alias.'/';

    if ($jgmainparam == 'detail')
    {
      // Get alias of image
      $imgaliasobj = sh404plugin_imgalias($imgid);
      $title[] = $imgaliasobj->alias;
      shRemoveFromGETVarsList('detail');
    }
    else
    {
      $type = isset($type) ? @$type : null;
      $imgaliasobj = sh404plugin_imgalias($imgid);
      $title[] = $type
                 .'-'
                 .$imgaliasobj->alias;

      shRemoveFromGETVarsList('type');
      shRemoveFromGETVarsList('format');
    }
    shRemoveFromGETVarsList('id');

    break;

  // View: search results
  case 'search' :
    $title[] = 'search';
    break;

  // View: top lists
  case 'toplist' :
    $type = isset($type) ? @$type : null;
    if ( $type == 'find' ) {
    } else {
      switch ( $type ) {
        case "lastcommented" :
          $title[] = strtolower(JText::_('JGS_COMMON_TOPLIST_LAST_COMMENTED'));
          break;
        case "lastadded" :
          $title[] = strtolower(JText::_('JGS_COMMON_TOPLIST_LAST_ADDED'));
          break;
        case "toprated" :
          $title[] = strtolower(JText::_('JGS_COMMON_TOPLIST_TOP_RATED'));
          break;
        default:
          $title[] = strtolower(JText::_('JGS_COMMON_TOPLIST_MOST_VIEWED'));
      }
    }
    shRemoveFromGETVarsList('type');
  break;

  // Favourites
  case 'favourites':
    $title[] = strtolower(JText::_('JGS_FAVOURITES_MY'));
    break;

  // Userpanel
  case 'userpanel':
  case 'usercategories':
  case 'editcategory':
  case 'deletecategory':
    $title[] = strtolower(JText::_('JGS_COMMON_USER_PANEL'));
    if ($jgmainparam != 'userpanel')
    {
      $title[] = strtolower(JText::_('JGS_COMMON_CATEGORIES'));
    }
    if ($jgmainparam == 'editcategory')
    {
      $catid = isset($catid) ? @$catid : null;
      if (is_null($catid))
      {
        $title[] = 'new';
      }
      else
      {
        $title[] = 'edit-'.$catid;
      }
      shRemoveFromGETVarsList('catid');
    }
    else if($jgmainparam == 'deletecategory')
    {
      $catid = isset($catid) ? @$catid : null;
      $title[] = 'delete-'.$catid;
      shRemoveFromGETVarsList('catid');
    }
    break;

  // View: gallery view
  case 'gallery':
    break;
  default:
    $dosef = false;
  break;
}

if ($dosef)
{

}

// ------------------  standard plugin finalize function - don't change --------
if ($dosef){
   $string = shFinalizePlugin( $string, $title, $shAppendString, $shItemidString,
      (isset($limit) ? @$limit : null), (isset($limitstart) ? @$limitstart : null),
      (isset($shLangName) ? @$shLangName : null));
}
// ------------------  standard plugin finalize function - don't change --------
?>