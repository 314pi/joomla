<?php
// $HeadURL: https://joomgallery.org/svn/joomgallery/JG-1.5/Plugins/JoomRokBox/joomrokbox.php $
// $Id: joomrokbox.php 1904 2010-03-02 20:57:30Z mab $
/****************************************************************************************\
**   Plugin 'JoomRokbox' 1.5                                                            **
**   By: JoomGallery::ProjectTeam                                                       **
**   Copyright (C) 2010 - 2010 Patrick Alt                                              **
**   Released under GNU GPL Public License                                              **
**   License: http://www.gnu.org/copyleft/gpl.html or have a look                       **
**   at administrator/components/com_joomgallery/LICENSE.TXT                            **
\****************************************************************************************/

defined('_JEXEC') or die('Direct Access to this location is not allowed.');

jimport('joomla.plugin.plugin');

/**
 * JoomGallery RokBox Plugin
 *
 * With this plugin JoomGallery is able to use
 * RokBox (http://www.rockettheme.com/extensions-joomla/rokbox/)
 * for displaying images.
 *
 * NOTE: Please remember that the system plugin of RokBox has to be installed and
 *       enabled to use RokBox in JoomGallery. You can find this plugin
 *       ('RokBox System Plugin') at the page linked above.
 *
 * @package     Joomla
 * @subpackage  JoomGallery
 * @since       1.5
 */
class plgJoomGalleryJoomRokbox extends JPlugin
{
  /**
   * Constructor
   *
   * For php4 compatability we must not use the __constructor as a constructor for plugins
   * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
   * This causes problems with cross-referencing necessary for the observer design pattern.
   *
   * @access  protected
   * @param   object    $subject  The object to observe
   * @param   object    $params   The object that holds the plugin parameters
   * @return  void
   * @since   1.5
   */
  function plgJoomGalleryJoomRokbox(&$subject, $params)
  {
    parent::__construct($subject, $params);
  }

  /**
   * OnJoomOpenImage method
   *
   * Method is called after an image of JoomGallery shall be opened.
   * It modifies the given link in order to use RokBox for opening the image.
   *
   * @access  public
   * @param   string  $link     The link to modify
   * @param   object  $image    An object holding the image data
   * @param   string  $img_url  The URL to the image which shall be openend
   * @param   string  $group    The name of an image group, RokBox will make an album out of the images of a group
   * @param   string  $type     'orig' for original image, 'img' for detail image or 'thumb' for thumbnail
   * @return  void
   * @since   1.5
   */
  function onJoomOpenImage(&$link, $image = null, $img_url = null, $group = 'joomgallery', $type = 'orig')
  {
    if($image)
    {
      #$this->_ambit = & JoomAmbit::getInstance();

      #$imgsize = getimagesize($this->_ambit->getImg($type.'_path', $image));
      $link = $img_url.'" rel="rokbox['./*$imgsize[0].' '.$imgsize[1].*/']('.$group.')" title="'.$image->imgtitle.' :: '.$image->imgtext;
    }
    else
    {
      // JoomGallery wants to know whether this plugin is enabled
      $link = true;
    }
  }
}