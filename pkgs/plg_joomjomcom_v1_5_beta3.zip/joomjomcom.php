<?php
// $HeadURL: https://joomgallery.org/svn/joomgallery/JG-1.5/Plugins/JoomJomComments/trunk/joomjomcom.php $
// $Id: joomjomcom.php 2317 2010-08-27 01:33:17Z chraneco $
/******************************************************************************\
**   JoomGallery Plugin 'JoomJomCom' 1.5 BETA                                 **
**   By: JoomGallery::ProjectTeam                                             **
**   Copyright (C) 2009 - 2009  Patrick Alt                                   **
**   Released under GNU GPL Public License                                    **
**   License: http://www.gnu.org/copyleft/gpl.html or have a look             **
**   at administrator/components/com_joomgallery/LICENSE.TXT                  **
\******************************************************************************/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');

jimport('joomla.plugin.plugin');

/**
 * JoomGallery Plugin
 * Displays the number of comments of images and categories
 *
 * @package     Joomla
 * @subpackage  JoomGallery
 * @since       1.5
 */
class plgJoomgalleryJoomJomCom extends JPlugin
{
  /**
   * Constructor
   *
   * For php4 compatability we must not use the __constructor as a constructor for plugins
   * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
   * This causes problems with cross-referencing necessary for the observer design pattern.
   *
   * @access  protected
   * @param   object    $subject  The object to observe
   * @param   object    $params   The object that holds the plugin parameters
   * @return  void
   * @since   1.5
   */
  function plgJoomgalleryJoomJomCom(&$subject, $params)
  {
    parent::__construct($subject, $params);

    $comments = JPATH_ROOT.DS.'components'.DS.'com_jomcomment'.DS.'helper'.DS.'minimal.helper.php';
    if(file_exists($comments))
    {
      require_once($comments);
    }
    else
    {
      JError::raiseError(404, 'JomComment is not installed');
    }
  }

  /**
   * Displays the number of comments of a specific image
   *
   * Method is called by the view
   *
   * @access  public
   * @param   int     $id The image ID
   * @return  string  The HTML output for displaying the number of comments
   * @since   1.5
   */
  function onJoomAfterDisplayThumb($id)
  {
    if(!$this->params->get('image'))
    {
      return '';
    }

    $html = '
        <li>
          '.JText::sprintf('JGS_COMMON_COMMENTS_VAR', jcCountComment($id, 'com_joomgallery')).'
        </li>';

    return $html;
  }

  /**
   * Displays the number of comments of a specific category
   *
   * Method is called by the view
   *
   * @access  public
   * @param   int     $id The category ID
   * @return  The HTML output for displaying the number of comments
   * @since   1.5
   */
  function onJoomAfterDisplayCatThumb($id)
  {
    if(!$this->params->get('category'))
    {
      return '';
    }

    $id = 900000000 + $id;

    $html = '
        <li>
          '.JText::sprintf('JGS_COMMON_COMMENTS_VAR', jcCountComment($id, 'com_joomgallery')).'
        </li>';

    return $html;
  }

  /**
   * Loads the data objects which JoomGallery will use in the
   * Toplist 'Last Commented' View.
   *
   * Method is called by the view
   *
   * @access  public
   * @param   int     $rows   The variable in which the objects will be stored
   * @param   int     $limit  The number of images to load, usually the one configured in JoomGallery for the toplists view
   * @return  void
   * @since   1.5
   */
  function onJoomGetLastComments(&$rows, $limit = null)
  {
    $user = & JFactory::getUser();
    $db   = & JFactory::getDBO();

    if($limit)
    {
      $limit = 'LIMIT '.intval($limit);
    }

    $db->setQuery(" SELECT
                      jc.*,
                      ca.*,
                      a.owner AS owner,
                      jc.date AS datetime,
                      a.*
                    FROM
                      "._JOOM_TABLE_IMAGES." AS a,
                      "._JOOM_TABLE_CATEGORIES." AS ca,
                      #__jomcomment AS jc
                    WHERE
                          a.id            = jc.object_id
                      AND jc.object_group = 'com_joomgallery'
                      AND a.catid         = ca.cid
                      AND a.published     = 1
                      AND a.approved      = 1
                      AND jc.published    = 1
                      AND ca.published    = 1
                      AND ca.access      <= ".$user->get('aid')."
                    ORDER BY
                      jc.date DESC
                    ".$limit
                  );

    if(!$rows = $db->loadObjectList())
    {
      return;
    }

    // Prepare the comments for displaying them and count the comments for each image
    foreach($rows as $key => $row)
    {
      JComments::prepareComment($rows[$key]);
      $rows[$key]->comments = JComments::getCommentsCount($row->object_id, 'com_joomgallery');
    }

    // JoomGallery wants to know that this data is delivered by a plugin
    $rows[0]->delivered_by_plugin = true;
  }
}