<?php
// $HeadURL: https://joomgallery.org/svn/joomgallery/JG-1.5/Module/JoomSearch/trunk/mod_joomsearch.php $
// $Id: mod_joomsearch.php 2149 2010-05-10 16:14:41Z aha $
/**
* Module JoomSearch 1.5
* by JoomGallery::Project Team
* @package JoomGallery
* @Copyright JoomGallery team
* @ All rights reserved
* @ Joomla Open Source is Free Stuff
* @ Released under GnuGPL License.
**/

/// no direct access
defined('_JEXEC') or die('Restricted access');
jimport('joomla.filesystem.file');

//get the interface
$resultinterface=require_once(JPATH_ROOT.DS.'components'.DS.'com_joomgallery'.DS.'interface.php');

//TODO Abbruch wenn nicht verfügbar

// Include the helper class only once
require_once (dirname(__FILE__).DS.'helper.php');

//id of actual module instance
$moduleid=$module->id;

//create helper object
$joomsearchObj=new modJoomSearchHelper($params,$moduleid);

//default view
$path = JModuleHelper::getLayoutPath('mod_joomsearch', 'default');

if (JFile::exists($path))
{
  require($path);
}
?>