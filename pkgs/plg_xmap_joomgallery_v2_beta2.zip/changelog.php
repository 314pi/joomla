<?php
defined( '_JEXEC' ) or die( 'Direct Access to this location is not allowed.' );
?>
CHANGELOG Plugin for XMAP

Legende / Legend:

* -> Security Fix
# -> Bug Fix
+ -> Addition
^ -> Change
- -> Removed
! -> Note

***     Version 2.0 BETA2   ***
# wrong url of gallery categories in xml sitemap

***     Version 2.0 BETA   ***
! 20120306 first public version