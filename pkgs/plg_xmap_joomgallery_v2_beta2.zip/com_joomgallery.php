<?php

defined('_JEXEC') or die;

class xmap_com_joomgallery
{

  static $jginterface;

  /**
   * This function is called before a menu item is printed. We use it to set the
   * proper uniqueid for the item
   *
   * @param object  Menu item to be "prepared"
   * @param array   The extension params
   *
   * @return void
   */
  static function prepareMenuItem(&$node,&$params)
  {
    $link_query = parse_url($node->link );
    parse_str(html_entity_decode($link_query['query']), $link_vars);
    $view = JArrayHelper::getValue( $link_vars, 'view', '', '' );

    // TODO view=image ???

    if($view =='detail')
    {
      $id = intval(JArrayHelper::getValue($link_vars,'id',0));
      $node->uid = 'com_joomgalleryi'.$id;
      $node->expandible = false;
    }
    elseif($view =='category')
    {
      $cid = intval(JArrayHelper::getValue($link_vars,'catid',0));
      $node->uid = 'com_joomgalleryc'.$cid;
      $node->expandible = true;
    }
  }

  /**
   * Gets the tree of category structure
   *
   * @return void
   * @since  1.0
   */
  static function getTree($xmap, $parent, &$params)
  {
    if ($xmap->isNews) // This component does not provide news content. don't waste time/resources
    {
      return false;
    }

    $link_query = parse_url($parent->link);
    if (!isset($link_query['query'])) {
      return;
    }

    parse_str(html_entity_decode($link_query['query']), $link_vars);

    // Get the parameters
    // Set expand_categories param, to determine the search of image items
    $expand_categories = JArrayHelper::getValue($params, 'expand_categories', 1);
    $expand_categories = ( $expand_categories == 1
                          || ( $expand_categories == 2 && $xmap->view == 'xml')
                          || ( $expand_categories == 3 && $xmap->view == 'html')
                          || $xmap->view == 'navigator');
    $params['expand_categories'] = $expand_categories;

    //----- Set cat_priority and cat_changefreq params
    $priority = JArrayHelper::getValue($params, 'cat_priority', $parent->priority);
    $changefreq = JArrayHelper::getValue($params, 'cat_changefreq', $parent->changefreq);
    if ($priority == '-1')
    {
      $priority = $parent->priority;
    }
    if ($changefreq == '-1')
    {
      $changefreq = $parent->changefreq;
    }

    $params['cat_priority'] = $priority;
    $params['cat_changefreq'] = $changefreq;

    //----- Set img_priority and img_changefreq params
    $priority = JArrayHelper::getValue($params, 'img_priority', $parent->priority);
    $changefreq = JArrayHelper::getValue($params, 'img_changefreq', $parent->changefreq);
    if ($priority == '-1')
    {
      $priority = $parent->priority;
    }
    if ($changefreq == '-1')
    {
      $changefreq = $parent->changefreq;
    }

    $params['img_priority'] = $priority;
    $params['img_changefreq'] = $changefreq;
    $params['max_images'] = intval(JArrayHelper::getValue($params, 'max_images', 0));

    $cid = intval(JArrayHelper::getValue($params, 'catid', 1));
    self::getCategories($xmap, $parent, $cid, $params, $parent->id);
  }

  /**
   * Get category items within a category and images contained
   * Returns an array of all contained categories and images
   *
   * @param object  $xmap
   * @param object  $parent   the menu item
   * @param int     $catid    the id of the category
   * @param array   $params   an assoc array with the params for this plugin on Xmap
   * @param int     $itemid   the itemid to use for this category's children
   */
  static function getCategories($xmap, $parent, $catid, &$params, $itemid)
  {
    // Get the interface of JoomGallery
    self::getJGInterface();

    if(!self::$jginterface)
    {
      return false;
    }

    // Get category structure
    static $catstructure;
    $catstructure = self::$jginterface->getAmbit()->getCategoryStructure();

    if(empty($catstructure))
    {
      // no viewable category in Gallery
      return false;
    }

    // If catid = 1 call getRootCats()
    // to get the cats at most upper level
    if($catid == 1)
    {
      $rootcats = self::getRootCats();
      $subcats = $rootcats;
    }
    else
    {
      // Get subcategories of category
      // returns an array with catids so construct an array with objects needed for the nodes
      $subcatsjg = JoomHelper::getAllSubCategories($catid, false, true);
      $subcats = array();
      foreach($subcatsjg as $key => $value)
      {
        // Deny elements with wrong hierarchy level, because getAllSubCategories delivers subcategories of all levels
        if($catstructure[$value]->parent_id == $catid)
        {
          $subcats[$key]->cid = $value;
        }
      }
    }

    if (count($subcats) > 0)
    {
      $xmap->changeLevel(1);
      foreach ($subcats as $subcat)
      {
        $node = new stdclass();
        $node->id = $parent->id;
        $node->uid = $parent->uid . 'c' . $subcat->cid;
        $node->browserNav = $parent->browserNav;
        $node->priority = $params['cat_priority'];
        $node->changefreq = $params['cat_changefreq'];

        $modifieddate =  self::getModifiedDate($subcat->cid);
        if(!is_null($modifieddate))
        {
          $node->modified = $modifieddate;
        }
        $node->name = $catstructure[$subcat->cid]->name;
        $node->expandible = true;
        $node->secure = $parent->secure;
        $node->keywords = $catstructure[$subcat->cid]->name;
        $node->newsItem = 0;
        $node->slug = $subcat->cid;
        $node->link = 'index.php?option=com_joomgallery&amp;view=category&amp;catid='.$subcat->cid.'&Itemid='.$parent->id;
        $node->itemid = $parent->id;

        // Print the category node and look recursively for subcategories
        if($xmap->printNode($node))
        {
          // Include images of category if setted
          // deny if detail view of JoomGallery is not reachable
          if(  $params['expand_categories']
             && self::$jginterface->getJConfig('jg_detailpic_open') == 0
             && self::$jginterface->getJConfig('jg_showdetailpage') == 1
             && self::$jginterface->getJConfig('jg_disabledetailpage') == 0
            )
          {
            self::getImages($xmap, $parent, $subcat->cid, $params, $itemid);
          }
          self::getCategories($xmap, $parent, $subcat->cid, $params, $node->itemid);
        }
      }
      $xmap->changeLevel(-1);
    }
    return true;
  }

  /**
   * Get all image items within the category.
   * Returns an array of contained images
   *
   */
  static function getImages($xmap, $parent, $catid, &$params,$Itemid)
  {
    // Get images from interface, ordered by imgdate
    $images = self::$jginterface->getPicsByCategory($catid, null, 'imgdate desc', $params['max_images']);

    if (count($images) > 0)
    {
      $xmap->changeLevel(1);
      foreach ($images as $image)
      {
        $node = new stdclass();
        $node->id = $parent->id;
        $node->uid = $parent->uid . 'i' . $image->id;
        $node->browserNav = $parent->browserNav;
        $node->priority = $params['img_priority'];
        $node->changefreq = $params['img_changefreq'];
        $node->name = $image->imgtitle;
        // Convert imgdate to timestamp
        $timestamp = strtotime($image->imgdate);
        $node->modified = $timestamp;
        $node->expandible = false;
        $node->secure = $parent->secure;
        $node->keywords = $image->imgtitle;
        $node->newsItem = 0;
        $node->language = null;
        $node->link = 'index.php?option=com_joomgallery&amp;view=detail&amp;id='.$image->id.'&Itemid='.$parent->id;
        $xmap->printNode($node);
      }
      $xmap->changeLevel(-1);
    }
    return true;
  }

  /**
   * @static
   * @return bool|JoomInterface|null
   */
  private static function getJGInterface()
  {
    if(self::$jginterface)
    {
      return;
    }

    // Check if JoomGallery component is installed/enabled
    if (!JComponentHelper::isEnabled('com_joomgallery', true )) {
      return false;
    }

    // Check if file of interface exists
    $jg_interface = JPATH_SITE . '/components/com_joomgallery/interface.php';
    if (!is_file($jg_interface))
    {
      return null;
    }

    require_once($jg_interface);
    self::$jginterface = new JoomInterface();
  }

  /**
   * Get the root categories of gallery
   *
   * @return array of category items
   */
  private function getRootCats()
  {
    $user = JFactory::getUser();
    $db   = JFactory::getDbo();

    $query = $db->getQuery(true)
      ->select('c.cid')
      ->from(_JOOM_TABLE_CATEGORIES.' AS c');

    $query->where('c.published = 1')
      ->where('c.hidden    = 0')
      ->where('c.parent_id = 1');


    $query->where('c.access IN ('.implode(',', $user->getAuthorisedViewLevels()).')');

    $query->order('c.lft');
    $db->setQuery( $query);
    $result = $db->loadObjectList();
    return $result;
  }

  /**
   * Get the max. image date to determine the modification date of category
   *
   * @param $cid
   * @return integer timestamp
   */
  private function getModifiedDate(&$cid)
  {
    $image = self::$jginterface->getPicsByCategory($cid, null, 'imgdate desc', 1, 0);

    if(empty($image))
    {
      $imgdate = null;
    }
    else
    {
      $imgdate = strtotime($image[0]->imgdate);
    }

    return $imgdate;
  }
}