<?php
// $HeadURL: https://joomgallery.org/svn/joomgallery/JG-1.5/Plugins/JoomSmileys/trunk/joomsmileys.php $
// $Id: joomsmileys.php 1676 2009-11-14 21:39:54Z chraneco $
/******************************************************************************\
**   JoomGallery Plugin 'JoomSmileys' 1.5 BETA                                **
**   By: JoomGallery::ProjectTeam                                             **
**   Copyright (C) 2009  Patrick Alt                                          **
**   Released under GNU GPL Public License                                    **
**   License: http://www.gnu.org/copyleft/gpl.html                            **
\******************************************************************************/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');

jimport('joomla.plugin.plugin');

/**
 * JoomGallery Plugin
 *
 * Adds the possibility to replace the default smileys of JoomGallery
 *
 * @package     Joomla
 * @subpackage  JoomGallery
 * @since       1.5
 */
class plgJoomGalleryJoomSmileys extends JPlugin
{
  /**
   * Constructor
   *
   * For php4 compatability we must not use the __constructor as a constructor for plugins
   * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
   * This causes problems with cross-referencing necessary for the observer design pattern.
   *
   * @param object $subject The object to observe
   * @param object $params  The object that holds the plugin parameters
   * @since 1.5
   */
  function plgJoomGalleryJoomSmileys(&$subject, $params)
  {
    parent::__construct($subject, $params);
  }

  /**
   * JoomSmileys onJoomGetSmileys method
   *
   * @param   array An array of smileys
   * @return  array The new smileys array
   */
  function onJoomGetSmileys(&$smileys)
  {
    if($this->params->get('disable_default_smileys'))
    {
      $smileys = array();
    }

    $path   = rtrim($this->params->get('url', ''), '/').'/';

    $array  = array("\r\n", "\r");
    $codes  = explode("\n", str_replace($array, "\n", $this->params->get('codes')));

    foreach($codes as $smiley)
    {
      $smiley = explode('-->', $smiley);

      if(isset($smiley[1]))
      {
        $smileys[$smiley[0]] = $path.$smiley[1];
      }
    }
  }
}