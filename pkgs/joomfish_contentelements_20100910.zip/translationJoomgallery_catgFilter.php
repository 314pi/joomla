<?php
/**
 * This script was written by Hermann Maurer (http://www.hermannsspace.de/)
 * Copyright (c) 2009-06-19, see the licence conditions below.
 * All rights reserved. 
 *  
 * This scripts is to be placed into the directory 
 * joomla/administrator/components/com_joomfish/contentelements
 * together with the joomlagallery.xml file.  
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,USA.
 *
 * The "GNU General Public License" (GPL) is available at
 * http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 * -----------------------------------------------------------------------------
 *
*/
 
// Don't allow direct linking
defined( 'JPATH_BASE' ) or die( 'Direct Access to this location is not allowed.' );
 
class translationjoomgallery_catgFilter extends translationFilter
{
  function translationjoomgallery_catgFilter ($contentElement){
    $this->filterNullValue=-1;
    $this->filterType="joomgallery_catg";
    $this->filterField = $contentElement->getFilter("joomgallery_catg");
    parent::translationFilter($contentElement);
  }
 
  function _createFilter(){
    $db =& JFactory::getDBO();
    if (!$this->filterField ) return "";
    $filter="";
    if ($this->filter_value!=$this->filterNullValue) {
      // get list of picids in the appropriate category
      $sql = "SELECT pic.id FROM #__joomgallery as pic"
        ." WHERE pic.catid=$this->filter_value";
      // echo($sql);
      $db->setQuery($sql);
      $picids = $db->loadObjectList();
      $idstring = "";
      foreach ($picids as $pid){
        if (strlen($idstring)>0) $idstring.=",";
          $idstring.=$pid->id;
      }
      $filter = "c.id IN($idstring)";
    }
    return $filter;
  }
 
 /**
 * Creates joomgallery_catg filter 
 *
 * @param unknown_type $filtertype
 * @param unknown_type $contentElement
 * @return unknown
 */
  function _createfilterHTML(){
    $db =& JFactory::getDBO();
    if (!$this->filterField) return "";
    $categoryOptions=array();
    $categoryOptions[] = JHTML::_('select.option', '-1', JText::_('All Categories'));
    $sql = "SELECT DISTINCT cat.cid, cat.name FROM #__joomgallery_catg as cat,"
     ." #__".$this->tableName." as c, #__joomgallery as xref"
     ." WHERE c.catid=xref.catid AND xref.".$this->filterField."=cat.cid ORDER BY cat.name";
    //  echo($sql);
    $db->setQuery($sql);
    $cats = $db->loadObjectList();
    $catcount=0;
    foreach($cats as $cat) {
      $categoryOptions[] = JHTML::_('select.option', $cat->cid,$cat->name);
      $catcount++;
    }
    $categoryList=array();
    $categoryList["title"]= 'JoomGallery category';
    $categoryList["html"] = JHTML::_('select.genericlist', $categoryOptions, 'joomgallery_catg_filter_value', 'class="inputbox" size="1" onchange="document.adminForm.submit();"', 'value', 'text', $this->filter_value );
    return $categoryList;
  }
}
 
?>
 