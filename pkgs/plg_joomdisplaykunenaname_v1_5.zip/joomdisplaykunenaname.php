<?php
// $HeadURL: https://joomgallery.org/svn/joomgallery/JG-1.5/Plugins/JoomDisplayKunenaName/trunk/joomdisplaykunenaname.php $
// $Id: joomdisplaykunenaname.php 3298 2011-08-26 19:42:43Z chraneco $
/****************************************************************************************\
**   Plugin 'JoomDisplayKunenaName' 1.5                                                 **
**   By: JoomGallery::ProjectTeam                                                       **
**   Copyright (C) 2010 - 2011 Patrick Alt                                              **
**   Released under GNU GPL Public License                                              **
**   License: http://www.gnu.org/copyleft/gpl.html or have a look                       **
**   at administrator/components/com_joomgallery/LICENSE.TXT                            **
\****************************************************************************************/

defined('_JEXEC') or die('Direct Access to this location is not allowed.');

jimport('joomla.plugin.plugin');

/**
 * JoomGallery Display Kunena Name Plugin
 *
 * @package     Joomla
 * @subpackage  JoomGallery
 * @since       1.5
 */
class plgJoomGalleryJoomDisplayKunenaName extends JPlugin
{
  /**
   * Constructor
   *
   * For php4 compatability we must not use the __constructor as a constructor for plugins
   * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
   * This causes problems with cross-referencing necessary for the observer design pattern.
   *
   * @access  protected
   * @param   object    $subject  The object to observe
   * @param   object    $params   The object that holds the plugin parameters
   * @return  void
   * @since   1.5
   */
  function plgJoomGalleryJoomDisplayKunenaName(&$subject, $params)
  {
    // Load the language file
    $this->loadLanguage('', JPATH_ADMINISTRATOR);

    $file = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_kunena'.DS.'admin.kunena.php';
    if(!file_exists($file))
    {
      JError::raiseError(500, JText::_('PLG_JOOMDISPLAYKUNENANAME_KUNENA_SEEMS_NOT_TO_BE_INSTALLED'));
    }

    parent::__construct($subject, $params);
  }

  /**
   * OnJoomDisplayUser method
   *
   * Method links a user name with the corresponding Community Builder profile.
   *
   * @access  public
   * @param   int     $userID   The ID of the user to display
   * @param   boolean $realname True, if the user's full name shall be displayed
   * @param   string  $context  The context in which the name will be displayed
   * @return  string  The HTML code created for displaying the user's name
   * @since   1.5
   */
  function onJoomDisplayUser(&$userId, $realname, $context = null)
  {
    $userId = intval($userId);

    $file = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_kunena'.DS.'api.php';

    if(file_exists($file))
    {
      // Kunena 1.6.x
      require_once $file;

      $user = KunenaFactory::getUser($userId);

      if(!$user->get('userid') || JFactory::getApplication()->isAdmin())
      {
        return false;
      }

      $name   = $realname ? $user->get('name') : $user->get('username');
      $avatar = KunenaFactory::getAvatarIntegration()->getLink($user);
      $link   = KunenaFactory::getProfile()->getProfileUrl($user);
    }
    else
    {
      // Kunena 1.5.x
      $db = & JFactory::getDBO();

      $db->setQuery(" SELECT
                        a.*,
                        b.*
                      FROM
                        #__fb_users AS a
                      LEFT JOIN
                        #__users AS b
                      ON
                        b.id = a.userid
                      WHERE
                        a.userid = ".$userId
                    );

      if(!$user = $db->loadObject())
      {
        return false;
      }

      $name = $realname ? $user->name : $user->username;

      if(!$name)
      {
        return false;
      }

      $link = 'index.php?option=com_kunena&func=fbprofile&userid='.$userId.$this->_getItemid();

      if($user->avatar)
      {
        if(!file_exists(JPATH_ROOT.DS.'images'.DS.'fbfiles'.DS.'avatars'.DS.'l_'.$user->avatar))
        {
          $avatar = '<span class="fb_avatar"><img border="0" src="'.JURI::root().'images/fbfiles/avatars/'.$user->avatar.'" alt="'.JText::sprintf('PLG_JOOMDISPLAYKUNENANAME_AVATAR_OF', $name).'"'./* style="max-width: '.$fbConfig->avatarwidth.'px; max-height: '.$fbConfig->avatarheight.'px;"*/ ' /></span>';
        }
        else
        {
          $avatar = '<span class="fb_avatar"><img border="0" src="'.JURI::root().'images/fbfiles/avatars/l_'.$user->avatar.'" alt="'.JText::sprintf('PLG_JOOMDISPLAYKUNENANAME_AVATAR_OF of', $name).'" /></span>';
        }
      }
      else
      {
        $avatar = '<span class="fb_avatar"><img  border="0" src="'.JURI::root().'images/fbfiles/avatars/nophoto.jpg" alt="'.JText::sprintf('PLG_JOOMDISPLAYKUNENANAME_NO_AVATAR_FOUND').'" /></span>';
      }
    }

    $overlib  = htmlspecialchars($avatar, ENT_QUOTES, 'UTF-8');

    if($context == 'comment')
    {
      $html = '<a href="'.JRoute::_($link).'">'.$name.'</a><br /><a href="'.JRoute::_($link).'">'.$avatar.'</a>';
      return $html;
    }

    JHTML::_('behavior.tooltip', '.hasHint');
    $html = '<a href="'.JRoute::_($link).'" title="'.$name.'" rel="'.$overlib.'" class="hasHint">'.$name.'</a>';

    return $html;
  }

  /**
   * Replaces the smileys of JoomGallery with the ones of Kunena, if enabled
   *
   * @access  public
   * @param   array   An array of smileys
   * @return  void
   * @since   1.5
   */
  function onJoomGetSmileys(&$smileys)
  {
    $file = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_kunena'.DS.'api.php';

    if(!$this->params->get('replace_smileys') || !file_exists($file))
    {
      return;
    }

    require_once $file;
    require_once KPATH_SITE.DS.'class.kunena.php';
    require_once KPATH_SITE.DS.'lib'.DS.'kunena.smile.class.php';

    $smileys = smile::getEmoticons(0, 1);
  }

  /**
   * Returns an Itemid which is associated with Kunena forum
   *
   * @access  protected
   * @return  string    A string for URLs with the Itemid ('&Itemid=X')
   * @since   1.5
   */
  function _getItemid()
  {
    if($Itemid = $this->params->get('valid_Itemid_string', ''))
    {
      return $Itemid;
    }

    $Itemid = intval($this->params->get('Itemid', 0));

    if($Itemid)
    {
      $Itemid = '&Itemid='.$Itemid;
      $this->params->set('valid_Itemid_string', $Itemid);

      return $Itemid;
    }

    $db = & JFactory::getDBO();
    $db->setQuery(" SELECT
                      id
                    FROM
                      #__menu
                    WHERE
                          link LIKE '%com_kunena%'
                      AND access = 0
                    ORDER BY
                      id DESC
                  ");
    if($Itemid = $db->loadResult())
    {
      $Itemid = '&Itemid='.$Itemid;
    }
    else
    {
      $db->setQuery(" SELECT
                        id
                      FROM
                        #__menu
                      WHERE
                            link LIKE '%com_kunena%'
                        AND access != 0
                      ORDER BY
                        id DESC
                    ");
      if($Itemid = $db->loadResult())
      {
        $Itemid = '&Itemid='.$Itemid;
      }
      else
      {
        $Itemid = '';
      }
    }

    $this->params->set('valid_Itemid_string', $Itemid);

    return $Itemid;
  }
}