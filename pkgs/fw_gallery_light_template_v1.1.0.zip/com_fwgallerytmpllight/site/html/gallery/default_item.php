<?php
/**
 * FW Gallery x.x.x
 * @copyright (C) 2010 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );

$link = JRoute::_('index.php?option=com_fwgallery&view=image&id='.$this->row->id.':'.JFilterOutput :: stringURLSafe($this->row->name).'&Itemid='.JFHelper :: getItemid('image', $this->row->id, JRequest :: getInt('Itemid')).'#fwgallerytop');
$color_displayed = false;

$styles = array();
if ($this->image_height) $styles[] = 'height:'.$this->image_height.'px;';

?>
<div id="fwgallery-image-<?php echo $this->row->id; ?>" class="fwgallery-<?php echo $this->row->_plugin_name; ?>">

	<div class="fwg-image-wrapper" style="width:<?php echo $this->params->get('im_mid_w')+20; ?>px;">

		<table class="fwgtmpl-table fwgtmpl-table-small fwgtmpl-table-med">
			<tr>
				<td class="fwg-td-top-left"></td>
				<td class="fwg-td-top-mid"></td>
				<td class="fwg-td-top-right"></td>
			</tr>
			<tr>
				<td class="fwg-td-mid-left"></td>
				<td class="fwg-td-mid-mid">
					<div class="fwg-image">
						<a href="<?php echo $link; ?>">
							<img src="<?php echo JURI::root(true).'/'.JFHelper::getFileFilename($this->row, 'mid'); ?>" alt="<?php echo JFHelper :: escape($this->row->name); ?>" />
						</a>
						<?php if (!$this->params->get('hide_mignifier')) { ?>
							<div class="fwg-zoom">
								<a class="fwg-lightbox" href="<?php echo JURI::base(false).JFHelper::getFileFilename($this->row); ?>" rel="fwg-lightbox-gallery" class="effectable">
									<img src="<?php echo JURI :: root(true); ?>/components/com_fwgallerytmpllight/assets/images/zoom.png" />
								</a>
							</div>
						<?php } ?>
					</div>
				</td>
				<td class="fwg-td-mid-right"></td>
			</tr>
			<tr>
				<td class="fwg-td-bottom-left"></td>
				<td class="fwg-td-bottom-mid"></td>
				<td class="fwg-td-bottom-right"></td>
			</tr>
		</table>

		<?php if ($this->params->get('display_name_image')) { ?>
		    <div class="fwg-name">
				<a href="<?php echo $link; ?>">
		        	<?php echo ($this->row->name) ? $this->row->name : JText::_('View image'); ?>
				</a>
		    </div>
		<?php }	?>
	
		<?php if ($this->params->get('use_voting')) { ?>
		<div class="fwg-vote" id="rating<?php echo $this->row->id ?>">
			<?php include(dirname(__FILE__).'/default_vote.php'); ?>
	    </div>
		<?php }	?>
		
		<?php
		if ($this->params->get('display_date_image') and $date = JFHelper::encodeDate($this->row->created)) {
		?>
		    <div class="fwg-date">
		    	<?php echo $date; ?>
		    </div>
		<?php
		}
		if ($this->params->get('display_owner_image') and $this->row->_user_name) {
		?>
		    <div class="fwg-author">
		        <?php echo JText::_('by')." ".$this->row->_user_name; ?>
		    </div>
		<?php
		}
		if (!empty($this->new_days)) {
			$date_diff = floor((time() - strtotime($this->row->created))/86400);
			if ($date_diff <= $this->new_days) {
		?>
		    <div class="fwg-new"></div>
		<?php
			}
		}
		?>

	</div>
</div>
