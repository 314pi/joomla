<?php
/**
 * FW Gallery Import Plugin 1.1.0
 * @copyright (C) 2011 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin' );

class plgFwGalleryImport extends JPlugin {
	function fwGetAdminForm() {
		if (JFactory :: getApplication()->isAdmin()) {
			$galleries = $this->_loadGalleriesList();
			ob_start();
			include(dirname(__FILE__).'/import/tmpl/'.($galleries?'adminform':'error').'.php');
			return ob_get_clean();
		}
	}
	function _loadGalleriesList() {
		$targets = array(
			'phocagallery'=>'Phoca Gallery'
		);
		$result = array();
		$db = JFactory :: getDBO();
		$tables = $db->getTableList();
		foreach ($targets as $table=>$name) {
			if (in_array($db->getPrefix().$table, $tables)) {
				$result[$table] = $name;
			}
		}
		return $result;
	}
	function fwProcess() {
		if (JFactory :: getApplication()->isAdmin()) {
			$gallery = JRequest :: getCmd('gallery');
			$galleries = $this->_loadGalleriesList();

			if ($gallery and isset($galleries[$gallery])) {
				$path = dirname(__FILE__).'/import/'.$gallery.'/'.$gallery.'.php';
				if (file_exists($path)) {
					set_time_limit(0);
					ini_set('memory_limit', '256M');
					jimport('joomla.filesystem.file');
					include($path);
				}
			}
		}
	}
}
?>