<?php
/**
 * FW Gallery Import Plugin 1.1.0
 * @copyright (C) 2011 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );
?>
<legend><?php echo JText :: _('FW Gallery Import'); ?></legend>
<p><?php echo JText :: _('No other galleries found to import'); ?></p>