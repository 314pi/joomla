<?php
/**
 * FW Gallery Import Plugin 1.1.0
 * @copyright (C) 2011 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );
JHTML :: _('behavior.mootools');
?>
<legend><?php echo JText :: _('FW Gallery Import'); ?></legend>
<form action="index.php?option=com_fwgallery&amp;view=plugins" method="post" name="adminForm" id="fw-import-form" onsubmit="return false;">
	<?php echo JText :: _('Select gallery to import'); ?>: <select name="gallery" style="float:none;"><?php foreach ($galleries as $gallery=>$name) {
		?><option value="<?php echo $gallery; ?>"><?php echo $name; ?></option><?php
	}; ?></select>
	<div class="clr"></div>
	<ul>
		<li><?php echo JText :: _('Import galleries'); ?><span id="fwgallery-import-step-1"></span></li>
		<li><?php echo JText :: _('Import images'); ?><span id="fwgallery-import-step-2"></span></li>
		<li><?php echo JText :: _('Import voting'); ?><span id="fwgallery-import-step-3"></span></li>
	</ul>
	<input type="button" name="process_button" value="<?php echo JText :: _('Import'); ?>" />
	<input type="hidden" name="plugin" value="import" />
	<input type="hidden" name="step" value="1" />
	<input type="hidden" name="tmpl" value="component" />
	<input type="hidden" name="task" value="edit" />
</form>
<script type="text/javascript">
window.addEvent('domready', function() {
	var form = $('fw-import-form');
	$(form.process_button).addEvent('click', function() {
		if (confirm('<?php echo JText :: _('Are you sure you need to import selected gallery data', true); ?>?')) {
			$('fwgallery-import-step-1').innerHTML = ' - <img src="<?php echo JURI :: root(true); ?>/plugins/fwgallery/import/<?php if (JFHelper :: isJoomla16()) { ?>import/<?php } ?>assets/images/pleasewait.gif" alt="<?php echo JText :: _('Please wait', true); ?>" />';
			form.step.value = 1;
<?php
if (JFHelper :: isJoomla16()) {
?>
			form.set('send', {
				evalScripts: true
			}).send();
<?php
} else {
?>
			form.send({
				evalScripts: true
			});
<?php
}
?>
		}
	});
});
</script>