<?php
/**
 * FW Gallery Import Plugin 1.1.0
 * @copyright (C) 2011 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );

$db = JFactory :: getDBO();
$step = JRequest :: getInt('step', 1);
$cats = $imgs = array();
$phoca_img_path = JPATH_SITE.'/images/phocagallery/';

/* import categories */
$imported = $processed = 0;
$db->setQuery('
SELECT
	c.id,
	c.title,
	c.`date`,
	c.published,
	c.ordering,
	c.description,
	(SELECT cc.id FROM #__fwg_projects AS cc WHERE cc.name = c.title LIMIT 1) AS category_id
FROM
	#__phocagallery_categories AS c'
);
if ($categories = $db->loadObjectList()) foreach ($categories as $category) {
	$processed++;
	if (!$category->category_id) {
		$post = array(
			'published' => $category->published,
			'name' => $category->title,
			'created' => $category->date,
			'decsr' => $category->description,
			'ordering' => $category->ordering
		);
		$table = JTable :: getInstance('Project', 'Table');
		if ($table->bind($post) and $table->check() and $table->store()) {
			$imported++;
			$category->category_id = $table->id;
		}
	}
	if ($category->category_id) $cats[$category->id] = $category->category_id;
}
/* restore tree categories structure */
$db->setQuery('
SELECT
	(SELECT cc.id FROM #__fwg_projects AS cc WHERE cc.name = pc.title LIMIT 1) AS parent_category_id,
	(SELECT cc.id FROM #__fwg_projects AS cc WHERE cc.name = c.title LIMIT 1) AS category_id
FROM
	#__phocagallery_categories AS c
	LEFT JOIN #__phocagallery_categories AS pc ON pc.id = c.parent_id'
);
if ($list = $db->loadObjectList()) foreach ($list as $row) if ($row->parent_category_id and $row->category_id) {
	$db->setQuery('UPDATE #__fwg_projects SET parent = '.$row->parent_category_id.' WHERE id = '.$row->category_id);
	$db->query();
}

if ($step == 1) {
?>
<script type="text/javascript">
$('fwgallery-import-step-1').innerHTML = ' - <?php echo JText :: sprintf('Processed %s records, imported - %s', $processed, $imported); ?>';
$('fwgallery-import-step-2').innerHTML = ' - <img src="<?php echo JURI :: root(true); ?>/plugins/fwgallery/import/<?php if (JFHelper :: isJoomla16()) { ?>import/<?php } ?>assets/images/pleasewait.gif" alt="<?php echo JText :: _('Please wait', true); ?>" />';
$('fw-import-form').step.value = 2;
<?php
	if (JFHelper :: isJoomla16()) {
?>
$('fw-import-form').set('send', {
	evalScripts: true
}).send();
<?php
	} else {
?>
$('fw-import-form').send({
	evalScripts: true
});
<?php
	}
?>
</script>
<?php
	die();
}

/* import images */
$imported = $processed = 0;
$db->setQuery('
SELECT
	p.id,
	p.catid,
	p.title,
	p.filename,
	p.description,
	p.`date`,
	p.hits,
	p.published,
	p.ordering,
	(SELECT cc.id FROM #__fwg_files AS cc WHERE cc.name = CONCAT(p.title, \' - \', p.catid) LIMIT 1) AS image_id
FROM
	#__phocagallery AS p'
);
if ($images = $db->loadObjectList()) foreach ($images as $image) {
	$processed ++;
	if (!$image->image_id) {
		$post = array(
			'project_id' => (int)JArrayHelper :: getValue($cats, $image->catid),
			'hits' => $image->hits,
			'published' => $image->published,
			'name' => $image->title.' - '.$image->catid,
			'created' => $image->date,
			'decsr' => $image->description,
			'ordering' => $image->ordering
		);
		if ($image->filename and file_exists($phoca_img_path.$image->filename)) {
			$file = array(
				'name' => basename($image->filename),
				'tmp_name' => $phoca_img_path.$image->filename,
				'size' => filesize($phoca_img_path.$image->filename),
				'error' => 0,
				'type' => 'image/'.strtolower(JFile :: getExt($image->filename))
			);
		} else $file = array();
		JRequest :: setVar('filename', $file, 'files');

		$table = JTable :: getInstance('File', 'Table');
		if ($table->bind($post) and $table->check() and $table->store()) {
			$imported++;
			$image->image_id = $table->id;
		}
	}
	if ($image->image_id) $imgs[$image->id] = $image->image_id;
}
if ($step == 2) {
?>
<script type="text/javascript">
$('fwgallery-import-step-2').innerHTML = ' - <?php echo JText :: sprintf('Processed %s records, imported - %s', $processed, $imported); ?>';
$('fwgallery-import-step-3').innerHTML = ' - <img src="<?php echo JURI :: root(true); ?>/plugins/fwgallery/import/<?php if (JFHelper :: isJoomla16()) { ?>import/<?php } ?>assets/images/pleasewait.gif" alt="<?php echo JText :: _('Please wait', true); ?>" />';
$('fw-import-form').step.value = 3;
<?php
	if (JFHelper :: isJoomla16()) {
?>
$('fw-import-form').set('send', {
	evalScripts: true
}).send();
<?php
	} else {
?>
$('fw-import-form').send({
	evalScripts: true
});
<?php
	}
?>
</script>
<?php
	die();
}

/* import votes */
$imported = $processed = 0;
$db->setQuery('SELECT * FROM #__fwg_files_vote');
$exists_votes = $db->loadObjectList();

$db->setQuery('
SELECT
	c.imgid,
	c.userid,
	c.rating
FROM
	#__phocagallery_img_votes AS c'
);
if ($votes = $db->loadObjectList()) foreach ($votes as $vote) {
	$image_id = JArrayHelper :: getValue($imgs, $vote->imgid);
	if (!$image_id) continue;

	$processed++;
	$vote_exists = false;
	foreach ($exists_votes as $i=>$exists_vote) if ($exists_vote->file_id == $image_id and $exists_vote->user_id == $vote->userid) {
		$vote_exists = true;
		array_splice($exists_vote, $i, 1);
		break;
	}

	if (!$vote_exists) {
		$db->setQuery('INSERT INTO #__fwg_files_vote SET file_id = '.$image_id.', user_id = '.$vote->userid.', `value` = '.(int)$vote->rating);
		if ($db->query()) $imported++;
	}
}
?>
<script type="text/javascript">
$('fwgallery-import-step-3').innerHTML = ' - <?php echo JText :: sprintf('Processed %s records, imported - %s', $processed, $imported); ?>';
alert('<?php echo JText :: _('Data importing finished'); ?>');
</script>
<?php
die();
?>