<?php
/**
* CHRONOFORMS version 4.0
* Copyright (c) 2006 - 2011 Chrono_Man, ChronoEngine.com. All rights reserved.
* Author: Chrono_Man (ChronoEngine.com)
* @license		GNU/GPL
* Visit http://www.ChronoEngine.com for regular updates and information.
**/
function com_uninstall() {
	echo "Thank you for using Chronoforms. The component has been uninstalled, If you have any questions or comments, please kindly contact us at this email address: webmaster@chronoengine.com";
}
?>