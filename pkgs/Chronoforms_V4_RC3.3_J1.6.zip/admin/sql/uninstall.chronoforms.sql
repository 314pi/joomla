DROP TABLE IF EXISTS `#__chronoforms`;
DROP TABLE IF EXISTS `#__chronoform_actions`;