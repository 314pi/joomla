<?php
/**
 * Creative Studio x.x.x
 * @copyright (C) 2011 Fastweb
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined('_JEXEC') or die;
JHTML::_('behavior.framework', true);
$app = JFactory::getApplication();
?>
<?php echo '<?'; ?>xml version="1.0" encoding="<?php echo $this->_charset ?>"?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>" >

  <head>
      <jdoc:include type="head" />
     
<link rel="stylesheet" href="/templates/system/css/system.css" type="text/css" />

<link rel="stylesheet" href="/templates/system/css/general.css" type="text/css" />

<link href="<?php echo $this->baseurl;?>/templates/<?php echo $this->template; ?>/css/template.css" rel="stylesheet" type="text/css" />
 
<!--[if IE]>
	<link href="<?php echo $this->baseurl;?>/templates/<?php echo $this->template; ?>/css/ie.css" rel="stylesheet" type="text/css" />
<![endif]-->
 
  </head>
	<body id="bd">

			<!-- header -->
			
			<div id="container-top-header">

				<div id="container-top-logo">
					<!--logo-->
					<div id="logo">
						<a href="<?php echo $this->baseurl;?>" alt="<?php echo JText::_("Real estate");?>">
							<img src="<?php echo $this->baseurl;?>/templates/<?php echo $this->template; ?>/images/logo.png" 
								width="255" height="101" alt="<?php echo JText::_("Real estate");?>" />
						</a>
					</div>
					<!--end logo-->
					
					<!--menu-->				
					<?php if($this->countModules('menu')) : ?>
						<div id="menu">
							<jdoc:include type="modules" name="menu" />
						</div>		
					<?php endif; ?>
					<!--end menu-->

				</div>
						
			</div>
	
		<div id="wrapper-box">
		
		
		<?if (strpos($_SERVER['REQUEST_URI'], 'index.php')!== false){?>

				<!-- content -->
			<div id="blockcontent<?php if($this->countModules('right')) echo "80"; ?>">
			
				<div id="content">
				<jdoc:include type="component" />
				</div>
			
			</div>
		
				<!-------- right  --------->
				<?php if($this->countModules('right')) : ?>
					<div class="right">
						<jdoc:include type="modules" name="right" style="xhtml" />
					</div>
				<?php endif; ?>
				<!-------- end right  --------->

<?}else{?>

			<!--  frontpage  -->
				<?php if($this->countModules('fronted-title')) : ?>
				<div id="fronted-title">
					<jdoc:include type="modules" name="fronted-title"/>
				</div>
				<?php endif; ?>
		
			<!--////////////////////////////////////////////////////////-->	
			<div id="fronted-left">	
				<?php if($this->countModules('fronted-our-projects')) : ?>
				<div id="fronted-our-projects" class="fronted">
					<jdoc:include type="modules" name="fronted-our-projects"" />
				</div>
				<?php endif; ?>
				
			<!--////////////////////////////////////////////////////////-->		
			
			<?php if($this->countModules('fronted-clients')) : ?>
				<div id="fronted-clients" class="fronted">
					<jdoc:include type="modules" name="fronted-clients"" />
				</div>
			<?php endif; ?>
			</div>	
			<!--////////////////////////////////////////////////////////-->			
			
			<?php if($this->countModules('fronted-location')) : ?>
				<div id="fronted-location" class="fronted">
					<jdoc:include type="modules" name="fronted-location"" />
				</div>
			<?php endif; ?>		
			
			<!-- end frontpage  -->

<?}?>			
				
		</div>
			<!-- end content -->

	<!--footer-->	
		
		<div id="footer">
			<div id="footer-box">
				<!--  footer menu  -->
				<?php if($this->countModules('footer-menu')) : ?>
				<div class="footer-menu">
					<jdoc:include type="modules" name="footer-menu" style="xhtml" />
				</div>
				<?php endif; ?>
			<!-- end footer menu  -->
						
			<!--social icons-->
					<?php if($this->countModules('name-social-icons-block') or
					$this->countModules('blogger') or 
					$this->countModules('facebook') or 
					$this->countModules('rss') or 
					$this->countModules('twitter')) : ?>
					<div id="social-icons-block">
						
						<?php if($this->countModules('name-social-icons-block')) : ?>
						<div class="name-social-icons-block">
							<h3><jdoc:include type="modules" name="name-social-icons-block"/></h3>
						</div>
						<?php endif; ?>
						
						
						<?php if($this->countModules('blogger')) : ?>
						<div class="blogger social-icons">
							<jdoc:include type="modules" name="blogger"/>
						</div>
						<?php endif; ?>
						
						<?php if($this->countModules('facebook')) : ?>
						<div class="facebook social-icons">
							<jdoc:include type="modules" name="facebook"/>
						</div>
						<?php endif; ?>
						
						<?php if($this->countModules('rss')) : ?>
						<div class="rss social-icons">
							<jdoc:include type="modules" name="rss"/>
						</div>
						<?php endif; ?>
												
						<?php if($this->countModules('twitter')) : ?>
						<div class="twitter social-icons">
							<jdoc:include type="modules" name="twitter"/>
						</div>
						<?php endif; ?>
																						
					</div>
					<?php endif; ?>
			</div>
		</div>
		<div id="footer-fastw3b">
			<a href="http://www.fastw3b.net">
							<img src="<?php echo $this->baseurl;?>/templates/<?php echo $this->template; ?>/images/fastw3b.png" 
								width="98" height="18" alt="fastw3b" />
						</a>
						Powered by Fastw3b Joomla!. Templates
		</div>
	<!-- end footer-->	
		
	</body>
</html>
