<?php
// $HeadURL: https://joomgallery.org/svn/joomgallery/JG-2.0/Plugins/JoomHighslide/trunk/joomhighslide.php $
// $Id: joomhighslide.php 3738 2012-04-05 11:50:58Z chraneco $
/****************************************************************************************\
**   Plugin 'JoomHighslide' 2.0                                                         **
**   By: JoomGallery::ProjectTeam                                                       **
**   Copyright (C) 2010 - 2012 Patrick Alt                                              **
**   Released under GNU GPL Public License                                              **
**   License: http://www.gnu.org/copyleft/gpl.html or have a look                       **
**   at administrator/components/com_joomgallery/LICENSE.TXT                            **
\****************************************************************************************/

defined('_JEXEC') or die('Direct Access to this location is not allowed.');

jimport('joomla.plugin.plugin');

/**
 * JoomGallery Highslide JS Plugin
 *
 * With this plugin JoomGallery is able to use
 * Highslide JS (http://www.highslide.com/) for displaying images.
 *
 * NOTE: Please remember that Highslide JS is licensed under the terms
 * of the 'Creative Commons Attribution-NonCommercial 2.5 License':
 *
 * http://highslide.com/#licence
 * http://creativecommons.org/licenses/by-nc/2.5/
 *
 * @package     Joomla
 * @subpackage  JoomGallery
 * @since       1.5
 */
class plgJoomGalleryJoomHighslide extends JPlugin
{
  /**
   * Constructor
   *
   * For php4 compatability we must not use the __constructor as a constructor for plugins
   * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
   * This causes problems with cross-referencing necessary for the observer design pattern.
   *
   * @access  protected
   * @param   object    $subject  The object to observe
   * @param   object    $params   The object that holds the plugin parameters
   * @return  void
   * @since   1.5
   */
  public function plgJoomGalleryJoomHighslide(&$subject, $params)
  {
    parent::__construct($subject, $params);
  }

  /**
   * OnJoomOpenImage method
   *
   * Method is called after an image of JoomGallery shall be opened.
   * It modifies the given link in order to use Highslide JS for opening the image.
   *
   * @access  public
   * @param   string  $link     The link to modify
   * @param   object  $image    An object holding the image data
   * @param   string  $img_url  The URL to the image which shall be openend
   * @param   string  $group    The name of an image group, RokBox will make an album out of the images of a group
   * @param   string  $type     'orig' for original image, 'img' for detail image or 'thumb' for thumbnail
   * @return  void
   * @since   1.5
   */
  public function onJoomOpenImage(&$link, $image = null, $img_url = null, $group = 'joomgallery', $type = 'orig')
  {
    static $loaded = false;

    if($image)
    {
      if(!$loaded && !$this->params->get('global_highslide_existent'))
      {
        $doc = JFactory::getDocument();

        $doc->addStyleSheet(JURI::root().'media/plg_joomhighslide/highslide.css');

        $doc->addScript(JURI::root().'media/plg_joomhighslide/highslide.js');
        $doc->addScriptDeclaration("	hs.graphicsDir = '".JURI::root()."media/plg_joomhighslide/graphics/';
  hs.wrapperClassName = 'wide-border';");

        $loaded = true;
      }

      $link = $img_url.'" rel="highslide['.$group.']" onclick="return hs.expand(this);';// class="highslide"
    }
    else
    {
      // JoomGallery wants to know whether this plugin is enabled
      $link = true;
    }
  }
 
  /**
   * onJoomOpenImageGetName method
   *
   * Method is called if the popup box name is requested used by this plugin
   *
   * @return  string  The name of the popup box used by this plugin
   * @since   2.0
   */
  public function onJoomOpenImageGetName()
  {
    return 'Highslide JS';
  }
}