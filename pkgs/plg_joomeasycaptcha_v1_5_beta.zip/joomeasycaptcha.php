<?php
// $HeadURL: https://joomgallery.org/svn/joomgallery/JG-1.5/Plugins/JoomEasyCaptcha/trunk/joomeasycaptcha.php $
// $Id: joomeasycaptcha.php 2072 2010-04-15 08:16:57Z chraneco $
/******************************************************************************\
**   JoomGallery Plugin 'JoomEasyCaptcha' 1.5 BETA                            **
**   By: JoomGallery::ProjectTeam                                             **
**   Copyright (C) 2009  Patrick Alt                                          **
**   Released under GNU GPL Public License                                    **
**   License: http://www.gnu.org/copyleft/gpl.html                            **
\******************************************************************************/
### Original copyright
/**
 * @version    $Id: joomeasycaptcha.php 2072 2010-04-15 08:16:57Z chraneco $
 * @package    Joomla
 * @subpackage  Content
 * @copyright  Copyright (C) 2005 - 2008 Open Source Matters. All rights reserved.
 * @license    GNU/GPL, see LICENSE.php
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');

jimport('joomla.plugin.plugin');

/**
 * JoomGallery EasyCaptcha Plugin
 *
 * @package    Joomla
 * @subpackage  Content
 * @since     1.5
 */
class plgJoomGalleryJoomEasyCaptcha extends JPlugin
{
  /**
   * Constructor
   *
   * For php4 compatability we must not use the __constructor as a constructor for plugins
   * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
   * This causes problems with cross-referencing necessary for the observer design pattern.
   *
   * @access  protected
   * @param   object    $subject  The object to observe
   * @param   object    $params   The object that holds the plugin parameters
   * @return  void
   * @since   1.5
   */
  function plgJoomGalleryJoomEasyCaptcha(&$subject, $params)
  {
    if(!file_exists(JPATH_ROOT.DS.'components'.DS.'com_easycaptcha'.DS.'class.easycaptcha.php'))
    {
      JError::raiseError(500, JText::_('EasyCaptcha seems not to be installed'));
    }

    parent::__construct($subject, $params);
  }

  /**
   * onJoomGetCaptcha method
   *
   * Method is called whenever spam protection is necessary in the gallery
   *
   * @access  public
   * @param   string  $ambit  A string which determines the ambit in which the captcha will be displayed (for example 'comments')
   * @return  string  The HTML output of the captcha
   * @since   1.5
   */
  function onJoomGetCaptcha($ambit = '')
  {
    $user = & JFactory::getUser();
    if($user->get('aid') > 0 && !$this->params->get('enabled_for'))
    {
      return '';
    }

    require_once(JPATH_ROOT.DS.'components'.DS.'com_easycaptcha'.DS.'class.easycaptcha.php');

    $captcha  = new easyCaptcha();
 
    $html = '
        <div class="jg_cmtl">
          &nbsp;
        </div>
        <div class="jg_cmtr">
          <img src="'.$captcha->getImageUrl().'" alt="'.$captcha->getAltText().'" border="0" id="jg_captcha_image" />
          <input type="hidden" name="jg_captcha_id" value="'.$captcha->getCaptchaId().'" />
        </div>
        <div class="jg_cmtl">
          '.JText::_('JGS_DETAIL_COMMENTS_ENTER_CODE').'&nbsp;
        </div>
        <div class="jg_cmtr">
          <input type="text" class="inputbox" value="" name="jg_captcha_code" />
          '.$captcha->getReloadButton('jg_captcha_image').'
          '.$captcha->getReloadCode().'
        </div>';

    return $html;
  }

  /**
   * onJoomCheckCaptcha method
   *
   * Method is called when a captcha should be validated
   *
   * @access  public
   * @param   string  $ambit  A string which determines the ambit in which the captcha will be displayed (for example 'comments')
   * @return  array   An array with result information, boolean false if a check isn't necessary in the context
   * @since   1.5
   */
  function onJoomCheckCaptcha($ambit = '')
  {
    $user = & JFactory::getUser();
    if($user->get('aid') > 0 && !$this->params->get('enabled_for'))
    {
      return false;
    }

    $code       = JRequest::getCmd('jg_captcha_code', '', 'post');
    $captcha_id = JRequest::getInt('jg_captcha_id', 0, 'post');

    require_once(JPATH_ROOT.DS.'components'.DS.'com_easycaptcha'.DS.'class.easycaptcha.php');

    $captcha    = new easyCaptcha($captcha_id);

    return array('valid' => $captcha->checkEnteredCode($code));
  }
}