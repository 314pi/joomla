<?php
/**
 * FW Gallery 1.6.1
 * @copyright (C) 2011 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );

JHTML :: _('behavior.formvalidation');
JHTML :: script('moorainbow'.(JFHelper :: isJoomla16()?'.1.2b2':'').'.js', 'administrator/components/com_fwgallery/assets/js/');

JToolBarHelper :: title(JText::_('Config').': <small><small>[ '.JText::_('Edit').' ]</small></small>', 'fwgallery-config.png' );
JToolBarHelper::save();
JToolBarHelper::cancel();
$color = $this->obj->params->get('gallery_color');
if (preg_match('/[0-9a-fA-F]{3,6}/', $color)) $color = '#'.$color;
else $color = '';
?>
<form action="index.php?option=com_fwgallery&amp;view=config" method="post" name="adminForm" id="adminForm" class="form-validate" enctype="multipart/form-data">
	<div id="settings1" style="width:40%;float:left;">
    <fieldset class="adminform">
        <legend><?php echo JText::_('Image settings'); ?></legend>
        <table class="admintable">
	        <tr>
	            <td title="<?php echo JText::_('Type the width for the thumbnails, that will suit your needs most'); ?>" class="key">
                    <?php echo JText::_('Thumb width'); ?> <span class="required">*</span>:
	            </td>
	            <td title="<?php echo JText::_('Type the width for the thumbnails, that will suit your needs most'); ?>">
					<input class="inputbox required validate-numeric" name="config[im_th_w]" value="<?php echo $this->obj->params->get('im_th_w', 160); ?>" size="5"/>
	            </td>
	        </tr>
	        <tr>
	            <td title="<?php echo JText::_('Type the height for the thumbnails, that will suit your needs most'); ?>" class="key">
                    <?php echo JText::_('Thumb height'); ?> <span class="required">*</span>:
	            </td>
	            <td title="<?php echo JText::_('Type the height for the thumbnails, that will suit your needs most'); ?>">
					<input class="inputbox required validate-numeric" name="config[im_th_h]" value="<?php echo $this->obj->params->get('im_th_h', 120); ?>" size="5"/>
	            </td>
	        </tr>
	        <tr>
	            <td title="<?php echo JText::_('The width for the medium size image during full screen view'); ?>" class="key">
                    <?php echo JText::_('Medium size width'); ?> <span class="required">*</span>:
	            </td>
	            <td title="<?php echo JText::_('The width for the medium size image during full screen view'); ?>">
					<input class="inputbox required validate-numeric" name="config[im_mid_w]" value="<?php echo $this->obj->params->get('im_mid_w', 340); ?>" size="5"/>
	            </td>
	        </tr>
	        <tr>
	            <td title="<?php echo JText::_('The height for the medium size image during full screen view'); ?>" class="key">
                    <?php echo JText::_('Medium size height'); ?> <span class="required">*</span>:
	            </td>
	            <td title="<?php echo JText::_('The height for the medium size image during full screen view'); ?>">
					<input class="inputbox required validate-numeric" name="config[im_mid_h]" value="<?php echo $this->obj->params->get('im_mid_h', 255); ?>" size="5"/>
	            </td>
	        </tr>
	        <tr>
	            <td title="<?php echo JText::_('The parameters of the image for lightbox effect view'); ?>" class="key">
                    <?php echo JText::_('Big size width'); ?> <span class="required">*</span>:
	            </td>
	            <td title="<?php echo JText::_('The parameters of the image for lightbox effect view'); ?>">
					<input class="inputbox required validate-numeric" name="config[im_max_w]" value="<?php echo $this->obj->params->get('im_max_w', 800); ?>" size="5"/>
	            </td>
	        </tr>
	        <tr>
	            <td title="<?php echo JText::_('The parameters of the image for lightbox effect view'); ?>" class="key">
                    <?php echo JText::_('Big size height'); ?> <span class="required">*</span>:
	            </td>
	            <td title="<?php echo JText::_('The parameters of the image for lightbox effect view'); ?>">
					<input class="inputbox required validate-numeric" name="config[im_max_h]" value="<?php echo $this->obj->params->get('im_max_h', 600); ?>" size="5"/>
	            </td>
	        </tr>
	        <tr>
	            <td title="" class="key">
                    <?php echo JText::_('Thumb and Medium images shrinking method'); ?>:
	            </td>
	            <td title="">
					<?php echo JHTML :: _('select.booleanlist', 'config[im_just_shrink]', '', $this->obj->params->get('im_just_shrink'), JText :: _('Just shrink'), JText :: _('Shrink and cut')); ?>
	            </td>
	        </tr>
	        <tr>
	            <td title="<?php echo JText::_('The frame for the gallery default image. It should be at least 20px bigger than the images\' size'); ?>" class="key">
                    <?php echo JText::_('Gallery box width'); ?>:
	            </td>
	            <td title="<?php echo JText::_('The frame for the gallery default image. It should be at least 20px bigger than the images\' size'); ?>">
					<input class="inputbox validate-numeric" name="config[gallery_box_width]" value="<?php echo $this->obj->params->get('gallery_box_width'); ?>" size="5"/> <?php echo JText :: _('px'); ?>
	            </td>
	        </tr>
	        <tr>
	            <td title="<?php echo JText::_('The frame for the gallery images. It should be at least 20 px bigger than the images\' size'); ?>" class="key">
                    <?php echo JText::_('Image box width'); ?>:
	            </td>
	            <td title="<?php echo JText::_('The frame for the gallery images. It should be at least 20 px bigger than the images\' size'); ?>">
					<input class="inputbox validate-numeric" name="config[image_box_width]" value="<?php echo $this->obj->params->get('image_box_width'); ?>" size="5"/> <?php echo JText :: _('px'); ?>
	            </td>
	        </tr>
	    </table>
    </fieldset>

    <fieldset class="adminform">
        <legend><?php echo JText::_('Layout settings'); ?></legend>
        <table class="admintable">
	        <tr>
	            <td title="<?php echo JText :: _('Select any color from the color palette or just type the color\'s code, if you know it'); ?>" class="key">
                    <?php echo JText::_('Galleries default color'); ?>:
	            </td>
	            <td title="<?php echo JText :: _('Select any color from the color palette or just type the color\'s code, if you know it'); ?>" id="color-row"<?php if ($color) { ?> style="background-color:<?php echo $color; ?>"<?php } ?>>
					<img id="myRainbow" src="<?php echo JURI :: root(true); ?>/administrator/components/com_fwgallery/assets/images/rainbow.png" alt="[r]" width="16" height="16" />
					<input id="color" name="config[gallery_color]" type="text" size="13" value="<?php echo $color; ?>" />
					<button type="button" id="myRainbowButton"><?php echo JText :: _('Select'); ?></button>
					<button type="button" id="myRainbowClearButton"><?php echo JText :: _('Clear'); ?></button>
	            </td>
	        </tr>
	        <tr>
	            <td title="<?php echo JText :: _('The number depends on the thumb sizes and the template of your site. Obligatory field'); ?>" class="key">
                    <?php echo JText::_('Galleries in a row'); ?> <span class="required">*</span>:
	            </td>
	            <td title="<?php echo JText :: _('The number depends on the thumb sizes and the template of your site. Obligatory field'); ?>">
					<input class="inputbox required validate-numeric" name="config[galleries_a_row]" value="<?php echo $this->obj->params->get('galleries_a_row', 3); ?>" size="5"/>
	            </td>
	        </tr>
	        <tr>
	            <td title="<?php echo JText :: _('The number depends on the thumb sizes and the template of your site. Obligatory field'); ?>" class="key">
                    <?php echo JText::_('Images in a row'); ?> <span class="required">*</span>:
	            </td>
	            <td title="<?php echo JText :: _('The number depends on the thumb sizes and the template of your site. Obligatory field'); ?>">
					<input class="inputbox required validate-numeric" name="config[images_a_row]" value="<?php echo $this->obj->params->get('images_a_row', 3); ?>" size="5"/>
	            </td>
	        </tr>
	        <tr>
	            <td title="<?php echo JText::_('Type the number of galleries, you want to be displayed per page'); ?>" class="key">
                    <?php echo JText::_('Galleries per page'); ?>:
	            </td>
	            <td title="<?php echo JText::_('Type the number of galleries, you want to be displayed per page'); ?>">
					<input class="inputbox required validate-numeric" name="config[galleries_limit]" value="<?php echo $this->obj->params->get('galleries_limit', 20); ?>" size="5"/>
	            </td>
	        </tr>
	        <tr>
	            <td title="<?php echo JText::_('Type the number of images you want to be displayed per page'); ?>" class="key">
                    <?php echo JText::_('Images per page'); ?>:
	            </td>
	            <td title="<?php echo JText::_('Type the number of images you want to be displayed per page'); ?>">
					<input class="inputbox required validate-numeric" name="config[images_limit]" value="<?php echo $this->obj->params->get('images_limit', 20); ?>" size="5"/>
	            </td>
	        </tr>
	        <tr>
	            <td title="<?php echo JText::_('Select one of the four galleries\' order types. This option is available on front-end too'); ?>" class="key">
                    <?php echo JText::_('Default galleries ordering'); ?>:
	            </td>
	            <td title="<?php echo JText::_('Select one of the four galleries\' order types. This option is available on front-end too'); ?>">
					<?php echo JHTML :: _('select.genericlist', array(
						JHTML :: _('select.option', 'name', JText :: _('Alphabetically'), 'id', 'name'),
						JHTML :: _('select.option', 'new', JText :: _('Newest First'), 'id', 'name'),
						JHTML :: _('select.option', 'old', JText :: _('Oldest First'), 'id', 'name'),
						JHTML :: _('select.option', 'order', JText :: _('Ordering'), 'id', 'name')
					), 'config[ordering_galleries]', '', 'id', 'name', $this->obj->params->get('ordering_galleries', 'order')); ?>
	            </td>
	        </tr>
	        <tr>
	            <td title="<?php echo JText::_('Select one of the four possible types of order for images. The option is available on front-end too'); ?>" class="key">
                    <?php echo JText::_('Default images ordering'); ?>:
	            </td>
	            <td title="<?php echo JText::_('Select one of the four possible types of order for images. The option is available on front-end too'); ?>">
					<?php echo JHTML :: _('select.genericlist', array(
						JHTML :: _('select.option', 'name', JText :: _('Alphabetically'), 'id', 'name'),
						JHTML :: _('select.option', 'new', JText :: _('Newest First'), 'id', 'name'),
						JHTML :: _('select.option', 'old', JText :: _('Oldest First'), 'id', 'name'),
						JHTML :: _('select.option', 'order', JText :: _('Ordering'), 'id', 'name')
					), 'config[ordering_images]', '', 'id', 'name', $this->obj->params->get('ordering_images', 'order')); ?>
	            </td>
	        </tr>
	    </table>
    </fieldset>

    <fieldset class="adminform">
        <legend><?php echo JText::_('Watermark'); ?></legend>
        <table class="admintable">
	        <tr>
	            <td title="<?php echo JText::_('Yes\No option. If you don\'t want to use it, then select &quot;No&quot; here'); ?>" class="key">
                    <?php echo JText::_('Use watermark'); ?>:
	            </td>
	            <td title="<?php echo JText::_('Yes\No option. If you don\'t want to use it, then select &quot;No&quot; here'); ?>">
					<?php echo JHTML :: _('select.booleanlist', 'config[use_watermark]', '', $this->obj->params->get('use_watermark')); ?>
	            </td>
	        </tr>
	        <tr>
	            <td title="<?php echo JText::_('Select one of the 5 possible locations of the watermark sign on images'); ?>" class="key">
                    <?php echo JText::_('Watermark position'); ?>:
	            </td>
	            <td title="<?php echo JText::_('Select one of the 5 possible locations of the watermark sign on images'); ?>">
					<?php echo JHTML :: _('select.genericlist', array(
						JHTML :: _('select.option', 'center', JText :: _('center'), 'id', 'name'),
						JHTML :: _('select.option', 'left top', JText :: _('left top'), 'id', 'name'),
						JHTML :: _('select.option', 'right top', JText :: _('right top'), 'id', 'name'),
						JHTML :: _('select.option', 'left bottom', JText :: _('left bottom'), 'id', 'name'),
						JHTML :: _('select.option', 'right bottom', JText :: _('right bottom'), 'id', 'name')
					), 'config[watermark_position]', '', 'id', 'name', $this->obj->params->get('watermark_position', 'left bottom')); ?>
	            </td>
	        </tr>
	        <tr>
	            <td title="<?php echo JText::_('Upload a file, that will be used as a watermark on images'); ?>" class="key">
                    <?php echo JText::_('Watermark file'); ?>:
	            </td>
	            <td title="<?php echo JText::_('Upload a file, that will be used as a watermark on images'); ?>">
<?php
if ($this->obj->params->get('watermark_file')) {
	if ($path = JFHelper :: getWatermarkFilename()) {
?>
					<img src="<?php echo JURI :: root(true); ?>/<?php echo $path; ?>" /><br/>
					<input type="checkbox" name="delete_watermark" value="1" /> <?php echo JText :: _('Remove watermark'); ?><br/>
<?php
	} else {
?>
					<p style="color:#f00;"><?php echo JText :: _('Watermark file not found!'); ?></p>
<?php
	}
}
?>
					<input id="watermark_file" type="file" class="inputbox" name="watermark_file" />
	            </td>
	        </tr>
	        <tr>
	            <td title="<?php echo JText::_('Type a text, that will be used as a watermark. If you upload a file, then text won\'t be displayed'); ?>" class="key">
                    <?php echo JText::_('Watermark text'); ?>:
	            </td>
	            <td title="<?php echo JText::_('Type a text, that will be used as a watermark. If you upload a file, then text won\'t be displayed'); ?>">
					<input class="inputbox" name="config[watermark_text]" value="<?php echo $this->obj->params->get('watermark_text'); ?>" size="35"/>
	            </td>
	        </tr>
		</table>
	</fieldset>

    <fieldset class="adminform">
        <legend><?php echo JText::_('Voting system'); ?></legend>
        <table class="admintable">
	        <tr>
	            <td title="<?php echo JText::_('Yes\No option. Select &quot;No&quot; if you don\'t want to use voting at all'); ?>" class="key">
                    <?php echo JText::_('Use Voting'); ?>:
	            </td>
	            <td title="<?php echo JText::_('Yes\No option. Select &quot;No&quot; if you don\'t want to use voting at all'); ?>">
					<?php echo JHTML :: _('select.booleanlist', 'config[use_voting]', '', $this->obj->params->get('use_voting')); ?>
	            </td>
	        </tr>
	        <tr>
	            <td title="<?php echo JText::_('Let the visitors of your site take part in public polls and vote for the best image. With public voting all the visitors of your site will be able to vote, without it-registered users only'); ?>" class="key">
                    <?php echo JText::_('Public voting'); ?>:
	            </td>
	            <td title="<?php echo JText::_('Let the visitors of your site take part in public polls and vote for the best image. With public voting all the visitors of your site will be able to vote, without it-registered users only'); ?>">
					<?php echo JHTML :: _('select.booleanlist', 'config[public_voting]', '', $this->obj->params->get('public_voting')); ?>
	            </td>
	        </tr>
		</table>
	</fieldset>
	</div>

	<div id="settings2" style="width:30%;float:left;">
    <fieldset class="adminform">
        <legend><?php echo JText::_('Displaying settings'); ?></legend>
        <table class="admintable">
	        <tr>
	            <td title="<?php echo JText::_('Yes\No option. Select &quot;No&quot;, if you want to hide it'); ?>" class="key">
                    <?php echo JText::_('Display Total galleries counter'); ?>:
	            </td>
	            <td title="<?php echo JText::_('Yes\No option. Select &quot;No&quot;, if you want to hide it'); ?>">
					<?php echo JHTML :: _('select.booleanlist', 'config[display_total_galleries]', '', $this->obj->params->get('display_total_galleries')); ?>
	            </td>
	        </tr>
	        <tr>
	            <td title="<?php echo JText::_('Yes\No option. Select &quot;No&quot;, if you want to hide it'); ?>" class="key">
                    <?php echo JText::_('Show "Display Limit" option for list of galleries'); ?>:
	            </td>
	            <td title="<?php echo JText::_('Yes\No option. Select &quot;No&quot;, if you want to hide it'); ?>">
					<?php echo JHTML :: _('select.booleanlist', 'config[display_galleries_limit_selector]', '', $this->obj->params->get('display_galleries_limit_selector')); ?>
	            </td>
	        </tr>
	        <tr>
	            <td title="<?php echo JText::_('Yes\No option. Select &quot;No&quot;, if you want to hide it'); ?>" class="key">
                    <?php echo JText::_('Show "Display Limit" option for single gallery'); ?>:
	            </td>
	            <td title="<?php echo JText::_('Yes\No option. Select &quot;No&quot;, if you want to hide it'); ?>">
					<?php echo JHTML :: _('select.booleanlist', 'config[display_gallery_limit_selector]', '', $this->obj->params->get('display_gallery_limit_selector')); ?>
	            </td>
	        </tr>
	        <tr>
	            <td title="<?php echo JText::_('Yes\No option. Select &quot;No&quot;, if you want to hide it'); ?>" class="key">
                    <?php echo JText::_('Display gallery owner name'); ?>:
	            </td>
	            <td title="<?php echo JText::_('Yes\No option. Select &quot;No&quot;, if you want to hide it'); ?>">
					<?php echo JHTML :: _('select.booleanlist', 'config[display_owner_gallery]', '', $this->obj->params->get('display_owner_gallery')); ?>
	            </td>
	        </tr>
	        <tr>
	            <td title="<?php echo JText::_('Yes\No option. Select &quot;No&quot;, if you want to hide it'); ?>" class="key">
                    <?php echo JText::_('Display image owner name'); ?>:
	            </td>
	            <td title="<?php echo JText::_('Yes\No option. Select &quot;No&quot;, if you want to hide it'); ?>">
					<?php echo JHTML :: _('select.booleanlist', 'config[display_owner_image]', '', $this->obj->params->get('display_owner_image')); ?>
	            </td>
	        </tr>
	        <tr>
	            <td title="<?php echo JText::_('Show or hide the creation date of the gallery, by selecting Yes\No'); ?>" class="key">
                    <?php echo JText::_('Display gallery date'); ?>:
	            </td>
	            <td title="<?php echo JText::_('Show or hide the creation date of the gallery, by selecting Yes\No'); ?>">
					<?php echo JHTML :: _('select.booleanlist', 'config[display_date_gallery]', '', $this->obj->params->get('display_date_gallery')); ?>
	            </td>
	        </tr>
	        <tr>
	            <td title="<?php echo JText::_('Yes\No option. Select &quot;No&quot;, if you want to hide it in the front-end'); ?>" class="key">
                    <?php echo JText::_('Display Order by option'); ?>:
	            </td>
	            <td title="<?php echo JText::_('Yes\No option. Select &quot;No&quot;, if you want to hide it in the front-end'); ?>">
					<?php echo JHTML :: _('select.booleanlist', 'config[display_gallery_sorting]', '', $this->obj->params->get('display_gallery_sorting')); ?>
	            </td>
	        </tr>
	        <tr>
	            <td title="<?php echo JText::_('Show or hide the name of the gallery, clicking Yes\No'); ?>" class="key">
                    <?php echo JText::_('Display gallery name'); ?>:
	            </td>
	            <td title="<?php echo JText::_('Show or hide the name of the gallery, clicking Yes\No'); ?>">
					<?php echo JHTML :: _('select.booleanlist', 'config[display_name_gallery]', '', $this->obj->params->get('display_name_gallery')); ?>
	            </td>
	        </tr>
	        <tr>
	            <td title="<?php echo JText::_('Show or hide the name of the images\' adding to the gallery, clicking Yes\No'); ?>" class="key">
                    <?php echo JText::_('Display image name'); ?>:
	            </td>
	            <td title="<?php echo JText::_('Show or hide the name of the images\' adding to the gallery, clicking Yes\No'); ?>">
					<?php echo JHTML :: _('select.booleanlist', 'config[display_name_image]', '', $this->obj->params->get('display_name_image')); ?>
	            </td>
	        </tr>
	        <tr>
	            <td title="<?php echo JText::_('Show or hide the date of the images\' adding to the gallery, clicking Yes\No'); ?>" class="key">
                    <?php echo JText::_('Display image date'); ?>:
	            </td>
	            <td title="<?php echo JText::_('Show or hide the date of the images\' adding to the gallery, clicking Yes\No'); ?>">
					<?php echo JHTML :: _('select.booleanlist', 'config[display_date_image]', '', $this->obj->params->get('display_date_image')); ?>
	            </td>
	        </tr>
	        <tr>
	            <td title="<?php echo JText::_('Show or hide the number of image views, selecting Yes\No options'); ?>" class="key">
                    <?php echo JText::_('Display image views'); ?>:
	            </td>
	            <td title="<?php echo JText::_('Show or hide the number of image views, selecting Yes\No options'); ?>">
					<?php echo JHTML :: _('select.booleanlist', 'config[display_image_views]', '', $this->obj->params->get('display_image_views')); ?>
	            </td>
	        </tr>
	        <tr>
	            <td title="<?php echo JText::_('Show or hide users copyright selecting Yes\No'); ?>" class="key">
                    <?php echo JText::_('Display users copyright'); ?>:
	            </td>
	            <td title="<?php echo JText::_('Show or hide users copyright selecting Yes\No'); ?>">
					<?php echo JHTML :: _('select.booleanlist', 'config[display_user_copyright]', '', $this->obj->params->get('display_user_copyright')); ?>
	            </td>
	        </tr>
	        <tr>
	            <td title="<?php echo JText::_('Set a suitable date format for the front-end: month, day and year'); ?>" class="key">
                    <?php echo JText::_('Date format'); ?>
	            </td>
	            <td title="<?php echo JText::_('Set a suitable date format for the front-end: month, day and year'); ?>">
					<input lass="inputbox" name="config[date_format]" value="<?php echo $this->obj->params->get('date_format', '%B %d, %Y'); ?>" size="15"/>
					&nbsp;<a href="http://docs.joomla.org/How_do_you_change_the_date_format%3F" target="_blank"><?php echo JText::_('Date options'); ?></a>
	            </td>
	        </tr>
	        <tr>
	            <td title="<?php echo JText::_('The number of days, when added image will have the icon &quot;New&quot; in the left top'); ?>" class="key">
                    <?php echo JText::_('Display icon New'); ?>:
	            </td>
	            <td title="<?php echo JText::_('The number of days, when added image will have the icon &quot;New&quot; in the left top'); ?>">
					<input class="inputbox" name="config[new_days]" value="<?php echo $this->obj->params->get('new_days', 7); ?>" size="5"/>
	            </td>
	        </tr>
	        <tr>
	            <td class="key">
                    <?php echo JText::_('Hide mignifier (lightbox effect)'); ?>:
	            </td>
	            <td>
					<?php echo JHTML :: _('select.booleanlist', 'config[hide_mignifier]', '', $this->obj->params->get('hide_mignifier')); ?>
	            </td>
	        </tr>
	        <tr>
	            <td title="<?php echo JText::_('If you don\'t want to display fastw3b copyright on the front-end of your website, then select &quot;No&quot; here'); ?>" class="key">
                    <?php echo JText::_('Hide Fastw3b copyright'); ?>:
	            </td>
	            <td title="<?php echo JText::_('If you don\'t want to display fastw3b copyright on the front-end of your website, then select &quot;No&quot; here'); ?>">
					<?php echo JHTML :: _('select.booleanlist', 'config[hide_fw_copyright]', '', $this->obj->params->get('hide_fw_copyright')); ?>
					<div id="fw-copyright-donation" style="display:none">
						<?php echo JText :: _('FWGALLERY_COPYRIGHT_HIDE'); ?>
					</div>
	            </td>
	        </tr>
		</table>
	</fieldset>
	</div>
	<div style="clear:both;"></div>
	<input type="hidden" name="task" value="" />
</form>
<script type="text/javascript">
var copyrightEff;
var fwgRainbow;

<?php
if (JFHelper :: isJoomla16()) {
?>
Fx.Slide=new Class({Extends:Fx,options:{mode:"vertical"},initialize:function(B,A){this.addEvent("complete",function(){this.open=(this.wrapper["offset"+this.layout.capitalize()]!=0);
if(this.open&&Browser.Engine.webkit419){this.element.dispose().inject(this.wrapper);}},true);this.element=this.subject=$(B);this.parent(A);var C=this.element.retrieve("wrapper");
this.wrapper=C||new Element("div",{styles:$extend(this.element.getStyles("margin","position"),{overflow:"hidden"})}).wraps(this.element);this.element.store("wrapper",this.wrapper).setStyle("margin",0);
this.now=[];this.open=true;},vertical:function(){this.margin="margin-top";this.layout="height";this.offset=this.element.offsetHeight;},horizontal:function(){this.margin="margin-left";
this.layout="width";this.offset=this.element.offsetWidth;},set:function(A){this.element.setStyle(this.margin,A[0]);this.wrapper.setStyle(this.layout,A[1]);
return this;},compute:function(E,D,C){var B=[];var A=2;A.times(function(F){B[F]=Fx.compute(E[F],D[F],C);});return B;},start:function(B,E){if(!this.check(arguments.callee,B,E)){return this;
}this[E||this.options.mode]();var D=this.element.getStyle(this.margin).toInt();var C=this.wrapper.getStyle(this.layout).toInt();var A=[[D,C],[0,this.offset]];
var G=[[D,C],[-this.offset,0]];var F;switch(B){case"in":F=A;break;case"out":F=G;break;case"toggle":F=(this.wrapper["offset"+this.layout.capitalize()]==0)?A:G;
}return this.parent(F[0],F[1]);},slideIn:function(A){return this.start("in",A);},slideOut:function(A){return this.start("out",A);},hide:function(A){this[A||this.options.mode]();
this.open=false;return this.set([-this.offset,0]);},show:function(A){this[A||this.options.mode]();this.open=true;return this.set([0,this.offset]);},toggle:function(A){return this.start("toggle",A);
}});Element.Properties.slide={set:function(B){var A=this.retrieve("slide");if(A){A.cancel();}return this.eliminate("slide").store("slide:options",$extend({link:"cancel"},B));
},get:function(A){if(A||!this.retrieve("slide")){if(A||!this.retrieve("slide:options")){this.set("slide",A);}this.store("slide",new Fx.Slide(this,this.retrieve("slide:options")));
}return this.retrieve("slide");}};Element.implement({slide:function(D,E){D=D||"toggle";var B=this.get("slide"),A;switch(D){case"hide":B.hide(E);break;case"show":B.show(E);
break;case"toggle":var C=this.retrieve("slide:flag",B.open);B[(C)?"slideOut":"slideIn"](E);this.store("slide:flag",!C);A=true;break;default:B.start(D,E);
}if(!A){this.eliminate("slide:flag");}return this;}});
<?php
}
?>
window.addEvent('domready', function() {
	$('myRainbowButton').addEvent('click', function(ev) {
		$('myRainbow').fireEvent('click', ev);
	});
	$('myRainbowClearButton').addEvent('click', function(ev) {
		$('color').value = '';
		$('color-row').setStyle('background-color', '');
	});
	$('color').addEvent('keyup', function() {
		if (this.value.match(/^#[0-9a-fA-F]{3,6}$/)) {
			$('color-row').setStyle('background-color', this.value);
			fwgRainbow.manualSet(this.value, 'hex');
		} else {
			$('color-row').setStyle('background-color', '');
		}
	});
	fwgRainbow = new MooRainbow('myRainbow', {
		wheel: true,
		imgPath: '<?php echo JURI :: root(true); ?>/administrator/components/com_fwgallery/assets/images/',
		onChange: function(color) {
			$('color').value = color.hex;
			$('color-row').setStyle('background-color', color.hex);
		},
		onComplete: function(color) {
			$('color').value = color.hex;
			$('color-row').setStyle('background-color', color.hex);
		}
	});
<?php
if ($color) {
?>
	fwgRainbow.manualSet('<?php echo $color; ?>', 'hex');
<?php
}
?>
	$('fw-copyright-donation').setStyle('display', '');
	$$('#adminForm input').each(function (el) {
		if (el.name == 'config[hide_fw_copyright]') {
			el.addEvent('click', check_copyright);
			el.addEvent('change', check_copyright);
		}
	});
	copyrightEff = new Fx.Slide('fw-copyright-donation');
	copyrightEff.hide();
	check_copyright();
});
function check_copyright() {
	$$('#adminForm input').each(function (el) {
		if (el.name == 'config[hide_fw_copyright]' && el.checked) {
			if (el.value == '0') copyrightEff.slideOut();
			else copyrightEff.slideIn()
		}
	});
}
function submitbutton(task) {
	if (task == 'save') {
		if (!document.formvalidator.isValid($('adminForm'))) {
			alert('<?php echo JText :: _('Not all required fields properly filled in'); ?>');
			return;
		}
		if ($('watermark_file') && $('watermark_file').value && !$('watermark_file').value.match(/\.png|gif$/i)) {
			alert('<?php echo JText :: _('Allowed PNG and GIF files as watermark images only'); ?>');
			return;
		}
	}
	$('adminForm').task.value = task;
	$('adminForm').submit();
}
</script>