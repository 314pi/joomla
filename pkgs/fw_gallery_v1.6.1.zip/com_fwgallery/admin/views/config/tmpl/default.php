<?php
/**
 * FW Gallery 1.6.1
 * @copyright (C) 2011 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );
JToolBarHelper :: title(JText::_('Config'), 'fwgallery-config.png' );
JToolBarHelper :: custom('edit', 'edit', 'edit', 'edit', false);

if (!file_exists(FWG_STORAGE_PATH) and !is_writable(JPATH_SITE.'/images')) {
?>
<p style="color:#f00;"><?php echo JText :: sprintf('Images folder %s is not writable!', JPATH_SITE.DS.'images') ?></p>
<?php
}
if (file_exists(FWG_STORAGE_PATH) and !is_writable(FWG_STORAGE_PATH)) {
?>
<p style="color:#f00;"><?php echo JText :: sprintf('Images folder %s is not writable!', FWG_STORAGE_PATH) ?></p>
<?php
}
?>
<form action="index.php?option=com_fwgallery&amp;view=config" method="post" name="adminForm" id="adminForm">

	<div id="settings1" style="width:30%;float:left;">
    <fieldset class="adminform">
        <legend><?php echo JText::_('Image settings'); ?></legend>
        <table class="admintable">
	        <tr>
	            <td class="key">
                    <?php echo JText::_('Thumb width'); ?>:
	            </td>
	            <td>
					<?php echo $this->obj->params->get('im_th_w'); ?><?php echo JText :: _('px'); ?>
	            </td>
	        </tr>
	        <tr>
	            <td class="key">
                    <?php echo JText::_('Thumb height'); ?>:
	            </td>
	            <td>
					<?php echo $this->obj->params->get('im_th_h'); ?><?php echo JText :: _('px'); ?>
	            </td>
	        </tr>
	        <tr>
	            <td class="key">
                    <?php echo JText::_('Medium size width'); ?>:
	            </td>
	            <td>
					<?php echo $this->obj->params->get('im_mid_w'); ?><?php echo JText :: _('px'); ?>
	            </td>
	        </tr>
	        <tr>
	            <td class="key">
                    <?php echo JText::_('Medium size height'); ?>:
	            </td>
	            <td>
					<?php echo $this->obj->params->get('im_mid_h'); ?><?php echo JText :: _('px'); ?>
	            </td>
	        </tr>
	        <tr>
	            <td class="key">
                    <?php echo JText::_('Big size width'); ?>:
	            </td>
	            <td>
					<?php echo $this->obj->params->get('im_max_w'); ?><?php echo JText :: _('px'); ?>
	            </td>
	        </tr>
	        <tr>
	            <td class="key">
                    <?php echo JText::_('Big size height'); ?>:
	            </td>
	            <td>
					<?php echo $this->obj->params->get('im_max_h'); ?><?php echo JText :: _('px'); ?>
	            </td>
	        </tr>
	        <tr>
	            <td title="" class="key">
                    <?php echo JText::_('Thumb and Medium images shrinking method'); ?>:
	            </td>
	            <td title="">
					<?php echo JText :: _($this->obj->params->get('im_just_shrink')?'Just shrink':'Shrink and cut'); ?>
	            </td>
	        </tr>
	        <tr>
	            <td class="key">
                    <?php echo JText::_('Gallery box width'); ?>:
	            </td>
	            <td>
					<?php if ($gallery_box_width = $this->obj->params->get('gallery_box_width')) echo $gallery_box_width.JText :: _('px'); else echo JText :: _('auto'); ?>
	            </td>
	        </tr>
	        <tr>
	            <td class="key">
                    <?php echo JText::_('Image box width'); ?>:
	            </td>
	            <td>
					<?php if ($image_box_width = $this->obj->params->get('image_box_width')) echo $image_box_width.JText :: _('px'); else echo JText :: _('auto'); ?>
	            </td>
	        </tr>
	    </table>
    </fieldset>
    <fieldset class="adminform">
        <legend><?php echo JText::_('Layout settings'); ?></legend>
        <table class="admintable">
	        <tr>
	            <td class="key">
                    <?php echo JText::_('Galleries default color'); ?>:
	            </td>
	            <td>
					<div class="fwg-gallery-color"<?php if ($color = $this->obj->params->get('gallery_color')) { ?> style="background-color:#<?php echo $color; ?>"<?php } ?>></div>
	            </td>
	        </tr>
	        <tr>
	            <td class="key">
                    <?php echo JText::_('Galleries in a row'); ?>:
	            </td>
	            <td>
					<?php echo $this->obj->params->get('galleries_a_row'); ?>
	            </td>
	        </tr>
	        <tr>
	            <td class="key">
                    <?php echo JText::_('Images in a row'); ?>:
	            </td>
	            <td>
					<?php echo $this->obj->params->get('images_a_row'); ?>
	            </td>
	        </tr>

	        <tr>
	            <td class="key">
                    <?php echo JText::_('Galleries per page'); ?>:
	            </td>
	            <td>
					<?php echo $this->obj->params->get('galleries_limit'); ?>
	            </td>
	        </tr>
	        <tr>
	            <td class="key">
                    <?php echo JText::_('Images per page'); ?>:
	            </td>
	            <td>
					<?php echo $this->obj->params->get('images_limit'); ?>
	            </td>
	        </tr>

	        <tr>
	            <td class="key">
                    <?php echo JText::_('Default galleries ordering'); ?>:
	            </td>
	            <td>
					<?php echo JText :: _('FWG_ORDERING_'.$this->obj->params->get('ordering_galleries', 'order')); ?>
	            </td>
	        </tr>
	        <tr>
	            <td class="key">
                    <?php echo JText::_('Default images ordering'); ?>:
	            </td>
	            <td>
					<?php echo JText :: _('FWG_ORDERING_'.$this->obj->params->get('ordering_images', 'order')); ?>
	            </td>
	        </tr>
	    </table>
    </fieldset>
    <fieldset class="adminform">
        <legend><?php echo JText::_('Watermark'); ?></legend>
        <table class="admintable">
	        <tr>
	            <td class="key">
                    <?php echo JText::_('Use watermark'); ?>:
	            </td>
	            <td>
					<?php echo JText :: _($this->obj->params->get('use_watermark')?'Yes':'No'); ?>
	            </td>
	        </tr>
	        <tr>
	            <td class="key">
                    <?php echo JText::_('Watermark position'); ?>:
	            </td>
	            <td>
					<?php echo JText :: _($this->obj->params->get('watermark_position', 'left bottom')); ?>
	            </td>
	        </tr>
	        <tr>
	            <td class="key">
                    <?php echo JText::_('Watermark file'); ?>:
	            </td>
	            <td>
<?php
if ($this->obj->params->get('watermark_file')) {
	if ($path = JFHelper :: getWatermarkFilename()) {
?>
					<img src="<?php echo JURI :: root(true); ?>/<?php echo $path; ?>" /><br/>
<?php
	} else {
?>
					<p style="color:#f00;"><?php echo JText :: _('Watermark file not found!'); ?></p>
<?php
	}
}
?>
	            </td>
	        </tr>
	        <tr>
	            <td class="key">
                    <?php echo JText::_('Watermark text'); ?>:
	            </td>
	            <td>
					<?php echo $this->obj->params->get('watermark_text'); ?>
	            </td>
	        </tr>
		</table>
	</fieldset>
    <fieldset class="adminform">
        <legend><?php echo JText::_('Voting system'); ?></legend>
        <table class="admintable">
	        <tr>
	            <td class="key">
                    <?php echo JText::_('Use Voting'); ?>:
	            </td>
	            <td>
					<?php echo JText :: _($this->obj->params->get('use_voting')?'Yes':'No'); ?>
	            </td>
	        </tr>
	        <tr>
	            <td class="key">
                    <?php echo JText::_('Public voting'); ?>:
	            </td>
	            <td>
					<?php echo JText :: _($this->obj->params->get('public_voting')?'Yes':'No'); ?>
	            </td>
	        </tr>
		</table>
	</fieldset>
	</div>

	<div id="settings2" style="width:30%;float:left;">
    <fieldset class="adminform">
        <legend><?php echo JText::_('Displaying settings'); ?></legend>
        <table class="admintable">
	        <tr>
	            <td class="key">
                    <?php echo JText::_('Display Total galleries counter'); ?>:
	            </td>
	            <td>
					<?php echo JText :: _($this->obj->params->get('display_total_galleries')?'Yes':'No'); ?>
	            </td>
	        </tr>
	        <tr>
	            <td class="key">
                    <?php echo JText::_('Show "Display Limit" option for list of galleries'); ?>:
	            </td>
	            <td>
					<?php echo JText :: _($this->obj->params->get('display_galleries_limit_selector')?'Yes':'No'); ?>
	            </td>
	        </tr>
	        <tr>
	            <td class="key">
                    <?php echo JText::_('Show "Display Limit" option for single gallery'); ?>:
	            </td>
	            <td>
					<?php echo JText :: _($this->obj->params->get('display_gallery_limit_selector')?'Yes':'No'); ?>
	            </td>
	        </tr>
	        <tr>
	            <td class="key">
                    <?php echo JText::_('Display gallery owner name'); ?>:
	            </td>
	            <td>
					<?php echo JText :: _($this->obj->params->get('display_owner_gallery')?'Yes':'No'); ?>
	            </td>
	        </tr>
	        <tr>
	            <td class="key">
                    <?php echo JText::_('Display image owner name'); ?>:
	            </td>
	            <td>
					<?php echo JText :: _($this->obj->params->get('display_owner_image')?'Yes':'No'); ?>
	            </td>
	        </tr>
	        <tr>
	            <td class="key">
                    <?php echo JText::_('Display gallery date'); ?>:
	            </td>
	            <td>
					<?php echo JText :: _($this->obj->params->get('display_date_gallery')?'Yes':'No'); ?>
	            </td>
	        </tr>
	        <tr>
	            <td class="key">
                    <?php echo JText::_('Display Order by option'); ?>:
	            </td>
	            <td>
					<?php echo JText :: _($this->obj->params->get('display_gallery_sorting')?'Yes':'No'); ?>
	            </td>
	        </tr>
	        <tr>
	            <td class="key">
                    <?php echo JText::_('Display gallery name'); ?>:
	            </td>
	            <td>
					<?php echo JText :: _($this->obj->params->get('display_name_gallery')?'Yes':'No'); ?>
	            </td>
	        </tr>
	        <tr>
	            <td class="key">
                    <?php echo JText::_('Display image name'); ?>:
	            </td>
	            <td>
					<?php echo JText :: _($this->obj->params->get('display_name_image')?'Yes':'No'); ?>
	            </td>
	        </tr>
	        <tr>
	            <td class="key">
                    <?php echo JText::_('Display image date'); ?>:
	            </td>
	            <td>
					<?php echo JText :: _($this->obj->params->get('display_date_image')?'Yes':'No'); ?>
	            </td>
	        </tr>
	        <tr>
	            <td class="key">
                    <?php echo JText::_('Display image views'); ?>:
	            </td>
	            <td>
					<?php echo JText :: _($this->obj->params->get('display_image_views')?'Yes':'No'); ?>
	            </td>
	        </tr>
	        <tr>
	            <td class="key">
                    <?php echo JText::_('Display users copyright'); ?>:
	            </td>
	            <td>
					<?php echo JText :: _($this->obj->params->get('display_user_copyright')?'Yes':'No'); ?>
	            </td>
	        </tr>
	        <tr>
	            <td class="key">
                    <?php echo JText::_('Date format'); ?>:
	            </td>
	            <td>
					<?php echo $this->obj->params->get('date_format'); ?>
					&nbsp;<a href="http://docs.joomla.org/How_do_you_change_the_date_format%3F" target="_blank"><?php echo JText :: _('Date options'); ?></a>
	            </td>
	        </tr>
	        <tr>
	            <td class="key">
                    <?php echo JText::_('Display icon New'); ?>:
	            </td>
	            <td>
					<?php echo $this->obj->params->get('new_days'); ?>
	            </td>
	        </tr>
	        <tr>
	            <td class="key">
                    <?php echo JText::_('Hide mignifier (lightbox effect)'); ?>:
	            </td>
	            <td>
					<?php echo JText :: _($this->obj->params->get('hide_mignifier')?'Yes':'No'); ?>
	            </td>
	        </tr>
	        <tr>
	            <td class="key">
                    <?php echo JText::_('Hide Fastw3b copyright'); ?>:
	            </td>
	            <td>
					<?php echo JText :: _($this->obj->params->get('hide_fw_copyright')?'Yes':'No'); ?>
	            </td>
	        </tr>
		</table>
	</fieldset>
	</div>
	<div id="description" style="width:40%;float:left;">
    <fieldset class="adminform">
        <legend><?php echo JText::_('FW Gallery'); ?></legend>

			<p><img style="margin-right: 10px; float: left !important;" src="<?php echo JURI :: base(true); ?>/components/com_fwgallery/assets/images/01_c_gallery_150.png" /></p>
			<p><span style="text-decoration: underline;"><strong><?php echo JText::_('Project details'); ?></strong></span></p>
			<div><strong><?php echo JText::_('Creation date'); ?></strong>:<br/><?php echo JText::_('July 8, 2010'); ?></div>
			<div><strong><?php echo JText::_('Version'); ?></strong>:<br/>1.6.1</div>
			<div><strong><?php echo JText::_('Type ext'); ?></strong>:<br/><?php echo JText::_('Non-Commercial'); ?></div>
			<div><strong><?php echo JText::_('License'); ?></strong>: GPLv2</div>
			<div class="clr"></div>

			<p><span style="text-decoration: underline;"><strong><?php echo JText::_('Useful links'); ?>:</strong></span></p>
			<ul>
				<li><?php echo JText::_('Check for'); ?> <a target="_blank" href="http://fastw3b.net/index.php?option=com_user&amp;view=login&amp;return=aHR0cDovL2Zhc3R3M2IubmV0L2NsaWVudC1zZWN0aW9uLW15LWRvd25sb2Fkcy5odG1s"><?php echo JText::_('updates'); ?> &gt;&gt;</a> (<?php echo JText::_('login first'); ?>)</li>
				<li><?php echo JText::_('Any ideas'); ?> <a href="mailto:wehearyou@fastw3b.net"><?php echo JText::_('ideas or suggestions'); ?> &gt;&gt;</a></li>
				<li><?php echo JText::_('Have any'); ?> <a target="_blank" href="http://fastw3b.net/forum.html"><?php echo JText::_('questions'); ?> &gt;&gt;</a></li>
				<li><?php echo JText::_('Our clients feedbacks and your reviews on'); ?> <a target="_blank" href="http://extensions.joomla.org/extensions/photos-a-images/photo-gallery/13185"><?php echo JText::_('JED'); ?> &gt;&gt;</a></li>
				<li><?php echo JText::_('Follow FW Gallery news on'); ?> <a target="_blank" href="http://twitter.com/#!/Fastw3b"><?php echo JText::_('Twitter'); ?> &gt;&gt;</a> <?php echo JText :: _('and'); ?> <a target="_blank" href="http://www.facebook.com/pages/edit/?id=165610930146118&amp;sk=basic#!/pages/Fastw3b/165610930146118?v=wall"><?php echo JText::_('Facebook'); ?> &gt;&gt;</a></li>
				<li><?php echo JText::_('Watch our video tutorial on'); ?> <a target="_blank" href="http://www.youtube.com/user/fastw3b">Youtube &gt;&gt;</a></li>
				<li>Fastw3b <a target="_blank" href="http://fastw3b.net/joomla-extensions/best-offer.html"><?php echo JText::_('best offers'); ?> &gt;&gt; </a></li>
				<li><?php echo JText::_('Related service'); ?>: <a target="_blank" href="http://fastw3b.net/joomla-services/service/4-extensions-customization.html"><?php echo JText::_('Extensions Customization'); ?> &gt;&gt; </a></li>
			</ul>

			<p><span style="text-decoration: underline;"><strong><?php echo JText::_('FW Gallery add-ons'); ?>:</strong></span></p>
			<ul>
				<li><?php echo JText::_('FW Gallery'); ?> <a target="_blank" href="http://fastw3b.net/joomla-extensions/product/60-fw-gallery-light-template.html"><?php echo JText::_('Light Template'); ?> &gt;&gt;</a></li>
				<li><?php echo JText::_('FW Gallery'); ?> <a target="_blank" href="http://fastw3b.net/joomla-extensions/product/61-fw-gallery-light-plus-template.html"><?php echo JText::_('Light Plus Template'); ?> &gt;&gt;</a></li>
				<li><?php echo JText::_('FW Gallery'); ?> <a target="_blank" href="http://fastw3b.net/joomla-extensions/product/62-fw-gallery-video-template.html"><?php echo JText::_('Video Template'); ?> &gt;&gt;</a></li>
				<li><?php echo JText::_('FW Gallery'); ?> <a target="_blank" href="http://fastw3b.net/joomla-extensions/product/9-fw-gallery-batch-upload.html"><?php echo JText::_('Batch Upload plugin'); ?> &gt;&gt;</a></li>
				<li><?php echo JText::_('FW Gallery'); ?> <a target="_blank" href="http://fastw3b.net/joomla-extensions/product/6-fw-gallery-comment.html"><?php echo JText::_('Comment Plugin'); ?> &gt;&gt;</a></li>
				<li><?php echo JText::_('FW Gallery'); ?> <a target="_blank" href="http://fastw3b.net/joomla-extensions/product/12-fw-gallery-content-plugin.html"><?php echo JText::_('Content Plugin'); ?> &gt;&gt;</a></li>
				<li><?php echo JText::_('FW Gallery'); ?> <a target="_blank" href="http://fastw3b.net/joomla-extensions/product/26-fw-gallery-facebook-plugin.html"><?php echo JText::_('Facebook Plugin'); ?> &gt;&gt;</a></li>
				<li><?php echo JText::_('FW Gallery'); ?> <a target="_blank" href="http://fastw3b.net/joomla-extensions/product/36-fw-gallery-front-end-manager.html"><?php echo JText::_('Front-end Manager plugin'); ?> &gt;&gt;</a></li>
				<li><?php echo JText::_('FW Gallery'); ?> <a target="_blank" href="http://fastw3b.net/joomla-extensions/product/14-fw-gallery-manual-resize.html"><?php echo JText::_('Manual Resize plugin'); ?> &gt;&gt;</a></li>
				<li><?php echo JText::_('FW Gallery'); ?> <a target="_blank" href="http://fastw3b.net/joomla-extensions/product/3-fw-gallery-import.html"><?php echo JText::_('Import Plugin'); ?> &gt;&gt;</a></li>
				<li><?php echo JText::_('FW Gallery'); ?> <a target="_blank" href="http://fastw3b.net/joomla-extensions/product/27-fw-gallery-jomsocial-plugin.html"><?php echo JText::_('JomSocial Plugin'); ?> &gt;&gt;</a></li>
				<li><?php echo JText::_('FW Gallery'); ?> <a target="_blank" href="http://fastw3b.net/joomla-extensions/product/13-fw-gallery-latest-module.html"><?php echo JText::_('Latest Module'); ?> &gt;&gt;</a></li>
				<li><?php echo JText::_('FW Gallery'); ?> <a target="_blank" href="http://fastw3b.net/joomla-extensions/product/2-fw-gallery-fancy-slideshow.html"><?php echo JText::_('Fancy Slideshow module'); ?> &gt;&gt;</a></li>
				<li><?php echo JText::_('FW Gallery'); ?> <a target="_blank" href="http://fastw3b.net/joomla-extensions/product/28-fw-gallery-search-plugin.html"><?php echo JText::_('Search Plugin'); ?> &gt;&gt;</a></li>
				<li><?php echo JText::_('FW Gallery'); ?> <a target="_blank" href="http://fastw3b.net/joomla-extensions/product/51-fw-video-gallery-plugin.html"><?php echo JText::_('Video Plugin'); ?> &gt;&gt;</a></li>
			</ul>
		</fieldset>
	</div>
	<div style="clear:both;"></div>
	<input type="hidden" name="task" value="" />
</form>
