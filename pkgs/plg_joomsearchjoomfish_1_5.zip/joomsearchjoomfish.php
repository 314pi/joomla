<?php
// $HeadURL: https://joomgallery.org/svn/joomgallery/JG-1.5/JG/trunk/components/com_joomgallery/models/search.php $
// $Id: search.php 2913 2011-03-17 13:28:57Z chraneco $
/****************************************************************************************\
**   Plugin JoomGallery Search Joom!Fish                                                **
**   By: JoomGallery::ProjectTeam                                                       **
**   Copyright (C) 2008 - 2011  JoomGallery::ProjectTeam                                **
\****************************************************************************************/

defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.plugin.plugin');

/**
 * JoomGallery Plugin
 *
 * Adds the possibility to search in translations of Joom!Fish
 *
 * @package     Joomla
 * @subpackage  JoomGallery
 * @since       1.5
 */
class plgJoomGalleryJoomSearchJoomFish extends JPlugin
{
  /**
   * Constructor
   *
   * For php4 compatability we must not use the __constructor as a constructor for plugins
   * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
   * This causes problems with cross-referencing necessary for the observer design pattern.
   *
   * @access  protected
   * @param   object  $subject  The object to observe
   * @param   object  $params   The object that holds the plugin parameters
   * @return  void
   * @since   1.5
   */
  function plgJoomGalleryJoomSearchJoomFish(&$subject, $params)
  {
    parent::__construct($subject, $params);
  }

  /**
   * onJoomSearch Method
   *
   * Method is called if something is searched in JoomGallery
   *
   * @access  public
   * @param   string  $searchstring The string to search for
   * @return  array   An array which holds query parts to extend the search query
   * @since   1.5
   */
  function onJoomSearch($searchstring)
  {
    $searcharr = array();

    $searcharr['images.leftjoin'] = "#__jf_content AS jf ON a.id = jf.reference_id";

    $searcharr['images.where.or'] = 'jf.value LIKE \'%'.$searchstring.'%\'';

    $searcharr['images.where']    = "(jf.reference_field = 'imgtitle' OR jf.reference_field = 'imgtext' OR ISNULL(jf.reference_field))
                  AND (jf.reference_table = 'joomgallery'             OR ISNULL(jf.reference_table))
                  AND (jf.published       = 1                         OR ISNULL(jf.published))";

    return $searcharr;
  }
}