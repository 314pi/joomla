<?php
// $HeadURL: https://joomgallery.org/svn/joomgallery/JG-1.5/Module/JoomJComments/trunk/mod_joomjcom.php $
// $Id: mod_joomjcom.php 1168 2009-02-18 19:11:14Z chraneco $
/******************************************************************************\
**   JoomGallery Module 'JoomJCom' 1.5 BETA (integrates JComments into JG)    **
**   By: JoomGallery::ProjectTeam                                             **
**   Copyright (C) 2009 - 2009  Patrick Alt                                   **
**   Released under GNU GPL Public License                                    **
**   License: http://www.gnu.org/copyleft/gpl.html or have a look             **
**   at administrator/components/com_joomgallery/LICENSE.TXT                  **
\******************************************************************************/

// Check to ensure this file is included in Joomla!
defined( '_JEXEC' ) or die( 'Restricted access' );

// Check to ensure that we are in JoomGallery ambit
if(!class_exists('JoomAmbit'))
{
  echo 'We are not in JoomGallery Ambit';
  return;
}

$view = JRequest::getCmd('view');
switch($view)
{
  case 'detail':
    $id     = JRequest::getInt('id');
    $title  = '';
    break;
  case 'category':
    $id     = JRequest::getInt('catid')+900000000;
    $title  = '';
    break;
  case '':
    $id     = 999999999;
    $title  = JText::_('JGA_GALLERY');
    break;
  default:
    return;
    break;
}

$comments = JPATH_ROOT.DS.'components'.DS.'com_jcomments'.DS.'jcomments.php';
if(file_exists($comments))
{
  require_once($comments);
  echo JComments::showComments($id, 'com_joomgallery', $title);
}
else
{
  echo 'JComments is not installed';
}