<?php
defined( '_JEXEC' ) or die( 'Direct Access to this location is not allowed.' );
?>

CHANGELOG Module CB GalleryTab for JoomGallery

Legende / Legend:

* -> Security Fix
# -> Bug Fix
+ -> Addition
^ -> Change
- -> Removed
! -> Note

20120214
! version for JoomGallery 2.0

20100118
#no use of JoomGallery column settings if parameters empty

20100115
^modified for JoomGallery MVC
no more compatibility for older versions of JoomGallery 1.5 MVC/Joomla! 1.5
!Version 4.1 

March 2009 - 4.0
Language files, category filtering, "Comments" tab
 
January 2009 - 3.1
Improved Joomla 1.5 compatibility

December 2008 - 3.0
New "Favourites" tab: User Favourites
overall user rating
Number of columns configurable
Complete Joomla 1.5 (w. CB 1.2) compatibility

October 2008 - 3.0 beta2
Using new JG interface, included tab with tagged images

August 2008 - 3.0 beta
Dropped Ponygallery support, quick rewrite for Joomgallery 1 (new public beta)

January 2008 - 2.1:
Removed ItemID() function from Ponygallery ML 2.41 beacuse it no longer exists on 2.5
=> compatible with PG-ML 2.5

August 2007 - 2.0:
now compatible with Joomgallery (beta) and Ponygallery (+ML), released as GalleryTab)
uses details view from Ponygallery ML, e.g. Javascript Popup


