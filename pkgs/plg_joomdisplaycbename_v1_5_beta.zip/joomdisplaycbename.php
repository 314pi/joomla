<?php
// $HeadURL: https://joomgallery.org/svn/joomgallery/JG-1.5/Plugins/JoomDisplayCBEName/trunk/joomdisplaycbename.php $
// $Id: joomdisplaycbename.php 2127 2010-05-03 09:29:00Z chraneco $
/****************************************************************************************\
**   Plugin 'JoomDisplayCBEName' 1.5                                                     **
**   By: JoomGallery::ProjectTeam                                                       **
**   Copyright (C) 2010 - 2010 Patrick Alt                                              **
**   Released under GNU GPL Public License                                              **
**   License: http://www.gnu.org/copyleft/gpl.html or have a look                       **
**   at administrator/components/com_joomgallery/LICENSE.TXT                            **
\****************************************************************************************/

defined('_JEXEC') or die('Direct Access to this location is not allowed.');

jimport('joomla.plugin.plugin');

/**
 * JoomGallery Display Community Builder Enhanced Name Plugin
 *
 * @package     Joomla
 * @subpackage  JoomGallery
 * @since       1.5
 */
class plgJoomGalleryJoomDisplayCBEName extends JPlugin
{
  /**
   * Constructor
   *
   * For php4 compatability we must not use the __constructor as a constructor for plugins
   * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
   * This causes problems with cross-referencing necessary for the observer design pattern.
   *
   * @access  protected
   * @param   object    $subject  The object to observe
   * @param   object    $params   The object that holds the plugin parameters
   * @return  void
   * @since   1.5
   */
  function plgJoomGalleryJoomDisplayCBEName(&$subject, $params)
  {
    $file = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_cbe'.DS.'cbe.xml';
    if(file_exists($file))
    {
      global $ueConfig;
      require_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_cbe'.DS.'ue_config.php');
      JHTML::_('behavior.mootools');
      JHTML::_('behavior.tooltip');
    }
    else
    {
      JError::raiseError(500, JText::_('CBE seems not to be installed'));
    }

    parent::__construct($subject, $params);
  }

  /**
   * OnJoomDisplayUser method
   *
   * Method links a user name with the corresponding Community Builder Enhanced profile.
   *
   * @access  public
   * @param   int     $userID   The ID of the user to display
   * @param   boolean $realname True, if the user's full name shall be displayed
   * @param   string  $context  The context in which the name will be displayed
   * @return  string  The HTML code created for displaying the user's name
   * @since   1.5
   */
  function onJoomDisplayUser(&$userId, &$realname, $context = null)
  {
    global $ueConfig;

    $userId = intval($userId);

    $user = & JFactory::getUser($userId);

    if(!$user)
    {
      return false;
    }

    $name = $realname ? $user->get('name') : $user->get('username');

    if(!$name)
    {
      return false;
    }

    $link = 'index.php?option=com_cbe&task=userProfile&user='.$userId.$this->_getItemid();

    // Directly link to gallery tab, if present
    if(file_exists(JPATH_ROOT.DS.'components'.DS.'com_comprofiler'.DS.'plugin'.DS.'user'.DS.'plug_joomgallery-tab'.DS.'cb.joomtab.php'))
    {
      $link .= '&tab=getjoomtab';
    }

    $db = & JFactory::getDBO();
    $db->setQuery('SELECT avatar, avatarapproved FROM #__cbe WHERE user_id = '.$userId.' LIMIT 1');
		$avatar = $db->loadObject();

    if(!$avatar->avatar || !$avatar->avatarapproved)
    {
      $language = & JFactory::getLanguage();
      $lang     = $language->getBackwardLang();

      // Path according language
      if(is_dir(JPATH_ROOT.DS.'components'.DS.'com_cbe'.DS.'images'.DS.$lang.DS.$ueConfig['defaultAvatarSet']))
      {
        $imagepath = 'components/com_cbe/images/'.$lang.'/'.$ueConfig['defaultAvatarSet'];
      }
      else
      {
        $imagepath = 'components/com_cbe/images/english/'.$ueConfig['defaultAvatarSet'];
      }
    }

    $image = null;
    if(!$avatar->avatarapproved)
    {
      // Pending approval
      $thumb  = $imagepath.'pendphoto.png';
    }
    else
    {
      if(!$avatar->avatar)
      {
        // No photo
        $thumb  = $imagepath.'nophoto.png';
      }
      else
      {
        // Avatar from gallery
        if(preg_match('/(gallery)/',  $avatar->avatar))
        {
          $thumb  = 'images/cbe/'.$avatar->avatar;
          $image  = 'images/cbe/'.$avatar->avatar;
        }
        else
        {
          // User has avatar
          $thumb  = 'images/cbe/tn'.$avatar->avatar;
          $image  = 'images/cbe/'.$avatar->avatar;
        }
      }
    }

    // Create tooltip with avatar
    $overlib = '<img src="'.$thumb.'" width="65" height="81" alt="'.JText::sprintf('Avatar of %s', $name).'" />';

    if($context == 'comment')
    {
      $html = '<a href="'.JRoute::_($link).'">'.$name.'</a><br /><a href="'.JRoute::_($link).'">'.$overlib.'</a>';
      return $html;
    }

    $overlib  = htmlspecialchars($overlib, ENT_QUOTES, 'UTF-8');

    $html = '<span class="hasTip" title="'.$overlib.'"><a href="'.JRoute::_($link).'">'.$name.'</a></span>';

    return $html;
  }

  /**
   * Returns an Itemid which is associated with Community Builder Enhanced
   *
   * @access  protected
   * @return  string    A string for URLs with the Itemid ('&Itemid=X')
   * @since   1.5
   */
  function _getItemid()
  {
    if($Itemid = $this->params->get('valid_Itemid_string', ''))
    {
      return $Itemid;
    }

    $Itemid = intval($this->params->get('Itemid', 0));

    if($Itemid)
    {
      $Itemid = '&Itemid='.$Itemid;
      $this->params->set('valid_Itemid_string', $Itemid);

      return $Itemid;
    }

    $db = & JFactory::getDBO();
    $db->setQuery(" SELECT
                      id
                    FROM
                      #__menu
                    WHERE
                          link LIKE '%com_cbe%'
                      AND access = 0
                    ORDER BY
                      id DESC
                  ");
    if($Itemid = $db->loadResult())
    {
      $Itemid = '&Itemid='.$Itemid;
    }
    else
    {
      $Itemid = '';
    }

    $this->params->set('valid_Itemid_string', $Itemid);

    return $Itemid;
  }
}