<?php
/**
* sh404SEF META plugin for JoomGallery component V 1.5.5 and more actual
* @version 1.5.5
* 20100911
* @author JoomGallery::Project Team
* @package JoomGallery
* @Copyright JoomGallery::Project Team
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* @ All rights reserved
* @ Joomla Open Source is Free Stuff
* @ Released under GnuGPL License.
* @
* if you set a variable to '', this will ERASE the corresponding meta tag
* if you set a variable to null, this will leave the corresponding meta tag UNCHANGED
* Rewrites TITLE, META DESC, META KEYWORDS and META ROBOTS tags in your header.
* They will be replaced, respectively, by the content of :
* $shCustomTitleTag,
* $shCustomDescriptionTag,
* $shCustomKeywordsTag
* $shCustomRobotsTag
* $shCustomLangTag
*/
defined( '_JEXEC' ) or die( 'Direct Access to this location is not allowed.' );

global $mainframe;

$itemid = JArrayHelper::getValue($_REQUEST, 'Itemid', null,'INT');
$view = JArrayHelper::getValue($_REQUEST, 'view', null,'STRING');
$category_id = JArrayHelper::getValue($_REQUEST, 'catid', null,'INT');
$picture_id = JArrayHelper::getValue($_REQUEST, 'id', null,'INT');

global $shCustomTitleTag, $shCustomDescriptionTag, $shCustomKeywordsTag,
$shCustomRobotsTag;

// Get the title from the name of the menu item
// otherwise the name of the site
$query = 'SELECT name FROM #__menu WHERE id='.$itemid;
$database->setQuery($query);
$shJoomName=$database->loadResult();
if (empty($shJoomName)) $shJoomName=$mainframe->getCfg('sitename');

/**
 * Get the description/titles from current/parent categories and titles
 *
 * @param object database connector
 * @param string description of current category
 * @param string title of current category
 * @param integer id of current category
 * @return string comma separated list from parent categories
 */
function joom_get_category_contents( &$db, &$catDesc,&$catTitle, &$catid){
  if (empty($catid))
  {
    return '';
  }
  $catsarr = JoomHelper::getAllParentCategories($catid, true);
  $cats = implode(',', array_keys($catsarr));

  $title= '';
  $db->setQuery("SELECT
                   cid,name,description
                 FROM
                   #__joomgallery_catg
                 WHERE
                   cid IN (".$cats.")");
  $rows = $db->loadObjectList('cid');

  // Iterate through array to construct string of titles
  foreach($rows as $row)
  {
    // Delete all tags and append to title
    $title .= strip_tags($row->name).',';
  }

  // Get the description of current category
  if (empty($catDesc))
  {
    $catDesc = $rows[$catid]->description;
  }

  // Get the title of current category
  if (empty($catTitle))
  {
    $catTitle = $rows[$catid]->name;
  }
  return rtrim($title, ',');
}

/**
 * Get the description and title of current picture
 *
 * @param object database connector
 * @param string description of current picture
 * @param integer id of current picture
 * @param integer id of current category
 * @return string title of picture
 */
function joom_get_picture_content(&$db, &$pictureDesc,&$picid,&$catid){
  if (is_null($picid))
  {
    return '';
  }
  $db->setQuery("SELECT
                   id,imgtitle,imgtext,catid
                 FROM
                   #__joomgallery
                 WHERE
                   id=".$picid);
  $picture = $db->loadRow();
  if (is_null($picture))
  {
    return '';
  }

  $pictureDesc = $picture[2];
  $catid = $picture[3];
  return $picture[1];
}

switch ($view)
{
  // Category View
  case 'category':
    // Title       = menuitemname/sitename - category title
    // Description = category description
    // Keywords    = menuitemname/sitename,category list
    // Robots      = index,follow
    $catDesc = '';
    $catTitle = '';
    $catList = joom_get_category_contents($database, $catDesc,$catTitle, $category_id);
    $shCustomTitleTag = $shJoomName.' - '.$catTitle;
    if (empty($catDesc))
    {
      $shCustomDescriptionTag = null; //preserve the existing tag
    }
    else
    {
      $shCustomDescriptionTag = $catDesc;
    }
    $shCustomKeywordsTag = $shJoomName.','.$catList;
    $shCustomRobotsTag = 'index,follow';
    break;
  // Detail view
  case 'detail':
    // Detail view
    // Title       = menuitemname/sitename - category title - picture title
    // Description = picture description
    // Keywords    = menuitemname/sitename,category list,picture title
    // Robots      = index,follow
    // picture
    $pictureDesc = '';
    $catid = '';
    $pictureTitle = joom_get_picture_content($database, $pictureDesc, $picture_id,$catid);

    // Category
    $catDesc = '';
    $catTitle = '';
    $catList = joom_get_category_contents($database, $catDesc,$catTitle, $catid);

    $shCustomTitleTag = $shJoomName.' - '.$catTitle.' - '.$pictureTitle;
    if (empty($pictureDesc))
    {
      // Preserve the existing tag
      $shCustomDescriptionTag = null;
    }
    else
    {
      $shCustomDescriptionTag = $pictureDesc;
    }
    $shCustomKeywordsTag = $shJoomName.','.$catList.','.$pictureTitle;
    $shCustomRobotsTag = 'index,follow';
  break;
  // Toplists
  case 'toplist':
    // Title       = menuitemname/sitename - sorting title
    // Description = sorting title
    // Keywords    = menuitemname/sitename,sorting title
    // Robots      = index,follow
    $type = JArrayHelper::getValue($_REQUEST, 'type', null,'STRING');

    // Include the frontend language files of JoomGallery
    $language = & JFactory::getLanguage();
    $language->load('com_joomgallery');

    switch ($type)
    {
      case "lastcommented" :
        $title = JText::_('JGS_TOPLIST_TOP').' '.JText::_('JGS_COMMON_TOPLIST_LAST_COMMENTED');
        break;
      case "lastadded" :
        $title = JText::_('JGS_TOPLIST_TOP').' '.JText::_('JGS_COMMON_TOPLIST_LAST_ADDED');
        break;
      case "toprated" :
        $title = JText::_('JGS_TOPLIST_TOP').' '.JText::_('JGS_COMMON_TOPLIST_TOP_RATED');
        break;
      default:
        $title = JText::_('JGS_TOPLIST_TOP').' '.JText::_('JGS_COMMON_TOPLIST_MOST_VIEWED');
    }
    $shCustomTitleTag=$shJoomName.' - '.$title;
    $shCustomDescriptionTag = $title;
    $shCustomKeywordsTag=$shJoomName.','.$title;
    $shCustomRobotsTag = 'index,follow';
  break;
  // Userpanel
  case 'userpanel':
      //nothing to do
  break;
 // Gallery View
  default:
    //Title       = menuitemname/sitename
    //Description = menuitemname/sitename
    //Keywords    = menuitemname/sitename
    //Robots      = index,follow
    $shCustomTitleTag=$shJoomName;
    $shCustomDescriptionTag =$shJoomName;
    $shCustomKeywordsTag=$shJoomName;
    $shCustomRobotsTag = 'index,follow';
  break;
}
?>
