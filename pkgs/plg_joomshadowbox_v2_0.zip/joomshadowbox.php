<?php
// $HeadURL: https://joomgallery.org/svn/joomgallery/JG-2.0/Plugins/JoomShadowbox/trunk/joomshadowbox.php $
// $Id: joomshadowbox.php 3736 2012-04-03 14:40:22Z chraneco $
/****************************************************************************************\
**   Plugin 'JoomShadowbox' 2.0                                                         **
**   By: JoomGallery::ProjectTeam                                                       **
**   Copyright (C) 2010 - 2010 Patrick Alt                                              **
**   Released under GNU GPL Public License                                              **
**   License: http://www.gnu.org/copyleft/gpl.html or have a look                       **
**   at administrator/components/com_joomgallery/LICENSE.TXT                            **
\****************************************************************************************/

defined('_JEXEC') or die('Direct Access to this location is not allowed.');

jimport('joomla.plugin.plugin');

/**
 * JoomGallery Shadowbox Plugin
 *
 * With this plugin JoomGallery is able to use
 * Shadowbox (http://www.shadowbox-js.com/) for displaying images.
 *
 * NOTE: Please remember that Shadowbox is licensed under the terms
 * of the 'Shadowbox.js License' (http://www.shadowbox-js.com/LICENSE,
 * http://www.shadowbox-js.com/#license).
 *
 * @package     Joomla
 * @subpackage  JoomGallery
 * @since       1.5
 */
class plgJoomGalleryJoomShadowbox extends JPlugin
{
  /**
   * Constructor
   *
   * For php4 compatability we must not use the __constructor as a constructor for plugins
   * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
   * This causes problems with cross-referencing necessary for the observer design pattern.
   *
   * @access  protected
   * @param   object    $subject  The object to observe
   * @param   object    $params   The object that holds the plugin parameters
   * @return  void
   * @since   1.5
   */
  public function plgJoomGalleryJoomShadowbox(&$subject, $params)
  {
    parent::__construct($subject, $params);
  }

  /**
   * OnJoomOpenImage method
   *
   * Method is called after an image of JoomGallery shall be opened.
   * It modifies the given link in order to use Shadowbox for opening the image.
   *
   * @access  public
   * @param   string  $link     The link to modify
   * @param   object  $image    An object holding the image data
   * @param   string  $img_url  The URL to the image which shall be openend
   * @param   string  $group    The name of an image group, RokBox will make an album out of the images of a group
   * @param   string  $type     'orig' for original image, 'img' for detail image or 'thumb' for thumbnail
   * @return  void
   * @since   1.5
   */
  public function onJoomOpenImage(&$link, $image = null, $img_url = null, $group = 'joomgallery', $type = 'orig')
  {
    static $loaded = false;

    if($image)
    {
      if(!$loaded && !$this->params->get('global_shadowbox_existent'))
      {
        $doc = JFactory::getDocument();

        $doc->addStyleSheet(JURI::root().'media/plg_joomshadowbox/shadowbox.css');

        JHtml::_('behavior.framework');
        $doc->addScript(JURI::root().'media/plg_joomshadowbox/shadowbox.js');
        $doc->addScriptDeclaration('    Shadowbox.init();');

        $loaded = true;
      }

      $link = $img_url.'" rel="shadowbox['.$group.'];player=img';
    }
    else
    {
      // JoomGallery wants to know whether this plugin is enabled
      $link = true;
    }
  }
 
  /**
   * onJoomOpenImageGetName method
   *
   * Method is called if the popup box name is requested used by this plugin
   *
   * @return  string  The name of the popup box used by this plugin
   * @since   2.0
   */
  public function onJoomOpenImageGetName()
  {
    return 'Shadowbox';
  }
}