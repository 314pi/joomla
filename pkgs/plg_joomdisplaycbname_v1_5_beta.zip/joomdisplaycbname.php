<?php
// $HeadURL: https://joomgallery.org/svn/joomgallery/JG-1.5/Plugins/JoomDisplayCBName/trunk/joomdisplaycbname.php $
// $Id: joomdisplaycbname.php 2127 2010-05-03 09:29:00Z chraneco $
/****************************************************************************************\
**   Plugin 'JoomDisplayCBName' 1.5                                                     **
**   By: JoomGallery::ProjectTeam                                                       **
**   Copyright (C) 2010 - 2010 Patrick Alt                                              **
**   Released under GNU GPL Public License                                              **
**   License: http://www.gnu.org/copyleft/gpl.html or have a look                       **
**   at administrator/components/com_joomgallery/LICENSE.TXT                            **
\****************************************************************************************/

defined('_JEXEC') or die('Direct Access to this location is not allowed.');

jimport('joomla.plugin.plugin');

/**
 * JoomGallery Display Community Builder Name Plugin
 *
 * @package     Joomla
 * @subpackage  JoomGallery
 * @since       1.5
 */
class plgJoomGalleryJoomDisplayCBName extends JPlugin
{
  /**
   * Constructor
   *
   * For php4 compatability we must not use the __constructor as a constructor for plugins
   * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
   * This causes problems with cross-referencing necessary for the observer design pattern.
   *
   * @access  protected
   * @param   object    $subject  The object to observe
   * @param   object    $params   The object that holds the plugin parameters
   * @return  void
   * @since   1.5
   */
  function plgJoomGalleryJoomDisplayCBName(&$subject, $params)
  {
    $file = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_comprofiler'.DS.'plugin.foundation.php';
    if(file_exists($file))
    {
      global $ueConfig;
      require_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_comprofiler'.DS.'ue_config.php');
      require_once($file);
      cbimport('cb.database');
      JHTML::_('behavior.mootools');
      JHTML::_('behavior.tooltip');
    }
    else
    {
      JError::raiseError(500, JText::_('CB seems not to be installed'));
    }

    parent::__construct($subject, $params);
  }

  /**
   * OnJoomDisplayUser method
   *
   * Method links a user name with the corresponding Community Builder profile.
   *
   * @access  public
   * @param   int     $userID   The ID of the user to display
   * @param   boolean $realname True, if the user's full name shall be displayed
   * @param   string  $context  The context in which the name will be displayed
   * @return  string  The HTML code created for displaying the user's name
   * @since   1.5
   */
  function onJoomDisplayUser(&$userId, &$realname, $context = null)
  {
    $userId = intval($userId);

    $cbUser = & CBuser::getInstance($userId);

    if(!$cbUser)
    {
      return false;
    }

    $cbUserData = &$cbUser->getUserData();

    $name       = $realname ? $cbUserData->name : $cbUserData->username;

    if(!$name)
    {
      return false;
    }

    $link = 'index.php?option=com_comprofiler&task=userProfile&user='.$userId.$this->_getItemid();

    // Directly link to gallery tab, if present
    if(file_exists(JPATH_ROOT.DS.'components'.DS.'com_comprofiler'.DS.'plugin'.DS.'user'.DS.'plug_gallery-tab'.DS.'cb.gallerytab.php'))
    {
      $link .= '&tab=getgallerytab';
    }

    // Create tooltip with avatar
    $overlib = '<img src="'.$cbUser->avatarFilePath().'" alt="'.JText::sprintf('Avatar of %s', $name).'" />';

    if($context == 'comment')
    {
      $html = '<a href="'.JRoute::_($link).'">'.$name.'</a><br /><a href="'.JRoute::_($link).'">'.$overlib.'</a>';
      return $html;
    }

    $overlib  = htmlspecialchars($overlib, ENT_QUOTES, 'UTF-8');

    $html = '<span class="hasTip" title="'.$name.'::'.$overlib.'"><a href="'.JRoute::_($link).'">'.$name.'</a></span>';

    return $html;
  }

  /**
   * Returns an Itemid which is associated with Community Builder
   *
   * @access  protected
   * @return  string    A string for URLs with the Itemid ('&Itemid=X')
   * @since   1.5
   */
  function _getItemid()
  {
    if($Itemid = $this->params->get('valid_Itemid_string', ''))
    {
      return $Itemid;
    }

    $Itemid = intval($this->params->get('Itemid', 0));

    if($Itemid)
    {
      $Itemid = '&Itemid='.$Itemid;
      $this->params->set('valid_Itemid_string', $Itemid);

      return $Itemid;
    }

    $db = & JFactory::getDBO();
    $db->setQuery(" SELECT
                      id
                    FROM
                      #__menu
                    WHERE
                          link LIKE '%com_comprofiler%'
                      AND access = 0
                    ORDER BY
                      id DESC
                  ");
    if($Itemid = $db->loadResult())
    {
      $Itemid = '&Itemid='.$Itemid;
    }
    else
    {
      $Itemid = '';
    }

    $this->params->set('valid_Itemid_string', $Itemid);

    return $Itemid;
  }
}