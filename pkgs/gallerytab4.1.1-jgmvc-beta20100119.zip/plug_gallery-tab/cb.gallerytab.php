<?php
// $HeadURL: https://joomgallery.org/svn/joomgallery/JG-1.5/Addons/Plugin%20CB%20GalleryTab/branches/JGMVC/plug_gallery-tab/cb.gallerytab.php $
// $Id: cb.gallerytab.php 1867 2010-01-19 07:34:28Z aha $
/*************************************************************************************
* Tab for Community Builder User Profiles to display the pictures the user has up-
* loaded in JoomGallery
*
* Authors: Armin Hornung                                   http://www.arminhornung.de
* and JoomGallery team
* Date: 1/19/2010
* Version: 4.1.1
* Released under GNU GPL Public License         http://www.gnu.org/copyleft/gpl.html
*************************************************************************************/

/** ensure this file is being included by a parent file */
defined('_JEXEC') or die('Direct Access to this location is not allowed.');

/**
 * The default GalleryTab class
 *
 * Outputs a user's images in JoomGallery *
 */
class getGalleryTab extends cbTabHandler {
  var $_interface;
  var $_mainframe;
  var $_my;

  function getGalleryTab() {
    $this->cbTabHandler();
    $this->_mainframe = & JFactory::getApplication();
    $this->_my = & JFactory::getUser();

    $params   = JComponentHelper::getParams('com_languages');
    $frontend_lang = $params->get('site', 'en-GB');
    $language = JLanguage::getInstance($frontend_lang);
    $mosConfig_lang = $language->getBackwardLang();
    $joom_interface_path = JPATH_SITE . "/components/com_joomgallery/interface.php" ;

    include_once($joom_interface_path);
    $this->_interface = new JoomInterface();

    // @TODO J1.0 compatible language file inclusion:
    $pluginPath = JPATH_SITE."/components/com_comprofiler/plugin/user/plug_gallery-tab/language/";
    if (file_exists($pluginPath.$mosConfig_lang.".php"))
      include_once($pluginPath.$mosConfig_lang.".php");
    else
      include_once($pluginPath."english.php");
  }
/**
 * Creates and returns the header of the Gallery tab
 * conatining No. of images, and upload-link if configured
 **/
  function getHeader($own, $total, $showRating = 0, $ratingStats = NULL)
  {
    $return = '<p>';
    if (intval($total) == 0){
      $return.=_JG_GT_USER_NO_IMAGES."<br />";
    }
    else
    {
      $return.= sprintf(_JG_GT_TOTAL_IMAGES, $total)."<br />";
      if ($showRating)
      {
        if ($ratingStats->numvotes > 0)
        {
          $avg_rating = number_format($ratingStats->votesum / $ratingStats->numvotes, 2);
        }
        else
        {
          $avg_rating = 0;
        }
        $return .= sprintf(_JG_GT_OVERALL_RATING, $avg_rating, $ratingStats->numvotes)."<br />";
      }
    }
    $gallery_link = JRoute::_("index.php?option=com_joomgallery&view=userpanel".$this->_interface->getJoomId());
    $return .=($own)?sprintf(_JG_GT_UPLOAD_IMAGES, $gallery_link):"";
    $return.= "</p>";

    return $return;
  }

  function listRows($rows, $numcols=1)
  {
    $elem_width =  floor(99 / $numcols);
    $this->_interface->getPageHeader();

    if (empty($rows))
    {
      return "";
    }

    $return = "";
    $return.= "\n<div class=\"gallerytab\">\n";
    $return.= "<div class=\"jg_row sectiontableentry2\" >";
    $rowcount = 0;
    $itemcount = 0;

    foreach ( $rows as $row1 )
    {
      if (($itemcount % $numcols == 0) && ($itemcount != 0))
      {
        $return.="</div> <div class=\"jg_row sectiontableentry". ($rowcount % 2 +1) ."\">\n";
        $rowcount++;
      }
      $return .= "<div class=\"jg_element_cat\" style=\"width:$elem_width%\">\n";
      $return .= "  ".$this->_interface->displayThumb($row1);
      $return .= "  <div class =\"jg_catelem_txt\">\n";
      $return .= "    ".$this->_interface->displayDesc($row1);
      $return .= "  </div>\n";
      $return.= "</div>\n";
      $itemcount++;
    }
    $return.= "</div>\n</div>";
    return $return;
  }


/**
 * Main function, displays the Gallery-Tab in Community Builder
 **/
  function getDisplayTab($tab, $user, $ui)
  {
    $database = & JFactory::getDBO();
    // See if Joomgallery is present
    if(!file_exists(JPATH_SITE . "/components/com_joomgallery/joomgallery.php"))
    {
        return "Error: JoomGallery not found. Is the component installed?";
    }
    $params = $this->params;

    // Set up JG-Interface options:
    if($params->get('hidebackend', '0'))
    {
      $this->_interface->addConfig("hidebackend", "true");
    }
    $this->_interface->addConfig("categoryfilter", $params->get('categoryfilter',''));
    $this->_interface->addConfig("showcategory", $params->get('showCategory','1')==1);
    $this->_interface->addConfig("showhits", $params->get('showhits','1')==1);
    $this->_interface->addConfig("shownumcomments", $params->get('shownumcomments','1')==1);
    $this->_interface->addConfig("showrate", $params->get('showrate','1')==1);
    $this->_interface->addConfig("showauthor", "0");

    //String to return for output
    $return="";
    if($tab->description != null)
    {
        $return .= "\t\t<div class=\"tab_Description\">".unHtmlspecialchars(getLangDefinition($tab->description))."</div>\n";
    }
    $total=$this->_interface->getNumPicsOfUser($user->id, $this->_my->gid);

    // Hide tab if no pics and it is configured to hide:
    if (($total==0) && ($params->get('showEmptyTab','1')==0))
    {
      return null;
    }
    // Display overall user rating, if wanted
    $ratingStats = array();
    $showRatingStats = $params->get('showUserRating', 1);
    if ($showRatingStats)
    {
      $query = "SELECT sum(imgvotes) AS numvotes, sum(imgvotesum) AS votesum
          FROM #__joomgallery
          WHERE owner = $user->id";
      $database->setQuery($query);
      $ratingStats = & $database->loadObject();
    }

    // If not setted in backend take the JG setting
    $numcols = intval($params->get('numcols', 0));
    if ($numcols < 1)
    {
      $numcols = $this->_interface->getJConfig('jg_colnumb');
    }

    // Pagination:
    $startpage=1;
    $picsperpage = $params->get('picsperpage','');
    if (!$picsperpage)
    {
      $picsNumber = $this->_interface->getJConfig('jg_perpage');
    }
    else
    {
      $picsNumber = $picsperpage;
    }
    $pagingParams = $this->_getPaging(array(),array("gallerytab_"));
    if ($pagingParams["gallerytab_limitstart"] === null)
    {
      $pagingParams["gallerytab_limitstart"] = "0";
    }
    if ($picsNumber > $total)
    {
      $pagingParams["gallerytab_limitstart"] = "0";
    }

    // Include Header (Information) on first page:
    $showUploadLink = (($params->get('uploadLinkEnabled', '1')==1) && ($user->id == $this->_my->id));
    if ($pagingParams["gallerytab_limitstart"] == "0")
    {
      $return .= $this->getHeader($showUploadLink, $total, $showRatingStats, $ratingStats);
    }
    // output nothing else when there are no pics:
    if ($total == 0)
    {
      return $return;
    }
    $limitstart = $pagingParams["gallerytab_limitstart"]?$pagingParams["gallerytab_limitstart"]:"0";
    $rows = $this->_interface->getPicsOfUser($user->id, $this->_my->gid, $params->get('sortBy','jg.catid ASC'), $picsNumber,$limitstart);

    $return .= $this->listRows($rows, $numcols);

    // Pagination, if configured to show:
    $showPagination = ($params->get('pagination','1')=='1');
    if ($showPagination &&($picsNumber < $total))
    {
      $return .= "<div style='width:95%;text-align:center;'>"
      .$this->_writePaging($pagingParams,"gallerytab_",$picsNumber,$total)
      ."</div>";
    }

    return $return;
  }
}

/**
 * The GalleryTagsTab class
 *
 * Outputs the images a user is tagged in
 */
class getGalleryTagsTab extends getGalleryTab
{
  function getGalleryTagsTab()
  {
    $this->getGalleryTab();
  }

  function getHeader($total)
  {
    $return = '';

    if (intval($total) == 0)
    {
      $return.="<p>"._JG_GT_USER_NO_TAGGED."</p>";
    }
    else {
        $return.= "<p>".sprintf(_JG_GT_TOTAL_TAGGED, $total) ."</p>";
    }

    return $return;
  }

  function getDisplayTab($tab, $user, $ui)
  {
    $params = $this->params;

    // Set up JG-Interface options:
    if($params->get('hidebackend', '0'))
    {
      $this->_interface->addConfig("hidebackend", "true");
    }
    $this->_interface->addConfig("categoryfilter", $params->get('categoryfilter',''));
    $this->_interface->addConfig("showcategory", $params->get('showCategory','1')==1);
    $this->_interface->addConfig("showhits", $params->get('showhits','1')==1);
    $this->_interface->addConfig("shownumcomments", $params->get('shownumcomments','1')==1);
    $this->_interface->addConfig("showrate", $params->get('showrate','1')==1);
    $this->_interface->addConfig("showcatlink", 1);

    $return="";  //String to return for output
    if($tab->description != null)
    {
      $return .= "\t\t<div class=\"tab_Description\">".unHtmlspecialchars(getLangDefinition($tab->description))."</div>\n";
    }
    $total=$this->_interface->getNumPicsUserTagged($user->id, $this->_my->gid);

    // Hide tab if no pics and it is configured to hide:
    if (($total==0) && ($params->get('showEmptyTab','1')==0))
    {
      return null;
    }

    $numcols = intval($params->get('numcols', 0));
    if ($numcols < 1)
    {
      $numcols = $this->_interface->getJConfig('jg_colnumb');
    }

    // Pagination:
    $startpage=1;
    $picsperpage = $params->get('picsperpage','');
    if (!$picsperpage)
    {
      $picsNumber = $this->_interface->getJConfig('jg_perpage');
    }
    else
    {
      $picsNumber = $picsperpage;
    }
    $pagingParams = $this->_getPaging(array(),array("gallerytagstab_"));
    if ($pagingParams["gallerytagstab_limitstart"] === null)
    {
      $pagingParams["gallerytagstab_limitstart"] = "0";
    }
    if ($picsNumber > $total)
    {
      $pagingParams["gallerytagstab_limitstart"] = "0";
    }

    // Include Header (Information) on first page:
    if ($pagingParams["gallerytagstab_limitstart"] == "0")
    {
      $return .= $this->getHeader($total);
    }

    // output nothing else when there are no pics:
    if ($total == 0)
    {
      return $return;
    }

    $limitstart = $pagingParams["gallerytagstab_limitstart"]?$pagingParams["gallerytagstab_limitstart"]:"0";
    $rows = $this->_interface->getPicsUserTagged($user->id, $this->_my->gid, $params->get('sortBy','jg.catid ASC'), $picsNumber,$limitstart);
    $return .= $this->listRows($rows, $numcols);

    // Pagination, if configured to show:
    $showPagination = ($params->get('pagination','1')=='1');
    if ($showPagination &&($picsNumber < $total)) {
      $return .= "<div style='width:95%;text-align:center;'>"
      .$this->_writePaging($pagingParams,"gallerytagstab_",$picsNumber,$total)
      ."</div>";
    }

    return $return;
  }
}

/**
 * The GalleryFavouritesTab class
 *
 * Outputs a user's favourite images in JoomGallery
 */
class getGalleryFavouritesTab extends getGalleryTab
{
  function getGalleryFavouritesTab()
  {
    $this->getGalleryTab();
  }

  function getHeader($own,$total)
  {
    $return = '';

    if (intval($total) == 0)
    {
      $return.="<p>". _JG_GT_USER_NO_FAV."<br/>";
    }
    else
    {
      $return.= "<p>".sprintf(_JG_GT_TOTAL_FAV, $total)."<br/>";
    }
    $gallery_link = JRoute::_("index.php?option=com_joomgallery&view=favourites".$this->_interface->getJoomId());
    $return .=($own)?sprintf(_JG_GT_MANAGE_FAVOURITES, $gallery_link):"";
    $return.= "</p>";
    return $return;
  }

  function getDisplayTab($tab, $user, $ui)
  {
    $params = $this->params;

    // Set up JG-Interface options:
    if($params->get('hidebackend', '0'))
    {
      $this->_interface->addConfig("hidebackend", "true");
    }
    $this->_interface->addConfig("categoryfilter", $params->get('categoryfilter',''));
    $this->_interface->addConfig("showcategory", $params->get('showCategory','1')==1);
    $this->_interface->addConfig("showhits", $params->get('showhits','1')==1);
    $this->_interface->addConfig("shownumcomments", $params->get('shownumcomments','1')==1);
    $this->_interface->addConfig("showrate", $params->get('showrate','1')==1);
    $this->_interface->addConfig("showcatlink", 1);

    $ownProfile = (($user->id == $this->_my->id));

    // Hide tab if not viewed by user and not public:
    if (!$ownProfile && $params->get('showPublic', '1') == 0)
    {
      return null;
    }

    $total=$this->_interface->getNumPicsUserFavoured($user->id, $this->_my->gid);

    // Hide tab if no pics and it is configured to hide:
    if (($total==0) && ($params->get('showEmptyTab','1')==0))
    {
      return null;
    }

    //String to return for output
    $return="";
    if($tab->description != null)
    {
      $return .= "\t\t<div class=\"tab_Description\">".unHtmlspecialchars(getLangDefinition($tab->description))."</div>\n";
    }

    $numcols = intval($params->get('numcols', 0));
    if ($numcols < 1)
    {
      $numcols = $this->_interface->getJConfig('jg_colnumb');
    }

    // Pagination:
    $startpage=1;
    $picsperpage = $params->get('picsperpage','');
    if (!$picsperpage)
    {
      $picsNumber = $this->_interface->getJConfig('jg_perpage');
    }
    else
    {
      $picsNumber = $picsperpage;
    }

    $pagingParams = $this->_getPaging(array(),array("galleryfavstab_"));
    if ($pagingParams["galleryfavstab_limitstart"] === null)
    {
      $pagingParams["galleryfavstab_limitstart"] = "0";
    }
    if ($picsNumber > $total)
    {
      $pagingParams["galleryfavstab_limitstart"] = "0";
    }

    // Include Header (Information) on first page:
    if ($pagingParams["galleryfavstab_limitstart"] == "0")
    {
      $return .= $this->getHeader($ownProfile, $total);
    }

    // output nothing else when there are no pics:
    if ($total == 0)
    {
      return $return;
    }
    $limitstart = $pagingParams["galleryfavstab_limitstart"]?$pagingParams["galleryfavstab_limitstart"]:"0";
    $rows = $this->_interface->getPicsUserFavoured($user->id, $this->_my->gid, $params->get('sortBy','jg.catid ASC'), $picsNumber,$limitstart);

    $return .= $this->listRows($rows, $numcols);

    // Pagination, if configured to show:
    $showPagination = ($params->get('pagination','1')=='1');
    if ($showPagination &&($picsNumber < $total))
    {
      $return .= "<div style='width:95%;text-align:center;'>"
      .$this->_writePaging($pagingParams,"galleryfavstab_",$picsNumber,$total)
      ."</div>";
    }

    return $return;
  }
}

class getGalleryCommentsTab extends getGalleryTab
{
  function getGalleryCommentsTab()
  {
    $this->getGalleryTab();
  }

  function getHeader($total)
  {
    $return = '';

    if (intval($total) == 0)
    {
      $return.="<p>"._JG_GT_USER_NO_COMMENTS."</p>";
    }
    else {
        $return.= "<p>".sprintf(_JG_GT_TOTAL_COMMENTS, $total) ."</p>";
    }

    return $return;
  }

  function getDisplayTab($tab, $user, $ui)
  {
    // version check first:
    if (!method_exists($this->_interface,"getNumCommentsUser")){
      return "Error: Your version of JoomGallery does not support user comments in the API. Please upgrade to the newest stable version (1.0.1, 1.5 RC or newer required)";
    }

    $params = $this->params;

    // Set up JG-Interface options:
    if($params->get('hidebackend', '0'))
    {
      $this->_interface->addConfig("hidebackend", "true");
    }

    // String to return for output
    $return="";
    if($tab->description != null)
    {
      $return .= "\t\t<div class=\"tab_Description\">".unHtmlspecialchars(getLangDefinition($tab->description))."</div>\n";
    }

    $total=$this->_interface->getNumCommentsUser($user->id, $this->_my->gid);

    // Hide tab if no pics and it is configured to hide:
    if (($total==0) && ($params->get('showEmptyTab','1')==0))
    {
      return null;
    }

    $numrows = intval($params->get('numrows', 15));

    // Pagination:
    $startpage=1;

    $pagingParams = $this->_getPaging(array(),array("commentstab_"));
    if ($pagingParams["commentstab_limitstart"] === null)
    {
      $pagingParams["commentstab_limitstart"] = "0";
    }
    if ($numrows > $total)
    {
      $pagingParams["commentstab_limitstart"] = "0";
    }

    // Include Header (Information) on first page:
    if ($pagingParams["commentstab_limitstart"] == "0")
    {
      $return .= $this->getHeader($total);
    }

    // Output nothing else when there are no pics:
    if ($total == 0)
    {
      return $return;
    }

    $limitstart = $pagingParams["commentstab_limitstart"]?$pagingParams["commentstab_limitstart"]:"0";
    $rows = $this->_interface->getCommentsUser($user->id, $this->_my->gid,$params->get('sortBy',"jgco.cmtid DESC"), $numrows,$limitstart);

    // Output of table rows:
    $return .= "<table cellpadding=\"3\" cellspacing=\"0\" border=\"0\" style=\"margin:0px;padding:0px;width:100%;\">";
    $return .= "\n\t<tr class=\"sectiontableheader\">";
    $return .= "<th>"._JG_GT_DATE."</th>";
    $return .= "<th>"._JG_GT_PIC."</th>";
    $return .= "<th>"._JG_GT_CAT."</th>";
    $return .= "<th>"._JG_GT_COMMENT."</th>";
    $return .= "</tr>";
    $i=2;
    foreach($rows as $row1)
    {
      $i= ($i==1) ? 2 : 1;
      //$return .="\n\t<tr class=\"sectiontableentry$i\"><td>".getFieldValue("date", date("Y-m-d, H:i:s",$row1->cmtdate))."</td>";
      $return .="\n\t<tr class=\"sectiontableentry$i\"><td>".$row1->cmtdate."</td>";
      $return .="<td><a href = \"".$this->_interface->getImageLink($row1)."\">".$row1->imgtitle."</a></td>";
      $return .="<td>".$row1->cattitle."</td>";

      if ($params->get('completeComment','1')!='1' && strlen($row1->cmttext) > 100)
      {
        $row1->cmttext = substr($row1->cmttext, 0, 100). "...";
      }
      $return .="<td>".stripslashes($row1->cmttext)."</td></tr>";
    }
    $return .= "</table>";

    // Pagination, if configured to show:
    $showPagination = ($params->get('pagination','1')=='1');
    if ($showPagination && ($numrows < $total))
    {
      $return .= "<div style='width:95%;text-align:center;'>"
      .$this->_writePaging($pagingParams,"commentstab_",$numrows,$total)
      ."</div>";
    }

    return $return;
  }
}
?>