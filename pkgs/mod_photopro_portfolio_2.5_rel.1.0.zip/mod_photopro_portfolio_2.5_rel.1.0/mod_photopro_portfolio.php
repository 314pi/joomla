<?php
/**
* @Copyright Copyright (C) 2012- photopro_portfolio by Smallirons
* @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
**/
defined( '_JEXEC' ) or die( 'Restricted access' );
require_once (dirname(__FILE__).DS.'noimage_functions.php');

$bannerWidth           = trim($params->get( 'bannerWidth', '100%' ));
$bannerHeight          = intval($params->get( 'bannerHeight', 500 ));
$contentxml   = 'data/cgal.xml';
$globalxml    = 'data/global.xml'; 
$musicxml     = 'data/playlist.xml'; 

$catppv_id = '';
$module_path = dirname(__FILE__).DS;

$pagetitle            = trim($params->get('pagetitle', 'YOURNAME' )); 
$pageid               = trim($params->get('pageid', 'YN' ));
$pageslogan           = trim($params->get('pageslogan', 'insert your slogan here..' ));
$pagecopyright        = trim($params->get('pagecopyright', 'Copyright 2012, Yourname.' ));

$firstgallery         = trim($params->get('firstgallery', 'First' )); 
$firstimgdir          = trim($params->get('firstimgdir', '' )); 
$first_imgdesc        = trim($params->get('first_imgdsc', '' )); 
$first_imgdsc_arr     = explode("|",$first_imgdesc);

$secondgallery         = trim($params->get('secondgallery', 'Second' )); 
$secondimgdir          = trim($params->get('secondimgdir', '' )); 
$second_imgdesc        = trim($params->get('second_imgdsc', '' )); 
$second_imgdsc_arr     = explode("|",$second_imgdesc);

$thirdgallery         = trim($params->get('thirdgallery', 'Third' )); 
$thirdimgdir          = trim($params->get('thirdimgdir', '' )); 
$third_imgdesc        = trim($params->get('third_imgdsc', '' )); 
$third_imgdsc_arr     = explode("|",$third_imgdesc);

$musicdir             = trim($params->get('musicdir', '' ));
$artist_desc          = trim($params->get('artist_desc', '' )); 
$artist_desc_arr      = explode("|",$artist_desc);
$song_desc            = trim($params->get('song_desc', '' )); 
$song_desc_arr        = explode("|",$song_desc);


////////// start : noimage code //////////////
$exist_url = JURI::root();
$server_path = getCurUrl($exist_url);

//////////////////////////////////////////WRITE GLOBAL//////////////////////////////////////////////////////////////
$xml_global_data .= '<?xml version="1.0" encoding="UTF-8"?>
<root>
	<title val="'. trim($pagetitle) .'"  id="'. trim($pageid) .'"/>
	<slogan val="'. trim($pageslogan) .'"/>
	<copyright val="'. trim($pagecopyright) .'"/>
	<menuitems>
		<menuitem val="PORTFOLIO" gallery="1">
		</menuitem>
	</menuitems>
</root>
';
$catppv_id .= md5($xml_global_data);
$xml_data_filename = $module_path.$catppv_id.'.xml';
if (!file_exists($xml_data_filename)) {
	$xml_prodgallery_file = fopen($xml_data_filename,'w');
	fwrite($xml_prodgallery_file, $xml_global_data);
	///////// set chmod 0777 for creating .xml file  if server is not windows
	$os_string = php_uname('s');
	$cnt = substr_count($os_string, 'Windows');
	if($cnt ==0){
		@chmod($xml_data_filename, 0777);
	}

	fclose($xml_prodgallery_file);
	
}
copy($module_path . $catppv_id . '.xml', $module_path . $globalxml);
unlink($xml_data_filename);

/////////////////////////////////////////// WRITE FIRST GALLERY////////////////////////////////////////////////////////////////////////
$xml_data_data .= '<?xml version="1.0" encoding="UTF-8"?>
<albums>
    <gallery name="' . trim($firstgallery) . '" path="' . trim($server_path) .  trim($firstimgdir) . '/">';



if(!function_exists('photoPortfolio')) {
  function photoPortfolio($dirname='.') {return glob($dirname .'*.{jpg,JPG,jpeg,JPEG,gif,GIF,png,PNG,bmp,BMP}', GLOB_BRACE);}
}
$catalog = photoPortfolio($firstimgdir."/");
$total = count($catalog);
if ($total==0) echo "folder $firstimgdir <br />is empty or does not exists";
for ($i=0;$i<$total;$i++) {
	$path = $catalog[$i];
	$last = strrpos($path, "/"); 
	$file = substr($path, $last+1); 
	$progres = $i + 1;
	$title = trim($firstgallery) . '_' . strval($progres) ;
	
	$xml_data_data .= ' <image img="' . trim($file) . '" bigimg="' . trim($file) . '" thumb="'  . trim($file) . '" title="'  . trim($title) . '" buy_link="" buy="0" fullsize="1" def="0"> ';
	if ($params->get('first_show_desc', 'yes') == 'yes') {
				$xml_data_data .= ' <description><![CDATA['.trim($first_imgdsc_arr[$i]).']]></description>';
		}else{
				$xml_data_data .= ' <description><![CDATA[]]></description>';
		}	
	
	$xml_data_data .= '
           </image>';
	$xml_data_data .= "\n";	   
}
$xml_data_data .= '
</gallery>
';
/////////////////////////////////////////// WRITE SECOND GALLERY////////////////////////////////////////////////////////////////////////

$catalog = photoPortfolio($secondimgdir."/");
$total = count($catalog);
if ($total>0) {
		$xml_data_data .= '
		<gallery name="' . trim($secondgallery) . '" path="' . trim($server_path) .  trim($secondimgdir) . '/">';



	for ($i=0;$i<$total;$i++) {
		$path = $catalog[$i];
		$last = strrpos($path, "/"); 
		$file = substr($path, $last+1); 
		$progres = $i + 1;
		$title = trim($secondgallery) . '_' . strval($progres) ;
	
		$xml_data_data .= ' <image img="' . trim($file) . '" bigimg="' . trim($file) . '" thumb="'  . trim($file) . '" title="'  . trim($title) . '" buy_link="" buy="0" fullsize="1" def="0"> ';
		if ($params->get('first_show_desc', 'yes') == 'yes') {
				$xml_data_data .= ' <description><![CDATA['.trim($second_imgdsc_arr[$i]).']]></description>';
			}else{
				$xml_data_data .= ' <description><![CDATA[]]></description>';
		}	
	
		$xml_data_data .= '
           </image>';
		$xml_data_data .= "\n";	   
	}
$xml_data_data .= '
</gallery>
';

}

/////////////////////////////////////////// WRITE THIRD GALLERY////////////////////////////////////////////////////////////////////////

$catalog = photoPortfolio($thirdimgdir."/");
$total = count($catalog);
if ($total>0) {
		$xml_data_data .= '
		<gallery name="' . trim($thirdgallery) . '" path="' . trim($server_path) .  trim($thirdimgdir) . '/">';



	for ($i=0;$i<$total;$i++) {
		$path = $catalog[$i];
		$last = strrpos($path, "/"); 
		$file = substr($path, $last+1); 
		$progres = $i + 1;
		$title = trim($thirdgallery) . '_' . strval($progres) ;
	
		$xml_data_data .= ' <image img="' . trim($file) . '" bigimg="' . trim($file) . '" thumb="'  . trim($file) . '" title="'  . trim($title) . '" buy_link="" buy="0" fullsize="1" def="0"> ';
		if ($params->get('first_show_desc', 'yes') == 'yes') {
				$xml_data_data .= ' <description><![CDATA['.trim($third_imgdsc_arr[$i]).']]></description>';
			}else{
				$xml_data_data .= ' <description><![CDATA[]]></description>';
		}	
	
		$xml_data_data .= '
           </image>';
		$xml_data_data .= "\n";	   
	}
$xml_data_data .= '
</gallery>
';

}
/////////////////////// close CGAL ///////////////////////////////////////////////////////////////

$xml_data_data .= '
</albums>
';
$catppv_id .= md5($xml_data_data);
$xml_data_filename = $module_path.$catppv_id.'.xml';
if (!file_exists($xml_data_filename)) {
	$xml_prodgallery_file = fopen($xml_data_filename,'w');
	fwrite($xml_prodgallery_file, $xml_data_data);
	///////// set chmod 0777 for creating .xml file  if server is not windows
	$os_string = php_uname('s');
	$cnt = substr_count($os_string, 'Windows');
	if($cnt ==0){
		@chmod($xml_data_filename, 0777);
	}

	fclose($xml_prodgallery_file);
	
}
copy($module_path . $catppv_id . '.xml', $module_path . $contentxml);
unlink($xml_data_filename);
//////////////////////////////////////////WRITE MUSIC PLAYLIST//////////////////////////////////////////////////////////////
if ($params->get('autostart_music', 'yes') == 'yes') {
				$autostart = '1';
		}else{
				$autostart = '0';
		}	
if ($params->get('loop_music', 'yes') == 'yes') {
				$loop = '1';
		}else{
				$loop = '0';
		}	
$xml_music_data .= '<?xml version="1.0" encoding="UTF-8"?>
<playlist autostart="'. trim($autostart) .'" loop="'. trim($loop) .'"> <!-- autostart="1(true)/0(false)" loop="1(true)/0(false)" - loop track or play tracks by order-->
	
';
if(!function_exists('musicPortfolio')) {
  function musicPortfolio($dirname='.') {return glob($dirname .'*.{mp3,MP3}', GLOB_BRACE);}
}
$catalog = musicPortfolio($musicdir."/");
$total = count($catalog);
if ($total==0) echo "folder $musicdir <br />is empty or does not exists, insert this folder with one mp3 song..please";

for ($i=0;$i<$total;$i++) {
	$file = $catalog[$i];
	$progres = $i + 1;
	$title = 'Song_' . strval($progres) ;
	
	$xml_music_data .= ' <song src="' . trim($server_path) . trim($file) . '" artist="'; 
	if ($artist_desc_arr[$i] == '') {
		$xml_music_data .=  trim($title) . '"';
	}else{
		$xml_music_data .=  trim($artist_desc_arr[$i]) . '"';
		}	
	if ($song_desc_arr[$i] == '') {
		$xml_music_data .= ' title="' . trim($title) . '" />';
	}else{
		$xml_music_data .= ' title="' .  trim($song_desc_arr[$i]) . '" />';
		}
		
	$xml_music_data .= "\n";	   
}
$xml_music_data .= '
</playlist>
';		

$catppv_id .= md5($xml_global_data);
$xml_data_filename = $module_path.$catppv_id.'.xml';
if (!file_exists($xml_data_filename)) {
	$xml_prodgallery_file = fopen($xml_data_filename,'w');
	fwrite($xml_prodgallery_file, $xml_music_data);
	///////// set chmod 0777 for creating .xml file  if server is not windows
	$os_string = php_uname('s');
	$cnt = substr_count($os_string, 'Windows');
	if($cnt ==0){
		@chmod($xml_data_filename, 0777);
	}

	fclose($xml_prodgallery_file);
	
}
copy($module_path . $catppv_id . '.xml', $module_path . $musicxml);
unlink($xml_data_filename);


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
$exist_url = JURI::root();
$server_path = getCurUrl($exist_url);
?>
<script language="javascript" type="text/javascript">
	function iFrameHeight() {
		var h = 0;
		if ( !document.all ) {
			h = document.getElementById('blockrandom').contentDocument.height;
			document.getElementById('blockrandom').style.height = h + 60 + 'px';
		} else if( document.all ) {
			h = document.frames('blockrandom').document.body.scrollHeight;
			document.all.blockrandom.style.height = h + 20 + 'px';
		}
	}
</script>

<iframe onload="iFrameHeight()"	id="blockrandom"
	name=""
	src="<?php echo $server_path; ?>modules/mod_photopro_portfolio/photopro_portfolio.html"
	width="<?php echo $bannerWidth; ?>"
	height="<?php echo $bannerHeight; ?>"
	scrolling="no"
	align="top"
	frameborder="0"
	class="wrappernuw">
	No Iframes</iframe>
<div style=clear:both;></div>
