<?php

/*
 * @version		$Id: router.php 1.2 2012-04-11 $
 * @package		Joomla
 * @copyright   Copyright (C) 2012-2013 MrVinoth
 * @license     GNU/GPL http://www.gnu.org/licenses/gpl-2.0.html
*/

function AllVideoShareBuildRoute( &$query )
{
	$segments = array();
   
    if(isset($query['view'])) {
    	$segments[] = $query['view'];
        unset( $query['view'] );
    }
	
    if(isset($query['slg'])) {
    	$segments[] = $query['slg'];
        unset( $query['slg'] );
    }
	
	if(isset($query['orderby'])) {
		$segments[] = $query['orderby'];
    	unset( $query['orderby'] );	
	}
	
    return $segments;
}

function AllVideoShareParseRoute( $segments )
{
	$vars  = array();
	$order = array('default', 'latest', 'popular', 'random', 'featured');
	$count = count( $segments );

	switch($segments[0]) {
    	case 'category':
        	$vars['view']   = 'category';
            break;
        case 'video':
            $vars['view']   = 'video';
            break;
		case 'search':
            $vars['search'] = 'search';
            break;
		case 'user':
            $vars['view']   = 'user';
            break;
    }
	
	if( $count == 2 ) {
		if( in_array($segments[1], $order) ) {
			$vars['orderby'] = $segments[1];
		} else {
			$vars['slg'] = $segments[1];
		}
	} else if($count == 3) {
		$vars['slg'] = $segments[1];
    	$vars['orderby'] = $segments[2];
	}

    return $vars;
}

?>