<?php

/*
 * @version		$Id: default.php 1.2 2012-04-11 $
 * @package		Joomla
 * @copyright   Copyright (C) 2012-2013 MrVinoth
 * @license     GNU/GPL http://www.gnu.org/licenses/gpl-2.0.html
*/

defined('_JEXEC') or die('Restricted access');

require_once( JPATH_ROOT.DS.'components'.DS.'com_allvideoshare'.DS.'models'.DS.'player.php' );

$config = $this->config;
$video  = $this->video;
$custom = new AllVideoShareModelPlayer();

?>
<style type="text/css">
<?php echo $config[0]->css; ?>
</style>
<div id="fb-root"></div>
<script>
(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));
</script>
<?php if($config[0]->title) { ?>
<h2> <?php echo $this->escape($video->title); ?> </h2>
<?php } ?>
<div id="avs_video<?php echo $this->escape($this->params->get('pageclass_sfx')); ?>">
  <div class="avs_video_header">
    <?php if($config[0]->category) { ?>
    <div class="avs_category_label"><strong>Category : </strong><?php echo $video->category; ?></div>
    <?php } ?>
    <?php if($config[0]->views) { ?>
    <div class="avs_views_label"><strong>Views : </strong><?php echo $video->views; ?></div>
    <?php } ?>
    <?php if($config[0]->search) { ?>
    <div class="avs_input_search">
      <form action="index.php" name="hsearch" id="hsearch" method="post" enctype="multipart/form-data"  >
        <input type="text" name="avssearch" id="avssearch" value=""/>
        <input type="hidden" name="option" value="com_allvideoshare" />
        <input type="hidden" name="view" value="search" />
        <input type="hidden" name="Itemid" value="<?php echo JRequest::getVar('Itemid'); ?>" />
        <input type="submit" name="search_btn" id="search_btn" value="Go" />
      </form>
    </div>
    <?php } ?>
    <div style="clear:both;"></div>
  </div>
  <div class="avs_player"> <?php echo $custom->buildPlayer($video->id, $config[0]->playerid); ?> </div>
  <div class="avs_video_description"><?php echo $video->description; ?></div>
  <?php
	if($config[0]->layout != 'none') {
		echo $this->loadTemplate($config[0]->layout); 
	}
  ?>
</div>