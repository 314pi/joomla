<?php

/*
 * @version		$Id: default_all.php 1.2 2012-04-11 $
 * @package		Joomla
 * @copyright   Copyright (C) 2012-2013 MrVinoth
 * @license     GNU/GPL http://www.gnu.org/licenses/gpl-2.0.html
*/

defined('_JEXEC') or die('Restricted access');

$config  = $this->config;
$videos  = $this->videos;
$catlink = "index.php?option=com_allvideoshare&view=category&slg=";
$vidlink = "index.php?option=com_allvideoshare&view=video&slg=";
$qs      = JRequest::getVar('Itemid') ? '&Itemid=' . JRequest::getVar('Itemid') : '';
$more    = (count($videos) > $config[0]->relatedvideoslimit) ? true : false;
$count   = ($config[0]->relatedvideoslimit > count($videos)) ? count($videos) : $config[0]->relatedvideoslimit;

?>

<div class="avs_videopage_left">
  <h2><?php echo JText::_('ADD_YOUR_COMMENTS'); ?></h2>
  <div class="fb-comments" data-href="<?php echo JURI::current(); ?>" data-num-posts="<?php echo $config[0]->comments_posts; ?>" data-width="<?php echo $config[0]->comments_width; ?>" data-colorscheme="<?php echo $config[0]->comments_color; ?>"></div>
</div>
<div class="avs_videopage_right">
  <h2><?php echo JText::_('RELATED_VIDEOS'); ?></h2>
  <?php 
  	if(!count($videos)) echo JText::_('ITEM_NOT_FOUND');
    $k = 0;
  	for ($i=0, $n=$count; $i < $n; $i++) { 
		$k = $i % 2;
  ?>
  <div style="clear:both;"></div>
  <div class="avs_related_row<?php echo $k; ?>"> <a href="<?php echo JRoute::_($vidlink.$videos[$i]->slug.$qs); ?>"> <img src="<?php echo $videos[$i]->thumb; ?>" width="75" height="60" title="<?php echo JText::_('CLICK_TO_VIEW').' : '.$videos[$i]->title; ?>" border="0" /> <span>
    <label class="title"><strong><?php echo $videos[$i]->title; ?></strong></label>
    <label class="views"><strong><?php echo JText::_('VIEWS'); ?> : </strong><?php echo $videos[$i]->views; ?></label>
    </span> </a> </div>
  <?php } ?>
  <div style="clear:both;"></div>
  <?php if($more) { ?>
  <div class="avsmore"><a href="<?php echo JRoute::_($catlink.$this->slug.$qs); ?>"><?php echo JText::_('MORE'); ?></a></div>
  <?php } ?>
</div>