<?php

/*
 * @version		$Id: default_relatedvideos.php 1.2 2012-04-11 $
 * @package		Joomla
 * @copyright   Copyright (C) 2012-2013 MrVinoth
 * @license     GNU/GPL http://www.gnu.org/licenses/gpl-2.0.html
*/

defined('_JEXEC') or die('Restricted access');

$config        = $this->config;
$limitedvideos = $this->limitedvideos;
$catlink       = "index.php?option=com_allvideoshare&view=category&slg=";
$vidlink       = "index.php?option=com_allvideoshare&view=video&slg=";
$qs            = JRequest::getVar('Itemid') ? '&Itemid=' . JRequest::getVar('Itemid') : '';
$row           = 0;
$column        = 0;

?>

<div class="avs_videopage_left">
  <h2><?php echo JText::_('RELATED_VIDEOS'); ?></h2>
  <div id="avs_gallery">
    <?php 
  	if(!count($limitedvideos)) echo JText::_('ITEM_NOT_FOUND');
  	for ($i=0, $n=count($limitedvideos); $i < $n; $i++) {   
		$clear = ''; 
    	if($column >= $config[0]->cols) {
			$clear  = '<div style="clear:both;"></div>';
			$column = 0;
			$row++;		
		}
		$column++;
		echo $clear;
	?>
    <div class="avs_thumb" style="width:<?php echo $config[0]->thumb_width; ?>px;"> <a href="<?php echo JRoute::_($vidlink.$limitedvideos[$i]->slug.$qs); ?>"> <img class="arrow" src="components/com_allvideoshare/assets/play.gif" border="0" style="margin-left:<?php echo ($config[0]->thumb_width / 2) - 15; ?>px; margin-top:<?php echo ($config[0]->thumb_height / 2) - 13; ?>px;" /> <img class="image" src="<?php echo $limitedvideos[$i]->thumb; ?>" width="<?php echo $config[0]->thumb_width; ?>" height="<?php echo $config[0]->thumb_height; ?>" title="<?php echo JText::_('CLICK_TO_VIEW').' : '.$limitedvideos[$i]->title; ?>" border="0" /> <span class="title"><?php echo $limitedvideos[$i]->title; ?></span> <span class="views"><strong>views : </strong><?php echo $limitedvideos[$i]->views; ?></span> </a> </div>
    <?php } ?>
  </div>
  <div style="clear:both"></div>
  <div id="avs_pagination"><?php echo $this->pagination->getPagesLinks(); ?></div>
</div>