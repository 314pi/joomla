<?php

/*
 * @version		$Id: mod_allvideosharesearch.php 1.2 2012-04-11 $
 * @package		Joomla
 * @copyright   Copyright (C) 2012-2013 MrVinoth
 * @license     GNU/GPL http://www.gnu.org/licenses/gpl-2.0.html
*/
 
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

?>

<div align="center">
  <form action="index.php" name="hsearch" id="hsearch" method="post" enctype="multipart/form-data"  >
    <input type="text" name="avssearch" id="avssearch" style="width:75%" value=""/>
    <input type="hidden" name="option" value="com_allvideoshare" />
    <input type="hidden" name="view" value="search" />
    <input type="hidden" name="Itemid" value="<?php echo JRequest::getVar('Itemid'); ?>" />
    <input type="submit" name="search_btn" id="search_btn" value="Go" />
  </form>
</div>