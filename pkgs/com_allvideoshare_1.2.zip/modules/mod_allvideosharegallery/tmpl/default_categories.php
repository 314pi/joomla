<?php 

/*
 * @version		$Id: default_categories.php 1.2 2012-04-11 $
 * @package		Joomla
 * @copyright   Copyright (C) 2012-2013 MrVinoth
 * @license     GNU/GPL http://www.gnu.org/licenses/gpl-2.0.html
*/

defined('_JEXEC') or die('Restricted access'); 

$link       = 'index.php?option=com_allvideoshare&view=category';
$categories = $items['data'];
$more       = $items['more'];
$count      = $items['columns'] * $items['rows'];
if(count($categories) <= $count) {
	$more  = 0;
    $count = count($categories);
}
$row    = 0;
$column = 0

?>
<style type="text/css">
#avs_gallery .avs_thumb {	
	float:left;
	padding:0px;
	margin:7px 14px 7px 0px;
	width:<?php echo $items['thumb_width']; ?>px;
}
#avs_gallery .avs_thumb a {
	text-decoration:none;
}
#avs_gallery .avs_thumb .image {
	display:block;
}
#avs_gallery .avs_thumb .arrow {
	position:absolute;
	width:29px;
	height:26px;
	margin-left:59px;
	margin-top:28px;
	opacity:0.5;
}
#avs_gallery .avs_thumb .name {
	margin:5px 0px 0px 0px;
	padding:0px;
	display:block;
	font-family:Arial;
	font-size:11px;
	color:#777;
	font-weight:bold;
}
.avsmore { 
	clear:both;
	padding:0px;
	margin:10px 0px; 
}
.avsmore a { 
	font-size:11px; 
	font-weight:bold; 
	text-decoration:none; 
	border:1px solid #CCC; 
	background-color:#E7E7E7; 
	padding:3px 5px; 
	margin:0px;
}
</style>
<div id="avs_gallery">
  <?php 
  	if(!count($categories)) echo JText::_('ITEM_NOT_FOUND');
  	for ($i=0, $n=$count; $i < $n; $i++) { 
		$clear = '';  
  		if($column >= $items['columns']) {
			$clear  = '<div style="clear:both;"></div>';
			$column = 0;
			$row++;		
		}
		$column++;
		echo $clear;
  ?>
  <div class="avs_thumb"> <a href="<?php echo JRoute::_($link.'&slg='.$categories[$i]->slug); ?>"><img class="arrow" src="components/com_allvideoshare/assets/play.gif" border="0" style="margin-left:<?php echo ($items['thumb_width'] / 2) - 15; ?>px; margin-top:<?php echo ($items['thumb_height'] / 2) - 13; ?>px;" /> <img class="image" src="<?php echo $categories[$i]->thumb; ?>" width="<?php echo $items['thumb_width']; ?>" height="<?php echo $items['thumb_height']; ?>" title="<?php echo JText::_('CLICK_TO_VIEW') . ' : ' . $categories[$i]->name; ?>" border="0" /> <span class="name"><?php echo $categories[$i]->name; ?></span> </a> </div>
  <?php } ?>
  <div style="clear:both"></div>
</div>
<?php if($more == 1) { ?>
	<div class="avsmore"><a href="<?php echo JRoute::_($link); ?>"><?php echo JText::_('MORE'); ?></a></div>
<?php } ?>