<?php

/*
 * @version		$Id: default_right.php 1.2 2012-04-11 $
 * @package		Joomla
 * @copyright   Copyright (C) 2012-2013 MrVinoth
 * @license     GNU/GPL http://www.gnu.org/licenses/gpl-2.0.html
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

?>

<div style="border:1px solid #E7E7E7; padding:5px; background-color:#fff;">
  <p align="center" style="font-size:15px; font-weight:bold; color:#0B55C4; margin:5px 0px">
  	<?php echo JText::_('ADMIN_WORK_CHART'); ?> <img src="components/com_allvideoshare/assets/workflow.png" />
  </p>
</div>