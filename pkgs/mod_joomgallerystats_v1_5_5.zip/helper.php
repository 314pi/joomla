<?php
// $HeadURL: https://joomgallery.org/svn/joomgallery/JG-1.5/Module/JoomStats/trunk/helper.php $
// $Id: helper.php 2298 2010-08-22 11:37:31Z aha $
/**
* mod_joomgallerystats
* @version 1.5.1
* @contact: team@joomgallery.net
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
*/

/// no direct access
defined('_JEXEC') or die('Restricted access');

class modJoomGalleryStatsHelper{

  function getList(&$params,&$debugmode) {
    $rows=array();
    $database =& JFactory::getDBO();

    // Retreive parameters
    $allpics=intval($params->get('all_pics'));
    $allpicstext=$params->get('all_picstext');

    $allcats=intval($params->get('all_cats'));
    $allcatstext=$params->get('all_catstext');

    $allhits=intval($params->get('all_hits'));
    $allhitstext=$params->get('all_hitstext');

    $allcomments=intval($params->get('all_comments'));
    $allcommentstext=$params->get('all_commentstext');

    $allvotes=intval($params->get('all_votes'));
    $allvotestext=$params->get('all_votestext');

    $allnametags=intval($params->get('all_nametags'));
    $allnametagstext=$params->get('all_nametagstext');


  //Number of all pics
    if ($allpics) {
      $rows['allpics']->enabled=true;
      $query = 'SELECT COUNT(id) from #__joomgallery';
      $database->setQuery($query);
      $result=$database->loadResult();
      if ($database->getErrorNum() && $debugmode) {
        $rows['allpics']->dberrortxt = $database->getErrorMsg();
      } else {
        $rows['allpics']->outputtext = $allpicstext;
        $rows['allpics']->outputresult = $result;
    }
      if ($debugmode) {
      $rows['allpics']->dbquery = $query;
    }
    } else {
      $rows['allpics']->enabled=false;
    }

    //Number of all categories
    if ($allcats) {
      $rows['allcats']->enabled=true;
      $query = 'SELECT COUNT(cid) from #__joomgallery_catg';
      $database->setQuery($query);
      $result=$database->loadResult();
      if ($database->getErrorNum() && $debugmode) {
        $rows['allcats']->dberrortxt = $database->getErrorMsg();
      } else {
        $rows['allcats']->outputtext = $allcatstext;
        $rows['allcats']->outputresult = $result;
    }
      if ($debugmode) {
      $rows['allcats']->dbquery = $query;
    }
    } else {
      $rows['allcats']->enabled=false;
    }

    //Number of all hits
    if ($allhits) {
      $rows['allhits']->enabled=true;
      $query = 'SELECT SUM(hits) from #__joomgallery';
      $database->setQuery($query);
      $result=$database->loadResult();
      if ($database->getErrorNum() && $debugmode) {
        $rows['allhits']->dberrortxt = $database->getErrorMsg();
      } else {
        $rows['allhits']->outputtext = $allhitstext;
        $rows['allhits']->outputresult = $result;
      }
      if ($debugmode) {
      $rows['allhits']->dbquery = $query;
    }
    } else {
      $rows['allhits']->enabled=false;
    }

    //Number of all comments
    if ($allcomments) {
      $rows['allcomments']->enabled=true;
      $query = 'SELECT COUNT(cmtid) from #__joomgallery_comments';
      $database->setQuery($query);
      $result=$database->loadResult();
      if ($database->getErrorNum() && $debugmode) {
        $rows['allcomments']->dberrortxt = $database->getErrorMsg();
      } else {
        $rows['allcomments']->outputtext = $allcommentstext;
        $rows['allcomments']->outputresult = $result;
      if ($debugmode) {
        $rows['allcomments']->dbquery = $query;
      }
    }
    } else {
      $rows['allcomments']->enabled=false;
    }

    //Number of all votes
    if ($allvotes){
      $rows['allvotes']->enabled=true;
      $query = 'SELECT SUM(imgvotes) from #__joomgallery';
      $database->setQuery($query);
      $result=$database->loadResult();
      if ($database->getErrorNum() && $debugmode) {
        $rows['allvotes']->dberrortxt = $database->getErrorMsg();
      } else {
        $rows['allvotes']->outputtext = $allvotestext;
        $rows['allvotes']->outputresult = $result;
    }
      if ($debugmode) {
      $rows['allvotes']->dbquery = $query;
    }
    } else {
      $rows['allvotes']->enabled=false;
    }

    //Number of all nametags
    if ($allnametags) {
      $rows['allnametags']->enabled=true;
      $query = 'SELECT COUNT(nid) from #__joomgallery_nameshields';
      $database->setQuery($query);
      $result=$database->loadResult();
      if ($database->getErrorNum() && $debugmode) {
        $rows['allnametags']->dberrortxt = $database->getErrorMsg();
      } else {
        $rows['allnametags']->outputtext = $allnametagstext;
        $rows['allnametags']->outputresult = $result;
    }
      if ($debugmode) {
      $rows['allnametags']->dbquery = $query;
    }
    } else {
      $rows['allnametags']->enabled=false;
    }

    return $rows;
  }
}
