<?php
// $HeadURL: https://joomgallery.org/svn/joomgallery/JG-1.5/Module/JoomStats/trunk/mod_joomgallerystats.php $
// $Id: mod_joomgallerystats.php 2298 2010-08-22 11:37:31Z aha $
/**
* mod_joomgallerystats
* @version 1.5.1
* @contact: team@joomgallery.net
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
*/
/// no direct access
defined('_JEXEC') or die('Restricted access');

// Include the syndicate functions only once
require_once (dirname(__FILE__).DS.'helper.php');
$debugmode = intval($params->get( 'debug' ));

$list = modJoomGalleryStatsHelper::getList($params,$debugmode);

require(JModuleHelper::getLayoutPath('mod_joomgallerystats'));
?>