<?php
// $HeadURL: https://joomgallery.org/svn/joomgallery/JG-1.5/Module/JoomStats/trunk/tmpl/default.php $
// $Id: default.php 2298 2010-08-22 11:37:31Z aha $
/**
* mod_joomgallerystats
* @version 1.5.1
* @contact: team@joomgallery.net
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

?>
<ul class="joomgstats_<?php echo $params->get('moduleclass_sfx'); ?>">
<?php
//### Count of all pictures ###
if ($list['allpics']->enabled){
?>
  <li>
<?php
  //print db error text if debug mode enabled
  if ($debugmode && isset($list['allpics']->dberrortxt)) {
?>
    <span class="joomgstats_dberrtext"><?php echo $list['allpics']->dberrortxt;?></span>
<?php
  } else {
?>
    <span class="joomgstats_text"><?php echo $list['allpics']->outputtext;?></span>
    &nbsp;
    <span class="joomgstats_result"><?php echo $list['allpics']->outputresult;?></span>
<?php
  }
  //print query
  if ($debugmode) {
?>
    <br />
    <span class="joomgstats_dbquery"><?php echo $list['allpics']->dbquery;?></span>
<?php
  }
?>
  </li>
<?php
}

//### Count of all categories ###
if ($list['allcats']->enabled){
?>
  <li>
<?php
  //print db error text if debug mode enabled
  if ($debugmode && isset($list['allcats']->dberrortxt)) {
?>
    <span class="joomgstats_dberrtext"><?php echo $list['allcats']->dberrortxt;?></span>
<?php
  } else {
?>
    <span class="joomgstats_text"><?php echo $list['allcats']->outputtext;?></span>
    &nbsp;
    <span class="joomgstats_result"><?php echo $list['allcats']->outputresult;?></span>
<?php
  }
  //print query
  if ($debugmode) {
?>
    <br />
    <span class="joomgstats_dbquery"><?php echo $list['allcats']->dbquery;?></span>
<?php
  }
?>
  </li>
<?php
}

//### Count of all hits ###
if ($list['allhits']->enabled){
?>
  <li>
<?php
  //print db error text if debug mode enabled
  if ($debugmode && isset($list['allhits']->dberrortxt)) {
?>
    <span class="joomgstats_dberrtext"><?php echo $list['allhits']->dberrortxt;?></span>
<?php
  } else {
?>
    <span class="joomgstats_text"><?php echo $list['allhits']->outputtext;?></span>
    &nbsp;
    <span class="joomgstats_result"><?php echo $list['allhits']->outputresult;?></span>
<?php
  }
  //print query
  if ($debugmode) {
?>
    <br />
    <span class="joomgstats_dbquery"><?php echo $list['allhits']->dbquery;?></span>
<?php
  }
?>
  </li>
<?php
}

//### Count of all comments ###
if ($list['allcomments']->enabled){
?>
  <li>
<?php
  //print db error text if debug mode enabled
  if ($debugmode && isset($list['allcomments']->dberrortxt)) {
?>
    <span class="joomgstats_dberrtext"><?php echo $list['allcomments']->dberrortxt;?></span>
<?php
  } else {
?>
    <span class="joomgstats_text"><?php echo $list['allcomments']->outputtext;?></span>
    &nbsp;
    <span class="joomgstats_result"><?php echo $list['allcomments']->outputresult;?></span>
<?php
  }
  //print query
  if ($debugmode) {
?>
    <br />
    <span class="joomgstats_dbquery"><?php echo $list['allcomments']->dbquery;?></span>
<?php
  }
?>
  </li>
<?php
}

//### Count of all votes ###
if ($list['allvotes']->enabled){
?>
  <li>
<?php
  //print db error text if debug mode enabled
  if ($debugmode && isset($list['allvotes']->dberrortxt)) {
?>
    <span class="joomgstats_dberrtext"><?php echo $list['allvotes']->dberrortxt;?></span>
<?php
  } else {
?>
    <span class="joomgstats_text"><?php echo $list['allvotes']->outputtext;?></span>
    &nbsp;
    <span class="joomgstats_result"><?php echo $list['allvotes']->outputresult;?></span>
<?php
  }
  //print query
  if ($debugmode) {
?>
    <br />
    <span class="joomgstats_dbquery"><?php echo $list['allvotes']->dbquery;?></span>
<?php
  }
?>
  </li>
<?php
}

//### Count of all nametags ###
if ($list['allnametags']->enabled){
?>
  <li>
<?php
  //print db error text if debug mode enabled
  if ($debugmode && isset($list['allnametags']->dberrortxt)) {
?>
    <span class="joomgstats_dberrtext"><?php echo $list['allnametags']->dberrortxt;?></span>
<?php
  } else {
?>
    <span class="joomgstats_text"><?php echo $list['allnametags']->outputtext;?></span>
    &nbsp;
    <span class="joomgstats_result"><?php echo $list['allnametags']->outputresult;?></span>
<?php
  }
  //print query
  if ($debugmode) {
?>
    <br />
    <span class="joomgstats_dbquery"><?php echo $list['allnametags']->dbquery;?></span>
<?php
  }
?>
  </li>
<?php
}

?>
</ul>