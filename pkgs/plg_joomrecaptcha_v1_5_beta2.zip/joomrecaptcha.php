<?php
// $HeadURL: https://joomgallery.org/svn/joomgallery/JG-1.5/Plugins/JoomreCaptcha/trunk/joomrecaptcha.php $
// $Id: joomrecaptcha.php 3295 2011-08-24 21:43:51Z chraneco $
/******************************************************************************\
**   JoomGallery Plugin 'JoomEasyCaptcha' 1.5 BETA                            **
**   By: JoomGallery::ProjectTeam                                             **
**   Copyright (C) 2010  Patrick Alt                                          **
**   With some code from the PHP library that handles calling reCAPTCHA       **
**   by Mike Crawford and Ben Maurer                                          **
**   Copyright (c) 2007 reCAPTCHA -- http://recaptcha.net                     **
**   Released under GNU GPL Public License                                    **
**   License: http://www.gnu.org/copyleft/gpl.html                            **
\******************************************************************************/
### Original copyright
/**
 * @version    $Id: joomrecaptcha.php 3295 2011-08-24 21:43:51Z chraneco $
 * @package    Joomla
 * @subpackage  Content
 * @copyright  Copyright (C) 2005 - 2008 Open Source Matters. All rights reserved.
 * @license    GNU/GPL, see LICENSE.php
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');

jimport('joomla.plugin.plugin');

/**
 * JoomGallery EasyCaptcha Plugin
 *
 * @package     Joomla
 * @subpackage  JoomGallery
 * @since       1.5
 */
class plgJoomGalleryJoomreCaptcha extends JPlugin
{
  /**
   * Constructor
   *
   * For php4 compatability we must not use the __constructor as a constructor for plugins
   * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
   * This causes problems with cross-referencing necessary for the observer design pattern.
   *
   * @access  protected
   * @param   object    $subject  The object to observe
   * @param   object    $params   The object that holds the plugin parameters
   * @return  void
   * @since   1.5
   */
  function plgJoomGalleryJoomreCaptcha(&$subject, $params)
  {
    parent::__construct($subject, $params);

    $this->loadLanguage('', JPATH_ADMINISTRATOR);
  }

  /**
   * onJoomGetCaptcha method
   *
   * Method is called whenever spam protection is necessary in the gallery
   *
   * @access  public
   * @param   string  $ambit  A string which determines the ambit in which the captcha will be displayed (for example 'comments')
   * @return  string  The HTML output of the captcha
   * @since   1.5
   */
  function onJoomGetCaptcha($ambit = '')
  {
    $user = & JFactory::getUser();
    if($user->get('aid') > 0 && !$this->params->get('enabled_for'))
    {
      return '';
    }

    $language = & JFactory::getLanguage();
    $lang     = $language->getTag();
    $lang     = substr($lang, 0, 2);

    $html = '
        <div class="jg_cmtl">
          &nbsp;
        </div>
        <div class="jg_cmtr">
          <script type="text/javascript">
            var RecaptchaOptions = {
              theme : \''.$this->params->get('theme').'\',
              lang : \''.$lang.'\'
            };
          </script>
          <script type="text/javascript" src="http://www.google.com/recaptcha/api/challenge?k='.$this->params->get('publickey').'"></script>
          <noscript>
            <iframe src="http://www.google.com/recaptcha/api/noscript?k='.$this->params->get('publickey').'" height="300" width="500" frameborder="0"></iframe>
            <br />
            <textarea name="recaptcha_challenge_field" rows="3" cols="40"></textarea>
            <input type="hidden" name="recaptcha_response_field" value="manual_challenge">
          </noscript>
        </div>';

    return $html;
  }

  /**
   * onJoomCheckCaptcha method
   *
   * Method is called when a captcha should be validated
   *
   * @access  public
   * @param   string  $ambit  A string which determines the ambit in which the captcha will be displayed (for example 'comments')
   * @return  array   An array with result information, boolean false if a check isn't necessary in the context
   * @since   1.5
   */
  function onJoomCheckCaptcha($ambit = '')
  {
    $user = & JFactory::getUser();
    if($user->get('aid') > 0 && !$this->params->get('enabled_for'))
    {
      return false;
    }

    // Load the language file
    $this->loadLanguage('', JPATH_ADMINISTRATOR);

    $server = 'www.google.com';

    $request  = 'privatekey='.urlencode(stripslashes($this->params->get('privatekey')));
    $request .= '&remoteip='.urlencode(stripslashes($_SERVER['REMOTE_ADDR']));
    $request .= '&challenge='.urlencode(stripslashes(JRequest::getVar('recaptcha_challenge_field')));
    $request .= '&response='.urlencode(stripslashes(JRequest::getVar('recaptcha_response_field')));

    $http_request  = "POST /recaptcha/api/verify HTTP/1.0\r\n";
    $http_request .= "Host: ".$server."\r\n";
    $http_request .= "Content-Type: application/x-www-form-urlencoded;\r\n";
    $http_request .= "Content-Length: ".strlen($request)."\r\n";
    $http_request .= "User-Agent: reCAPTCHA/PHP\r\n";
    $http_request .= "\r\n";
    $http_request .= $request;

    $fs = @fsockopen($server, 80);
    if(!$fs)
    {
      JError::raiseError(500, JText::_('Could not open socket'));
    }

    fwrite($fs, $http_request);

    $response = '';

    while(!feof($fs))
    {
      // One TCP-IP packet
      $response .= fgets($fs, 1160);
    }
 
    fclose($fs);

    $response = explode("\r\n\r\n", $response, 2);

    $response = explode("\n", $response[1]);

    if($response[0] == 'true')
    {
      $valid = true;
      $error = '';
    }
    else
    {
      $valid = false;
      $error = $response[1];

      if($error == 'incorrect-captcha-sol')
      {
        $error = JText::_('JRECAPTCHA_SECURITY_CODE_WRONG');
      }
    }

    return array('valid' => $valid, 'error' => $error);
  }
}