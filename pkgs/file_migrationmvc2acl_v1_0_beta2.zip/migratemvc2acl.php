<?php
// $HeadURL: https://joomgallery.org/svn/joomgallery/JG-2.0/Addons/MigrationFromMVCtoACL/trunk/migratemvc2acl.php $
// $Id: admin.migratephoca2j.class.php 1904 2010-03-02 20:57:30Z mab $
/******************************************************************************\
**   JoomGallery Migration Script MVC2ACL 1.0                                 **
**   By: JoomGallery::ProjectTeam                                             **
**   Copyright (C) 2011 JoomGallery::ProjectTeam                              **
**   Released under GNU GPL Public License                                    **
**   License: http://www.gnu.org/copyleft/gpl.html or have a look             **
**   at administrator/components/com_joomgallery/LICENSE.TXT                  **
\******************************************************************************/

/******************************************************************************\
**   Migration of DB and Files from JoomGallery 1.5.7 to Joomgallery 2 ACL    **
**   On the fly generation of categories in db and file system                **
**   moving the images into the new categories                                **
\******************************************************************************/

defined('_JEXEC') or die('Direct Access to this location is not allowed.');

/**
 * Migration script class
 *
 * @package JoomGallery
 * @since   1.0
 */
class JoomMigrate_Mvc2Acl extends JoomMigration
{
  /**
   * Properties for paths and database table names of old JoomGallery to migrate from
   *
   * @var string
   */
  protected $prefix;
  protected $path;
  protected $path_originals;
  protected $path_details;
  protected $path_thumbnails;
  protected $table_images;
  protected $table_categories;
  protected $table_comments;
  protected $table_config;
  protected $table_nameshields;
  protected $table_users;
  protected $table_votes;

  /**
   * Determines whether the user IDs shall be checked against the existing users
   *
   * @var boolean
   */
  protected $check_owner;

  /**
   * Constructor
   *
   * @return  void
   * @since   1.0
   */
  public function __construct()
  {
    $this->migration = 'mvc2acl';

    parent::__construct();

    // Create the image paths and table names
    $this->prefix = $this->_mainframe->getUserStateFromRequest('joom.migration.mvc2acl.prefix', 'prefix', '', 'cmd');
    $this->path   = $this->_mainframe->getUserStateFromRequest('joom.migration.mvc2acl.path2joomla', 'path2joomla', '', 'string');
    if($this->path == '-')
    {
      $this->path_originals   = $this->_mainframe->getUserStateFromRequest('joom.migration.mvc2acl.originals', 'originals', '', 'string');
      $this->path_details     = $this->_mainframe->getUserStateFromRequest('joom.migration.mvc2acl.details', 'details', '', 'string');
      $this->path_thumbnails  = $this->_mainframe->getUserStateFromRequest('joom.migration.mvc2acl.thumbnails', 'thumbnails', '', 'string');
    }
    else
    {
      $this->path             = JPath::clean(rtrim($this->path, '\/'));
      $this->path_originals   = $this->path.DS.$this->_mainframe->getUserStateFromRequest('joom.migration.mvc2acl.originals', 'originals', '', 'string');
      $this->path_details     = $this->path.DS.$this->_mainframe->getUserStateFromRequest('joom.migration.mvc2acl.details', 'details', '', 'string');
      $this->path_thumbnails  = $this->path.DS.$this->_mainframe->getUserStateFromRequest('joom.migration.mvc2acl.thumbnails', 'thumbnails', '', 'string');
    }

    $this->path_originals     = JPath::clean(rtrim($this->path_originals, '\/').DS);
    $this->path_details       = JPath::clean(rtrim($this->path_details, '\/').DS);
    $this->path_thumbnails    = JPath::clean(rtrim($this->path_thumbnails, '\/').DS);

    $this->table_images       = str_replace('#__', $this->prefix, _JOOM_TABLE_IMAGES);
    $this->table_categories   = str_replace('#__', $this->prefix, _JOOM_TABLE_CATEGORIES);
    $this->table_comments     = str_replace('#__', $this->prefix, _JOOM_TABLE_COMMENTS);
    $this->table_config       = str_replace('#__', $this->prefix, _JOOM_TABLE_CONFIG);
    $this->table_nameshields  = str_replace('#__', $this->prefix, _JOOM_TABLE_NAMESHIELDS);
    $this->table_users        = str_replace('#__', $this->prefix, _JOOM_TABLE_USERS);
    $this->table_votes        = str_replace('#__', $this->prefix, _JOOM_TABLE_VOTES);

    $this->check_owner        = $this->_mainframe->getUserStateFromRequest('joom.migration.mvc2acl.owner', 'check_owner', '', 'int');
  }

  /**
   * Checks requirements for migration
   *
   * @return  void
   * @since   1.0
   */
  public function check()
  {
    if($this->path == JPATH_ROOT)
    {
      JFactory::getLanguage()->load('com_joomgallery.mvc2acl');
      $this->_mainframe->redirect('index.php?option='._JOOM_OPTION.'&controller=migration', JText::_('FILES_JOOMGALLERY_MIGRATION_MVC2ACL_WRONG_PATH2JOOMLA'), 'notice');
    }

    if($this->prefix == $this->_db->getPrefix())
    {
      JFactory::getLanguage()->load('com_joomgallery.mvc2acl');
      $this->_mainframe->redirect('index.php?option='._JOOM_OPTION.'&controller=migration', JText::_('FILES_JOOMGALLERY_MIGRATION_MVC2ACL_WRONG_PREFIX'), 'notice');
    }

    $dirs         = array($this->path_originals,
                          $this->path_details,
                          $this->path_thumbnails);
    $tables       = array($this->table_images,
                          $this->table_categories,
                          $this->table_comments,
                          $this->table_nameshields,
                          $this->table_users,
                          $this->table_votes);
    $xml = null;
    if($this->path != '-')
    {
      $xml  = JPath::clean($this->path.DS.'administrator'.DS.'components'.DS.'com_joomgallery'.DS.'joomgallery.xml');
    }

    $min_version  = '1.5.7.3';
    $max_version  = false;

    parent::check($dirs, $tables, $xml, $min_version, $max_version);
  }

  /**
   * Main migration function
   *
   * @return  void
   * @since   1.0
   */
  protected function doMigration()
  {
    $task = $this->_mainframe->getUserState('joom.migration.data.task', 'categories');

    switch($task)
    {
      case 'categories':
        $this->migrateCategories();
        // Break intentionally omited
      case 'rebuild':
        $this->rebuild();
        // Break intentionally omited
      case 'images':
        $this->migrateImages();
        // Break intentionally omited
      case 'comments':
        $this->migrateComments();
        // Break intentionally omited
      case 'nametags':
        $this->migrateNametags();
        // Break intentionally omited
      case 'users':
        $this->migrateUsers();
        // Break intentionally omited
      case 'votes':
        $this->migrateVotes();
        // Break intentionally omited
      case 'config':
        $this->migrateConfig();
        // Break intentionally omited
      default:
        break;
    }
  }

  /**
   * Returns the maximum category ID of JoomGallery 1.5.7.
   *
   * @return  int   The maximum category ID of JoomGallery 1.5.7
   * @since   1.0
   */
  protected function getMaxCategoryId()
  {
    $query = $this->_db->getQuery(true)
          ->select('MAX(cid)')
          ->from($this->table_categories);
    $this->_db->setQuery($query);

    return $this->runQuery('loadResult');
  }

  /**
   * Migrates all categories
   *
   * @return  void
   * @since   1.0
   */
  protected function migrateCategories()
  {
    $query = $this->_db->getQuery(true)
          ->select('*')
          ->from($this->table_categories);
    $this->prepareTable($query, $this->table_categories, 'parent', array(0));

    while($cat = $this->getNextObject())
    {
      // Make information accessible for JoomGallery
      $cat->parent_id = $cat->parent;
      $cat->access    = $cat->access + 1;

      // Search for thumbnail
      $cat->thumbnail = 0;
      if($cat->catimage)
      {
        $search_query = $this->_db->getQuery(true)
                      ->select('id')
                      ->from($this->table_images)
                      ->where('imgthumbname = '.$this->_db->quote($cat->catimage));
        $this->_db->setQuery($search_query);
        $cat->thumbnail = $this->runQuery('loadResult');
      }

      $this->createCategory($cat, $this->check_owner);

      $this->markAsMigrated($cat->cid, 'cid', $this->table_categories);

      if(!$this->checkTime())
      {
        $this->refresh();
      }
    }

    $this->resetTable($this->table_categories);
  }

  /**
   * Migrates all images
   *
   * @return  void
   * @since   1.0
   */
  protected function migrateImages()
  {
    $query = $this->_db->getQuery(true)
          ->select('i.*, c.catpath')
          ->from($this->table_images.' AS i')
          ->leftJoin($this->table_categories.' AS c ON i.catid = c.cid');
    $this->prepareTable($query);

    while($row = $this->getNextObject())
    {
      $original   = $this->path_originals.$row->catpath.DS.$row->imgfilename;
      $detail     = $this->path_details.$row->catpath.DS.$row->imgfilename;
      $thumbnail  = $this->path_thumbnails.$row->catpath.DS.$row->imgthumbname;

      $no_original = false;
      if(!JFile::exists($original))
      {
        $no_original  = true;
        $original = $detail;
        $detail   = null;
      }

      $this->moveAndResizeImage($row, $original, $detail, $thumbnail, false, false, $this->check_owner);

      if($no_original)
      {
        // If there was no original image in the old gallery move the
        // original image in new gallery into detail images directory
        $original = $this->_ambit->getImg('orig_path', $row);
        $detail   = $this->_ambit->getImg('img_path', $row);
        if(!JFile::move($original, $detail))
        {
          $this->setError('Error moving '.$original.' to '.$detail);
        }
      }

      if(!$this->checkTime())
      {
        $this->_mainframe->setUserState('joom.migration.data.task', 'images');
        $this->refresh();
      }
    }
  }

  /**
   * Migrates all comments
   *
   * @return  void
   * @since   1.0
   */
  protected function migrateComments()
  {
    if(!$this->checkTime())
    {
      $this->_mainframe->setUserState('joom.migration.data.task', 'comments');
      $this->refresh();
    }

    $this->writeLogfile('Start migrating comments');
    $selectQuery = $this->_db->getQuery(true)
                ->select('a.*')
                ->from($this->table_comments.' AS a');
    if($this->check_owner)
    {
      $selectQuery->leftJoin('#__users AS u ON a.userid = u.id')
                  ->where('a.userid = 0 OR u.id IS NOT NULL');
    }
    $query = 'INSERT INTO '._JOOM_TABLE_COMMENTS.' '.$selectQuery;
    $this->_db->setQuery($query);
    if($this->runQuery())
    {
      $this->writeLogfile('Comments successfully migrated');
    }
    else
    {
      $this->writeLogfile('Error migrating the commments');
    }
  }

  /**
   * Migrates all name tags
   *
   * @return  void
   * @since   1.0
   */
  protected function migrateNametags()
  {
    if(!$this->checkTime())
    {
      $this->_mainframe->setUserState('joom.migration.data.task', 'nametags');
      $this->refresh();
    }

    $this->writeLogfile('Start migrating name tags');
    $selectQuery = $this->_db->getQuery(true)
                ->select('a.*')
                ->from($this->table_nameshields.' AS a');
    if($this->check_owner)
    {
      $selectQuery->leftJoin('#__users AS u ON a.nuserid = u.id')
                  ->where('u.id IS NOT NULL');
    }
    $query = 'INSERT INTO '._JOOM_TABLE_NAMESHIELDS.' '.$selectQuery;
    $this->_db->setQuery($query);
    if($this->runQuery())
    {
      $this->writeLogfile('Name tags successfully migrated');
    }
    else
    {
      $this->writeLogfile('Error migrating the name tags');
    }
  }

  /**
   * Migrates all comments
   *
   * @return  void
   * @since   1.0
   */
  protected function migrateUsers()
  {
    if(!$this->checkTime())
    {
      $this->_mainframe->setUserState('joom.migration.data.task', 'users');
      $this->refresh();
    }

    $this->writeLogfile('Start migrating users');
    $selectQuery = $this->_db->getQuery(true)
                ->select('a.*')
                ->from($this->table_users.' AS a');
    if($this->check_owner)
    {
      $selectQuery->leftJoin('#__users AS u ON a.uuserid = u.id')
                  ->where('u.id IS NOT NULL');
    }
    $query = 'INSERT INTO '._JOOM_TABLE_USERS.' '.$selectQuery;
    $this->_db->setQuery($query);
    if($this->runQuery())
    {
      $this->writeLogfile('Users successfully migrated');
    }
    else
    {
      $this->writeLogfile('Error migrating the users');
    }
  }

  /**
   * Migrates all votes
   *
   * @return  void
   * @since   1.0
   */
  protected function migrateVotes()
  {
    if(!$this->checkTime())
    {
      $this->_mainframe->setUserState('joom.migration.data.task', 'votes');
      $this->refresh();
    }

    $this->writeLogfile('Start migrating votes');
    $selectQuery = $this->_db->getQuery(true)
                ->select('a.*')
                ->from($this->table_votes.' AS a');
    if($this->check_owner)
    {
      $selectQuery->leftJoin('#__users AS u ON a.userid = u.id')
                  ->where('u.id IS NOT NULL');
    }
    $query = 'INSERT INTO '._JOOM_TABLE_VOTES.' '.$selectQuery;
    $this->_db->setQuery($query);
    if($this->runQuery())
    {
      $this->writeLogfile('Votes successfully migrated');
    }
    else
    {
      $this->writeLogfile('Error migrating the votes');
    }
  }

  /**
   * Migrates configuration settings (where possible)
   *
   * @return  void
   * @since   1.0
   */
  protected function migrateConfig()
  {
    if(!$this->checkTime())
    {
      $this->_mainframe->setUserState('joom.migration.data.task', 'config');
      $this->refresh();
    }

    $migrateable_settings = array('jg_use_real_paths', 'jg_dateformat', 'jg_checkupdate',
                                  'jg_thumbcreation', 'jg_fastgd2thumbcreation', 'jg_impath', 'jg_resizetomaxwidth', 'jg_maxwidth', 'jg_picturequality', 'jg_useforresizedirection', 'jg_cropposition', 'jg_thumbwidth', 'jg_thumbheight', 'jg_thumbquality',
                                  'jg_uploadorder', 'jg_useorigfilename', 'jg_filenamenumber', 'jg_delete_original', 'jg_wrongvaluecolor',
                                  'jg_msg_upload_type', 'jg_msg_upload_recipients', 'jg_msg_download_type', 'jg_msg_zipdownload', 'jg_msg_download_recipients', 'jg_msg_comment_type', 'jg_msg_comment_recipients', 'jg_msg_comment_toowner', 'jg_msg_nametag_type', 'jg_msg_nametag_recipients', 'jg_msg_nametag_totaggeduser', 'jg_msg_nametag_toowner', 'jg_msg_report_type', 'jg_msg_report_recipients', 'jg_msg_report_toowner',
                                  'jg_realname', 'jg_cooliris', 'jg_coolirislink', 'jg_contentpluginsenabled', 'jg_itemid',
                                  'jg_userspace', 'jg_approve', 'jg_maxusercat', 'jg_maxuserimage', 'jg_maxfilesize', 'jg_usercatacc', 'jg_maxuploadfields', 'jg_useruploadsingle', 'jg_useruploadbatch', 'jg_useruploadjava', 'jg_useruseorigfilename', 'jg_useruploadnumber', 'jg_special_gif_upload', 'jg_delete_original_user', 'jg_newpiccopyright', 'jg_newpicnote', 'jg_redirect_after_upload',
                                  'jg_downloadfile', 'jg_downloadwithwatermark',
                                  'jg_showrating', 'jg_maxvoting', 'jg_ratingcalctype', 'jg_ratingdisplaytype', 'jg_ajaxrating', 'jg_onlyreguservotes AS jg_votingonlyonce',
                                  'jg_showcomment', 'jg_anoncomment', 'jg_namedanoncomment', 'jg_approvecom', 'jg_bbcodesupport', 'jg_smiliesupport', 'jg_anismilie', 'jg_smiliescolor',
                                  'jg_anchors', 'jg_tooltips', 'jg_dyncrop', 'jg_dyncropposition', 'jg_dyncropwidth', 'jg_dyncropheight', 'jg_dyncropbgcol', 'jg_hideemptycats', 'jg_imgalign',
                                  'jg_firstorder', 'jg_secondorder', 'jg_thirdorder',
                                  'jg_showgalleryhead', 'jg_showpathway', 'jg_completebreadcrumbs', 'jg_showallpics', 'jg_showallhits', 'jg_showbacklink', 'jg_suppresscredits', 'jg_showrmsmcats AS jg_showrestrictedcats', 'jg_rmsm AS jg_showrestrictedhint',
                                  'jg_showallpicstoadmin', 'jg_showminithumbs', 'jg_openjs_padding', 'jg_openjs_background', 'jg_dhtml_border', 'jg_show_title_in_dhtml AS jg_show_title_in_popup', 'jg_show_description_in_dhtml AS jg_show_description_in_popup', 'jg_lightbox_speed', 'jg_lightbox_slide_all', 'jg_resize_js_image', 'jg_disable_rightclick_original',
                                  'jg_showgallerysubhead', 'jg_showallcathead', 'jg_colcat', 'jg_catperpage', 'jg_ordercatbyalpha', 'jg_showgallerypagenav', 'jg_showcatcount', 'jg_showcatthumb', 'jg_showrandomcatthumb', 'jg_ctalign', 'jg_showtotalcatimages', 'jg_showtotalcathits', 'jg_showcatasnew', 'jg_catdaysnew', 'jg_showdescriptioningalleryview', 'jg_showsubsingalleryview',
                                  'jg_category_rss', 'jg_showcathead', 'jg_usercatorder', 'jg_usercatorderlist', 'jg_showcatdescriptionincat', 'jg_showpagenav', 'jg_showpiccount', 'jg_perpage', 'jg_catthumbalign', 'jg_colnumb', 'jg_detailpic_open', 'jg_lightboxbigpic', 'jg_showtitle', 'jg_showpicasnew', 'jg_daysnew', 'jg_showhits', 'jg_showauthor', 'jg_showowner', 'jg_showcatcom', 'jg_showcatrate', 'jg_showcatdescription', 'jg_showcategoryfavourite', 'jg_showcategoryeditorlinks',
                                  'jg_showsubcathead', 'jg_showsubcatcount', 'jg_colsubcat', 'jg_subperpage', 'jg_showpagenavsubs', 'jg_subcatthumbalign', 'jg_showsubthumbs', 'jg_showrandomsubthumb', 'jg_showdescriptionincategoryview', 'jg_ordersubcatbyalpha', 'jg_showtotalsubcatimages', 'jg_showtotalsubcathits',
                                  'jg_showdetailpage', 'jg_disabledetailpage', 'jg_showdetailnumberofpics', 'jg_cursor_navigation', 'jg_disable_rightclick_detail', 'jg_showdetaileditorlinks', 'jg_showdetailtitle', 'jg_showdetail', 'jg_showdetailaccordion', 'jg_showdetaildescription', 'jg_showdetaildatum', 'jg_showdetailhits', 'jg_showdetailrating', 'jg_showdetailfilesize', 'jg_showdetailauthor', 'jg_showoriginalfilesize', 'jg_watermark', 'jg_watermarkpos', 'jg_bigpic', 'jg_bigpic_open', 'jg_bbcodelink', 'jg_showcommentsunreg', 'jg_showcommentsarea', 'jg_send2friend',
                                  'jg_minis', 'jg_motionminis', 'jg_motionminiWidth', 'jg_motionminiHeight', 'jg_miniWidth', 'jg_miniHeight', 'jg_minisprop',
                                  'jg_nameshields', 'jg_nameshields_others', 'jg_nameshields_unreg', 'jg_show_nameshields_unreg', 'jg_nameshields_height', 'jg_nameshields_width',
                                  'jg_slideshow', 'jg_slideshow_timer', 'jg_slideshow_transition', 'jg_slideshow_transtime', 'jg_slideshow_maxdimauto', 'jg_slideshow_width', 'jg_slideshow_heigth', 'jg_slideshow_infopane', 'jg_slideshow_carousel', 'jg_slideshow_arrows', 'jg_slideshow_repeat',
                                  'jg_showexifdata', 'jg_geotagging', 'jg_subifdtags', 'jg_ifdotags', 'jg_gpstags',
                                  'jg_showiptcdata', 'jg_iptctags',
                                  'jg_showtoplist', 'jg_toplist', 'jg_topthumbalign', 'jg_toptextalign', 'jg_toplistcols', 'jg_whereshowtoplist', 'jg_showrate', 'jg_showlatest', 'jg_showcom', 'jg_showthiscomment', 'jg_showmostviewed', 'jg_showtoplistfavourite', 'jg_showtoplisteditorlinks',
                                  'jg_favourites', 'jg_favouritesshownotauth', 'jg_maxfavourites', 'jg_zipdownload', 'jg_usefavouritesforpubliczip', 'jg_usefavouritesforzip', 'jg_showfavouriteseditorlinks',
                                  'jg_search', 'jg_searchcols', 'jg_searchthumbalign', 'jg_searchtextalign', 'jg_showsearchfavourite', 'jg_showsearcheditorlinks'
                                  );

    $this->writeLogfile('Start migrating configuration');
    $query = $this->_db->getQuery(true)
          ->select($migrateable_settings)
          ->from($this->table_config)
          ->where('id = 1');
    $this->_db->setQuery($query);

    if(!$settings = $this->runQuery('loadObject'))
    {
      $this->setError('Old configuration settings not found');

      return;
    }

    $config = JoomConfig::getInstance('admin');
    if(!$config->save($settings, 1))
    {
      $this->setError('Unable to store migrated settings');

      return;
    }

    $this->writeLogfile('Configuration successfully migrated');

    $query->clear()
          ->select('COUNT(id)')
          ->from(_JOOM_TABLE_CONFIG);
    $this->_db->setQuery($query);
    if($this->runQuery('loadResult') > 1)
    {
      // Propagate global settings to all config rows
      $this->writeLogfile('Propagate migrated settings to all other config rows');
      $model = JModel::getInstance('Configs', 'JoomGalleryModel');
      if(!$model->propagateChanges($settings))
      {
        $this->setError($model->getError());

        return;
      }

      $this->writeLogfile('Settings were successfully propagated');
    }
  }
}

if(isset($show_jmtablerow)):
  JFactory::getLanguage()->load('com_joomgallery.mvc2acl'); ?>
          <tr>
            <td width="50%">
              <h4><?php echo JText::sprintf('COM_JOOMGALLERY_MIGMAN_MIGRATIONCHECK', 'JoomGallery 1.5.7'); ?></h4>
            </td>
            <td>
              <form action="index.php?option=<?php echo _JOOM_OPTION; ?>&amp;controller=migration&amp;task=check" method="post" class="form-validate jg-migration-form">
                <div>
                  <ul>
                    <li>
                      <label for="prefix-mvc2acl" class="hasTip" title="<?php echo JText::_('FILES_JOOMGALLERY_MIGRATION_MVC2ACL_PREFIX_LABEL'); ?>" rel="<?php echo JText::_('FILES_JOOMGALLERY_MIGRATION_MVC2ACL_PREFIX_DESC'); ?>">
                        <?php echo JText::_('FILES_JOOMGALLERY_MIGRATION_MVC2ACL_PREFIX_LABEL'); ?>
                      </label>
                      <input type="text" id="prefix-mvc2acl" name="prefix" size="10" class="required" value="<?php echo JFactory::getApplication()->getUserState('joom.migration.mvc2acl.prefix'); ?>" />
                    </li>
                    <li>
                      <label for="path2joomla-mvc2acl" class="hasTip" title="<?php echo JText::_('FILES_JOOMGALLERY_MIGRATION_MVC2ACL_PATH2JOOMLA_LABEL'); ?>" rel="<?php echo JText::_('FILES_JOOMGALLERY_MIGRATION_MVC2ACL_PATH2JOOMLA_DESC'); ?>">
                        <?php echo JText::_('FILES_JOOMGALLERY_MIGRATION_MVC2ACL_PATH2JOOMLA_LABEL'); ?>
                      </label>
                      <input type="text" id="path2joomla-mvc2acl" name="path2joomla" size="80" class="required" value="<?php echo JFactory::getApplication()->getUserState('joom.migration.mvc2acl.path2joomla', JPATH_ROOT); ?>" />
                    </li>
                    <li>
                      <label for="originals-mvc2acl" class="hasTip" title="<?php echo JText::_('FILES_JOOMGALLERY_MIGRATION_MVC2ACL_ORIGINALS_LABEL'); ?>" rel="<?php echo JText::_('FILES_JOOMGALLERY_MIGRATION_MVC2ACL_ORIGINALS_DESC'); ?>">
                        <?php echo JText::_('FILES_JOOMGALLERY_MIGRATION_MVC2ACL_ORIGINALS_LABEL'); ?>
                      </label>
                      <input type="text" id="originals-mvc2acl" name="originals" size="80" class="required" value="<?php echo JFactory::getApplication()->getUserState('joom.migration.mvc2acl.originals', $this->_config->get('jg_pathoriginalimages')); ?>" />
                    </li>
                    <li>
                      <label for="details-mvc2acl" class="hasTip" title="<?php echo JText::_('FILES_JOOMGALLERY_MIGRATION_MVC2ACL_DETAILS_LABEL'); ?>" rel="<?php echo JText::_('FILES_JOOMGALLERY_MIGRATION_MVC2ACL_DETAILS_DESC'); ?>">
                        <?php echo JText::_('FILES_JOOMGALLERY_MIGRATION_MVC2ACL_DETAILS_LABEL'); ?>
                      </label>
                      <input type="text" id="details-mvc2acl" name="details" size="80" class="required" value="<?php echo JFactory::getApplication()->getUserState('joom.migration.mvc2acl.details', $this->_config->get('jg_pathimages')); ?>" />
                    </li>
                    <li>
                      <label for="thumbnails-mvc2acl" class="hasTip" title="<?php echo JText::_('FILES_JOOMGALLERY_MIGRATION_MVC2ACL_THUMBNAILS_LABEL'); ?>" rel="<?php echo JText::_('FILES_JOOMGALLERY_MIGRATION_MVC2ACL_THUMBNAILS_DESC'); ?>">
                        <?php echo JText::_('FILES_JOOMGALLERY_MIGRATION_MVC2ACL_THUMBNAILS_LABEL'); ?>
                      </label>
                      <input type="text" id="thumbnails-mvc2acl" name="thumbnails" size="80" class="required" value="<?php echo JFactory::getApplication()->getUserState('joom.migration.mvc2acl.thumbnails', $this->_config->get('jg_paththumbs')); ?>" />
                    </li>
                    <li>
                      <label for="owner-mvc2acl" class="hasTip" title="<?php echo JText::_('FILES_JOOMGALLERY_MIGRATION_MVC2ACL_CHECK_OWNER_LABEL'); ?>" rel="<?php echo JText::_('FILES_JOOMGALLERY_MIGRATION_MVC2ACL_CHECK_OWNER_DESC'); ?>">
                        <?php echo JText::_('FILES_JOOMGALLERY_MIGRATION_MVC2ACL_CHECK_OWNER_LABEL'); ?>
                      </label>
                      <input type="checkbox" id="owner-mvc2acl" name="check_owner_box" value="1"<?php echo JFactory::getApplication()->getUserState('joom.migration.mvc2acl.owner', false) ? ' checked="checked"' : ''; ?> onchange="this.checked ? this.form.check_owner.value = 1 : this.form.check_owner.value = 0;" />
                      <input type="hidden" name="check_owner" value="<?php echo JFactory::getApplication()->getUserState('joom.migration.mvc2acl.owner', false) ? '1' : '0'; ?>" />
                    </li>
                    <li>
                      <label for="button-mvc2acl"></label>
                      <button id="button-mvc2acl"><?php echo JText::_('COM_JOOMGALLERY_MIGMAN_CHECK'); ?></button>
                    </li>
                    <li>
                      <span class="jg_clearboth jg-floatleft"><?php echo JText::_('FILES_JOOMGALLERY_MIGRATION_MVC2ACL_NOTES'); ?></span>
                    </li>
                  </ul>
                  <input type="hidden" name="migration" value="mvc2acl" />
                </div>
              </form>
            </td>
          </tr>
<?php endif;