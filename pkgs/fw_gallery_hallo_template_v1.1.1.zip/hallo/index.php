<?php
/**
 * Hallo x.x.x
 * @copyright (C) 2011 Fastweb
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined('_JEXEC') or die;
JHTML::_('behavior.framework', true);
$app = JFactory::getApplication();
?>
<?php echo '<?'; ?>xml version="1.0" encoding="<?php echo $this->_charset ?>"?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>" >

  <head>
      <jdoc:include type="head" />
     
<link rel="stylesheet" href="/templates/system/css/system.css" type="text/css" />

<link rel="stylesheet" href="/templates/system/css/general.css" type="text/css" />

<link href="<?php echo $this->baseurl;?>/templates/<?php echo $this->template; ?>/css/template.css" rel="stylesheet" type="text/css" />
 
  </head>
	<body id="bd">

			<!-- header -->
			
			<div id="container-top-header">
				<div id="container-top-logo">
					<!--menu-->				
					<?php if($this->countModules('menu')) : ?>
						<div id="menu">
							<jdoc:include type="modules" name="menu" style="xhtml" />
						</div>		
					<?php endif; ?>
					<!--end menu-->

					<!--logo-->
					<div id="logo">
						<a href="<?php echo $this->baseurl;?>" alt="<?php echo JText::_("Real estate");?>">
							<img src="<?php echo $this->baseurl;?>/templates/<?php echo $this->template; ?>/images/logo.png" 
								width="767" height="167" alt="<?php echo JText::_("Real estate");?>" />
						</a>
					</div>
			
				</div>
						
			</div>
		
		<div id="wrapper-box">
		
			<!-- content -->
			
			<div id="blockcontent<?php if($this->countModules('right') or
			$this->countModules('right') or
			$this->countModules('right-images-right') or
			$this->countModules('twitter') or
			$this->countModules('name-social-icons-block') or
			$this->countModules('rss') or 
			$this->countModules('ff') or 
			$this->countModules('flickr') or 
			$this->countModules('tumblr')
			) echo "-right"; ?>">
			
				<div id="content">
				<jdoc:include type="component" />
				</div>
				
				<?php if($this->countModules('bottom-content-left')) : ?>
				<div class="bottom-content-block">
					<div class="bottom-content-left<?php if($this->countModules('bottom-content-right')) echo "-width50"; ?>">
						<jdoc:include type="modules" name="bottom-content-left" style="xhtml" />
					</div>
					
					<?php if($this->countModules('bottom-content-right')) : ?>
					<div class="bottom-content-right">
						<jdoc:include type="modules" name="bottom-content-right" style="xhtml" />
					</div>
					<?php endif; ?>
				</div>
				<?php endif; ?>
				
			</div>

				<!-------- right  --------->
				
				<div id="right">
				
					<?php if($this->countModules('right')) : ?>
						<div class="right">
							<jdoc:include type="modules" name="right" style="xhtml" />
						</div>
					<?php endif; ?>
					
					
					<!--right-images-block-->
					<?php if($this->countModules('right')) : ?>
					<div class="right-images-block">
						<div class="right-images-left<?php if($this->countModules('right-images-right')) echo "-width50"; ?>">
							<jdoc:include type="modules" name="right-images-left" style="xhtml" />
						</div>
						
						<?php if($this->countModules('right-images-right')) : ?>
						<div class="right-images-right">
							<jdoc:include type="modules" name="right-images-right" style="xhtml" />
						</div>
						<?php endif; ?>
					</div>
					<?php endif; ?>
			
					<!--social icons-->
					<?php if($this->countModules('name-social-icons-block') or
					$this->countModules('twitter') or 
					$this->countModules('rss') or 
					$this->countModules('ff') or 
					$this->countModules('flickr') or 
					$this->countModules('tumblr')) : ?>
					<div id="social-icons-block">
						
						<?php if($this->countModules('name-social-icons-block')) : ?>
						<div class="name-social-icons-block">
							<jdoc:include type="modules" name="name-social-icons-block"/>
						</div>
						<?php endif; ?>
						
						<?php if($this->countModules('twitter')) : ?>
						<div class="twitter social-icons">
							<jdoc:include type="modules" name="twitter"/>
						</div>
						<?php endif; ?>
						
						<?php if($this->countModules('rss')) : ?>
						<div class="rss social-icons">
							<jdoc:include type="modules" name="rss"/>
						</div>
						<?php endif; ?>
						
						<?php if($this->countModules('ff')) : ?>
						<div class="ff social-icons">
							<jdoc:include type="modules" name="ff"/>
						</div>
						<?php endif; ?>
						
						<?php if($this->countModules('flickr')) : ?>
						<div class="flickr social-icons">
							<jdoc:include type="modules" name="flickr"/>
						</div>
						<?php endif; ?>
						
						<?php if($this->countModules('tumblr')) : ?>
						<div class="tumblr social-icons">
							<jdoc:include type="modules" name="tumblr"/>
						</div>
						<?php endif; ?>
										
					</div>
					<?php endif; ?>
				
				</div>
				<!-------- end right  --------->
			
		</div>
			<!-- end content -->
	
	<!--footer-->	
		<div id="footer">
			<?php if($this->countModules('copyright')) : ?>
			<div class="copyright">
				<jdoc:include type="modules" name="copyright" style="xhtml" />
			</div>
			<?php endif; ?>
		</div>
	<!-- end footer-->	
	<div id="fastw3b">
				<a href="http://www.fastw3b.net">
							<img src="<?php echo $this->baseurl;?>/templates/<?php echo $this->template; ?>/images/fastw3b.png" 
								width="129" height="37" alt="fastw3b" />
						</a>
			</div>
		
	</body>
</html>
