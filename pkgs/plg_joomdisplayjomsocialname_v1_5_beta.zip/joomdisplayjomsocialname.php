<?php
// $HeadURL: https://joomgallery.org/svn/joomgallery/JG-1.5/Plugins/JoomDisplayJomSocialName/trunk/joomdisplayjomsocialname.php $
// $Id: joomdisplayjomsocialname.php 2197 2010-06-08 14:53:45Z chraneco $
/****************************************************************************************\
**   Plugin 'JoomDisplayJomSocialName' 1.5                                              **
**   By: JoomGallery::ProjectTeam                                                       **
**   Copyright (C) 2010 - 2010 Patrick Alt                                              **
**   Released under GNU GPL Public License                                              **
**   License: http://www.gnu.org/copyleft/gpl.html or have a look                       **
**   at administrator/components/com_joomgallery/LICENSE.TXT                            **
\****************************************************************************************/

defined('_JEXEC') or die('Direct Access to this location is not allowed.');

jimport('joomla.plugin.plugin');

/**
 * JoomGallery Display JomSocial Name Plugin
 *
 * @package     Joomla
 * @subpackage  JoomGallery
 * @since       1.5
 */
class plgJoomGalleryJoomDisplayJomSocialName extends JPlugin
{
  /**
   * Constructor
   *
   * For php4 compatability we must not use the __constructor as a constructor for plugins
   * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
   * This causes problems with cross-referencing necessary for the observer design pattern.
   *
   * @access  protected
   * @param   object    $subject  The object to observe
   * @param   object    $params   The object that holds the plugin parameters
   * @return  void
   * @since   1.5
   */
  function plgJoomGalleryJoomDisplayJomSocialName(&$subject, $params)
  {
    parent::__construct($subject, $params);

    // Load the language file
    //$this->loadLanguage('', JPATH_ADMINISTRATOR);
  }

  /**
   * OnJoomDisplayUser method
   *
   * Method links a user name with the corresponding JomSocial profile.
   *
   * @access  public
   * @param   int     $userID   The ID of the user to display
   * @param   boolean $realname True, if the user's full name shall be displayed
   * @param   string  $context  The context in which the name will be displayed
   * @return  string  The HTML code created for displaying the user's name
   * @since   1.5
   */
  function onJoomDisplayUser(&$userId, &$realname, $context = null)
  {
    static $loaded = false;

    if(!$loaded)
    {
      $file = JPATH_ROOT.DS.'components'.DS.'com_community'.DS.'libraries'.DS.'core.php';
      if(file_exists($file))
      {
        require_once($file);
        $loaded = true;
      }
      else
      {
        JError::raiseError(500, JText::_('JomSocial seems not to be installed'/*PLG_JOOMDISPLAYJOMSOCIALNAME_KUNENA_SEEMS_NOT_TO_BE_INSTALLED*/));
      }
    }

    $userId = intval($userId);

    $user   = & CFactory::getUser($userId);

    if(!$user)
    {
      return false;
    }

    $name = $user->getDisplayName();

    if(!$name)
    {
      return false;
    }

    $link = 'index.php?option=com_community&view=profile&userid='.$userId;

    CFactory::load('libraries', 'tooltip');
    CFactory::load('helpers',   'string');
    JHTML::_('behavior.tooltip');

    $language = & JFactory::getLanguage();
    $language->load('com_community');

    $html = '<a href="'.CRoute::_($link).'" title="'.cAvatarTooltip($user).'" class="hasTip">';

    if($context == 'comment')
    {
      $html .= '<img class="avatar" src="'.$user->getThumbAvatar().'" width="45" height="45" alt="'.$user->getDisplayName().'" />';
    }
    else
    {
      $html .= $name;
    }

    $html .= '</a>';

    return $html;
  }
}