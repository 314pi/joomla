<?php
// $HeadURL: https://joomgallery.org/svn/joomgallery/JG-2.0/Module/JoomCategories/trunk/changelog.php $
// $Id: changelog.php 3693 2012-03-08 16:01:04Z erftralle $
/**
* Module JoomCategories for JoomGallery
* by JoomGallery::Project Team
* @package JoomGallery
* @copyright JoomGallery::Project Team
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
*
* This program is free software; you can redistribute it and/or modify it under
* the terms of the GNU General Public License as published by the Free Software
* Foundation, either version 2 of the License, or (at your option) any later
* version.
*
* This program is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY, without even the implied warranty of MERCHANTABILITY or FITNESS
* FOR A PARTICULAR PURPOSE.
* See the GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License along with
* this program; if not, write to the Free Software Foundation, Inc.,
* 51 Franklin St, Fifth Floor, Boston, MA 02110, USA
*/

// no direct access
defined('_JEXEC') or die('Restricted access');
?>

CHANGELOG MOD_JOOMCAT (since Version 2.0 BETA )

Legende / Legend:

* -> Security Fix
# -> Bug Fix
+ -> Addition
^ -> Change
- -> Removed
! -> Note

-------------------------------------------------------------------------------
MOD_JOOMCAT version: 2.0 BETA4
-------------------------------------------------------------------------------
20120308
^ CSS improvements

-------------------------------------------------------------------------------
MOD_JOOMCAT version: 2.0 BETA3
-------------------------------------------------------------------------------
20120126
^ Javascript adaptions to become campatible with Mootools 1.4.2

-------------------------------------------------------------------------------
MOD_JOOMCAT version: 2.0 BETA2
-------------------------------------------------------------------------------
20120120
# If 'Thumbnail display mode' was set to 'Manual setting' the selected
  thumbnail had to be in the category itself, selecting thumbnails from other
  categories caused a complete false module output for some cases.

-------------------------------------------------------------------------------
MOD_JOOMCAT version: 2.0 BETA
-------------------------------------------------------------------------------
20111012
^ assets moved to media/mod_joomcat
+ Update server added

20110924
^ Changes due to JoomGallery's new category structure and the
  use of JTableNested for _JOOM_TABLE_CATEGORIES
^ Javascript adaptions to become campatible with Mootools 1.3
^ Language constants renamed (Joomla! standards)

20110508
^ Adaptions for Joomla 1.6! compatibility (language files, XML files, parameters
  , JDatabaseQuery)
