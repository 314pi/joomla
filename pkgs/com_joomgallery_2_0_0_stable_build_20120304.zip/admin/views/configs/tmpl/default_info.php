<?php defined('_JEXEC') or die('Direct Access to this location is not allowed.'); ?>
<div id="jg-info-popup">
  <div class="m">
    <h2><?php echo JText::_('COM_JOOMGALLERY_CONFIGS_WELCOME'); ?></h2>
    <div class="jg-configs-introduction"><?php echo JText::_('COM_JOOMGALLERY_CONFIGS_INTRODUCTION_INTRO'); ?></div>
    <div><?php echo JText::_('COM_JOOMGALLERY_CONFIGS_INTRODUCTION'); ?></div>
    <div class="jg-configs-button-holder">
      <div class="button-holder">
        <div class="button1">
          <div class="next">
            <a onclick="window.parent.SqueezeBox.close();" href="#"><?php echo JText::_('COM_JOOMGALLERY_CONFIGS_OK'); ?></a>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>