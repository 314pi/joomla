<?php
defined( '_JEXEC' ) or die( 'Direct Access to this location is not allowed.' );
?>

CHANGELOG Plugin JoomMultiSlimbox for JoomGallery

Legend:

* -> Security Fix
# -> Bug Fix
+ -> Addition
^ -> Change
- -> Removed
! -> Note


                   ***  Version 1.5.2  ****
20110325
# slimbox 1.71 doesn't work with FF 4, IE 9, new option to include mootols 1.3 to correct this issue

20101103
# slimbox doesn't show the full description if hyphens included (thx @Erftralle)

                   ***  Version 1.5.1  ****
 
20101025
# Slimbox 1.71 and 1.58 doesn't work with activated resize in other browsers than Firefox
# JS-error in IE 7/8 with all slimboxes
# No prev/next in IE 7/8

                   ***  Version 1.5    ****

20101016
!First version