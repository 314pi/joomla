<?php
/**
 * JFUploader 2.16.x Freeware - for Joomla 1.5.x
 *
 * Copyright (c) 2004-2012 TinyWebGallery
 * written by Michael Dempfle
 *
 * @license GNU / GPL  
 *  
 * For the latest version please go to http://jfu.tinywebgallery.com
**/
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
?>
<h1>JFUploader</h1>
This file is not used yet. Currently I stick with my old structure because I 
use the code which should be in this file for the site and the plugin as well!